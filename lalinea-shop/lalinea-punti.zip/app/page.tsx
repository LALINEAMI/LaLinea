"use client";



import { useEffect, useRef, useState, type ReactNode } from "react";
import { createPortal as laLineaGamePortal } from "react-dom";

function mescolaNumeri(valori: number[]) {
  const copia = [...valori];
  for (let i = copia.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copia[i], copia[j]] = [copia[j], copia[i]];
  }
  return copia;
}
function InfoRiga({
  etichetta,
  children,
}: {
  etichetta: string;
  
  children: ReactNode;
}) {
  return (
    <p className="flex flex-col gap-2 sm:flex-row sm:items-start">
      <span className="w-fit shrink-0 rounded-full border border-yellow-300/80 bg-yellow-400/10 px-3 py-1 text-[11px] font-black uppercase tracking-[0.16em] text-yellow-300 shadow-[0_0_14px_rgba(250,204,21,0.45)]">
        {etichetta}
      </span>
      <span className="min-w-0 break-words text-sm font-bold uppercase leading-relaxed text-zinc-200">
        {children}
      </span>
    </p>
  );
}

function NeonGlobalStyle() {
  return (
    <style jsx global>{`
      .lalinea-neon [class~="text-yellow-300"],
      .lalinea-neon [class~="text-yellow-400"] {
        text-shadow:
          0 1px 1px rgba(0, 0, 0, 1),
          0 0 5px rgba(250, 204, 21, 0.95),
          0 0 12px rgba(250, 204, 21, 0.72),
          0 0 22px rgba(250, 204, 21, 0.38);
      }

      .lalinea-neon .lalinea-price-neon {
        color: rgb(74 222 128);
        -webkit-text-stroke: 0.2px rgba(0, 0, 0, 0.9);
        text-shadow:
          0 1px 1px rgba(0, 0, 0, 1),
          0 0 5px rgba(74, 222, 128, 0.98),
          0 0 12px rgba(34, 197, 94, 0.78),
          0 0 24px rgba(34, 197, 94, 0.48);
      }

      .lalinea-neon .text-white,
      .lalinea-neon [class~="text-zinc-200"],
      .lalinea-neon [class~="text-zinc-300"],
      .lalinea-neon [class~="text-zinc-400"] {
        text-shadow:
          1px 0 1px rgba(0, 0, 0, 0.95),
          -1px 0 1px rgba(0, 0, 0, 0.95),
          0 1px 1px rgba(0, 0, 0, 0.95),
          0 -1px 1px rgba(0, 0, 0, 0.95);
      }

      @keyframes lalineaAccessPulse {
        0%, 100% {
          transform: scale(0.96);
          opacity: 0.72;
          box-shadow: 0 0 10px rgba(250, 204, 21, 0.35);
        }
        50% {
          transform: scale(1.04);
          opacity: 1;
          box-shadow: 0 0 34px rgba(250, 204, 21, 0.9);
        }
      }

      @keyframes lalineaAccessScan {
        0% { transform: translateY(-44px); opacity: 0; }
        20% { opacity: 1; }
        80% { opacity: 1; }
        100% { transform: translateY(44px); opacity: 0; }
      }

      .lalinea-access-pulse {
        animation: lalineaAccessPulse 0.85s ease-in-out infinite;
      }

      .lalinea-access-scan {
        animation: lalineaAccessScan 0.9s ease-in-out infinite;
      }

      .ll-mobile-home,
      .ll-mobile-toolbar {
        display: none;
      }

      @media (max-width: 767px) {
        .lalinea-mobile-shell 
          height: 100dvh;
          min-height: 0 !important;
          overflow: hidden;
          background: #000;
        }

        .lalinea-mobile-shell .ll-hero-banner,
        .lalinea-mobile-shell > section,
        .lalinea-mobile-shell > footer,
        .lalinea-mobile-shell > .ll-gioca {
          display: none !important;
        }

        .lalinea-mobile-shell > a[href="/vip"] {
          display: none !important;
        }

        .lalinea-mobile-shell > header {
          position: relative !important;
          top: auto !important;
          z-index: 70;
          height: 4.75rem;
          flex: 0 0 4.75rem;
          border-bottom-color: rgba(250, 204, 21, 0.5);
          box-shadow: 0 10px 28px rgba(0, 0, 0, 0.45);
        }

        .lalinea-mobile-shell > header > div {
          height: 4.75rem !important;
          padding-left: 0.75rem !important;
          padding-right: 0.75rem !important;
        }

        .lalinea-mobile-shell > header img {
          height: 3.25rem !important;
          max-width: 34vw;
          object-fit: contain;
        }

        .ll-mobile-home,
        .ll-mobile-toolbar {
          font-family: "Avenir Next Condensed", "Arial Narrow", -apple-system,
            BlinkMacSystemFont, "Segoe UI", sans-serif;
        }

        .lalinea-mobile-shell[data-vista-mobile="home"] > .ll-mobile-home {
          display: flex !important;
        }

        .ll-mobile-home {
          height: calc(100dvh - 4.75rem);
          min-height: 0;
          flex-direction: column;
          overflow: hidden;
          padding: 0.75rem 0.75rem calc(10.25rem + env(safe-area-inset-bottom));
          background:
            radial-gradient(circle at 50% -10%, rgba(250, 204, 21, 0.16), transparent 35%),
            linear-gradient(180deg, #090909 0%, #000 65%);
        }

        .ll-catalog-kicker {
          -webkit-text-stroke: 0.35px rgba(0, 0, 0, 0.95);
          text-shadow:
            1px 0 0 rgba(0,0,0,.95),
            -1px 0 0 rgba(0,0,0,.95),
            0 1px 0 rgba(0,0,0,.95),
            0 -1px 0 rgba(0,0,0,.95),
            0 0 5px rgba(250, 204, 21, 0.95),
            0 0 12px rgba(250, 204, 21, 0.55);
        }

        .ll-simple-live {
          display: inline-flex;
          align-items: center;
          gap: 0.35rem;
          border: 1px solid rgba(74, 222, 128, 0.7);
          border-radius: 9999px;
          background: rgba(0, 0, 0, 0.86);
          padding: 0.3rem 0.55rem;
          color: rgb(187 247 208);
          box-shadow: 0 0 14px rgba(34, 197, 94, 0.22);
          white-space: nowrap;
        }

        .ll-simple-live-dot {
          width: 0.42rem;
          height: 0.42rem;
          border-radius: 9999px;
          background: rgb(74 222 128);
          box-shadow: 0 0 8px rgba(74, 222, 128, 0.95);
          animation: llLivePulse 1.8s ease-in-out infinite;
        }

        @keyframes llLivePulse {
          0%, 100% { opacity: 0.55; transform: scale(0.9); }
          50% { opacity: 1; transform: scale(1.15); }
        }

        .ll-vpn-security {
          display: grid;
          grid-template-columns: 2.15rem minmax(0, 1fr);
          align-items: center;
          gap: 0.45rem;
          min-width: 9.8rem;
          max-width: 46vw;
          border: 1px solid rgba(74, 222, 128, 0.7);
          border-radius: 1rem;
          background:
            radial-gradient(circle at 16% 50%, rgba(34, 197, 94, 0.18), transparent 42%),
            rgba(0, 0, 0, 0.88);
          padding: 0.42rem 0.55rem;
          color: rgb(220 252 231);
          box-shadow:
            inset 0 0 0 1px rgba(255, 255, 255, 0.025),
            0 0 16px rgba(34, 197, 94, 0.2);
          backdrop-filter: blur(10px);
        }

        .ll-vpn-orb {
          position: relative;
          display: grid;
          width: 2rem;
          height: 2rem;
          place-items: center;
          border: 1px solid rgba(74, 222, 128, 0.75);
          border-radius: 9999px;
          background: rgba(20, 83, 45, 0.28);
          color: rgb(74 222 128);
          box-shadow: 0 0 12px rgba(34, 197, 94, 0.35);
        }

        .ll-vpn-orb::after {
          content: "";
          position: absolute;
          inset: -0.22rem;
          border: 1px dashed rgba(250, 204, 21, 0.5);
          border-radius: 9999px;
          animation: llVpnOrbit 8s linear infinite;
        }

        .ll-vpn-lock {
          position: absolute;
          right: -0.2rem;
          bottom: -0.15rem;
          display: grid;
          width: 0.9rem;
          height: 0.9rem;
          place-items: center;
          border-radius: 9999px;
          background: rgb(250 204 21);
          color: #050505;
          box-shadow: 0 0 8px rgba(250, 204, 21, 0.55);
        }

        .ll-vpn-copy {
          min-width: 0;
          line-height: 1.05;
        }

        .ll-vpn-label {
          display: block;
          overflow: hidden;
          color: rgb(134 239 172);
          font-size: 0.44rem;
          font-weight: 900;
          letter-spacing: 0.16em;
          text-overflow: ellipsis;
          text-transform: uppercase;
          white-space: nowrap;
        }

        .ll-vpn-city {
          display: block;
          margin-top: 0.12rem;
          overflow: hidden;
          color: white;
          font-size: 0.58rem;
          font-weight: 950;
          letter-spacing: 0.08em;
          text-overflow: ellipsis;
          text-transform: uppercase;
          white-space: nowrap;
        }

        .ll-vpn-high {
          display: inline-flex;
          align-items: center;
          gap: 0.22rem;
          margin-top: 0.14rem;
          color: rgb(253 224 71);
          font-size: 0.39rem;
          font-weight: 950;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          white-space: nowrap;
        }

        .ll-vpn-high-dot {
          width: 0.3rem;
          height: 0.3rem;
          border-radius: 9999px;
          background: rgb(74 222 128);
          box-shadow: 0 0 6px rgba(74, 222, 128, 0.95);
        }

        .ll-vpn-demo {
          margin-left: 0.22rem;
          color: rgb(161 161 170);
          font-size: 0.34rem;
          letter-spacing: 0.06em;
        }

        @keyframes llVpnOrbit {
          to { transform: rotate(360deg); }
        }

        .ll-mobile-category-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          grid-template-rows: repeat(3, minmax(0, 1fr));
          gap: 0.55rem;
          min-height: 0;
          flex: 1 1 auto;
        }

        .ll-mobile-category-card {
          position: relative;
          min-width: 0;
          min-height: 0;
          overflow: hidden;
          border: 1px solid rgba(253, 224, 71, 0.6);
          border-radius: 1.15rem;
          background: #090909;
          box-shadow:
            inset 0 0 0 1px rgba(255,255,255,.025),
            0 0 16px rgba(250, 204, 21, 0.12);
          -webkit-tap-highlight-color: transparent;
        }

        .ll-mobile-category-card:active {
          transform: scale(0.97);
          border-color: rgb(253 224 71);
          box-shadow: 0 0 24px rgba(250, 204, 21, 0.32);
        }

        .ll-mobile-category-card img {
          pointer-events: none;
          user-select: none;
          -webkit-user-drag: none;
        }

        .ll-mobile-toolbar {
          height: 3.5rem;
          min-height: 3.5rem;
          align-items: center;
          gap: 0.55rem;
          border-bottom: 1px solid rgba(250, 204, 21, 0.35);
          background: rgba(0, 0, 0, 0.96);
          padding: 0.45rem 0.7rem;
          box-shadow: 0 8px 22px rgba(0,0,0,.4);
        }

        .lalinea-mobile-shell:not([data-vista-mobile="home"]) > .ll-mobile-toolbar {
          display: flex !important;
        }

        .lalinea-mobile-shell[data-vista-mobile="shop"] > #shop,
        .lalinea-mobile-shell[data-vista-mobile="gift-card"] > #shop,
        .lalinea-mobile-shell[data-vista-mobile="carrello"] > #shop,
        .lalinea-mobile-shell[data-vista-mobile="promo"] > #promo,
        .lalinea-mobile-shell[data-vista-mobile="tracking"] > #tracking,
        .lalinea-mobile-shell[data-vista-mobile="dicono-di-noi"] > #dicono-di-noi,
        .lalinea-mobile-shell[data-vista-mobile="point"] > #point,
        .lalinea-mobile-shell[data-vista-mobile="delivery"] > #delivery,
        .lalinea-mobile-shell[data-vista-mobile="contatti"] > #contatti {
          display: block !important;
          height: calc(100dvh - 8.25rem);
          min-height: 0;
          overflow-x: hidden;
          overflow-y: auto;
          overscroll-behavior: contain;
          -webkit-overflow-scrolling: touch;
          scrollbar-width: none;
          padding-bottom: calc(11.25rem + env(safe-area-inset-bottom)) !important;
        }

        .lalinea-mobile-shell[data-vista-mobile="shop"] > #shop::-webkit-scrollbar,
        .lalinea-mobile-shell[data-vista-mobile="gift-card"] > #shop::-webkit-scrollbar,
        .lalinea-mobile-shell[data-vista-mobile="carrello"] > #shop::-webkit-scrollbar,
        .lalinea-mobile-shell[data-vista-mobile="promo"] > #promo::-webkit-scrollbar,
        .lalinea-mobile-shell[data-vista-mobile="tracking"] > #tracking::-webkit-scrollbar,
        .lalinea-mobile-shell[data-vista-mobile="dicono-di-noi"] > #dicono-di-noi::-webkit-scrollbar,
        .lalinea-mobile-shell[data-vista-mobile="point"] > #point::-webkit-scrollbar,
        .lalinea-mobile-shell[data-vista-mobile="delivery"] > #delivery::-webkit-scrollbar,
        .lalinea-mobile-shell[data-vista-mobile="contatti"] > #contatti::-webkit-scrollbar {
          display: none;
        }

        .lalinea-mobile-shell[data-vista-mobile="shop"] > #shop,
        .lalinea-mobile-shell[data-vista-mobile="gift-card"] > #shop,
        .lalinea-mobile-shell[data-vista-mobile="carrello"] > #shop {
          max-width: none !important;
          margin: 0 !important;
          padding: 0.9rem 0.9rem calc(11.25rem + env(safe-area-inset-bottom)) !important;
        }

        .lalinea-mobile-shell #shop > .ll-shop-intro,
        .lalinea-mobile-shell #shop > .ll-category-nav {
          display: none !important;
        }

        .lalinea-mobile-shell[data-vista-mobile="gift-card"] #shop > :not(#gift-card),
        .lalinea-mobile-shell[data-vista-mobile="carrello"] #shop > :not(#ll-carrello):not(#ll-checkout) {
          display: none !important;
        }

        .lalinea-mobile-shell[data-vista-mobile="gift-card"] #gift-card {
          margin-top: 0 !important;
        }

        .lalinea-mobile-shell[data-vista-mobile="carrello"] #ll-carrello {
          margin-top: 0 !important;
        }

        /* Mobile bottom stack 2.0: player slim + feedback + Tetris */
        .ll-music-player {
          left: 0.5rem !important;
          bottom: calc(0.5rem + env(safe-area-inset-bottom)) !important;
          width: calc(50% - 0.75rem) !important;
          height: 3.35rem !important;
          max-height: 3.35rem !important;
          overflow: hidden !important;
          border-radius: 0.9rem !important;
          background: rgba(0, 0, 0, 0.97) !important;
          box-shadow:
            0 0 0 1px rgba(250, 204, 21, 0.14),
            0 0 18px rgba(250, 204, 21, 0.20) !important;
        }

        .ll-music-title,
        .ll-music-progress,
        .ll-music-counter {
          display: none !important;
        }

        .ll-music-body {
          height: 3.35rem !important;
          padding: 0.28rem 0.28rem 0.28rem 0.34rem !important;
          display: grid !important;
          grid-template-columns: minmax(0, 1fr) auto;
          align-items: center;
          gap: 0.28rem;
        }

        .ll-music-body > div:first-child {
          min-width: 0;
          padding-left: 1.18rem;
        }

        .ll-music-track {
          font-size: 0.50rem !important;
          line-height: 1.05 !important;
          letter-spacing: 0.03em !important;
        }

        .ll-music-artist {
          margin-top: 0.12rem !important;
          font-size: 0.37rem !important;
          line-height: 1 !important;
          color: #facc15 !important;
        }

        .ll-music-controls {
          margin-top: 0 !important;
          gap: 0.16rem !important;
          justify-content: flex-end !important;
        }

        .ll-music-controls button {
          width: 1.6rem !important;
          height: 1.6rem !important;
          min-width: 1.6rem !important;
          padding: 0 !important;
          border: 1px solid rgba(74, 222, 128, 0.72) !important;
          background: rgba(34, 197, 94, 0.10) !important;
          color: #86efac !important;
          box-shadow:
            inset 0 0 0 1px rgba(255, 255, 255, 0.03),
            0 0 10px rgba(34, 197, 94, 0.18) !important;
          backdrop-filter: blur(8px);
        }

        .ll-music-controls button svg {
          width: 0.72rem !important;
          height: 0.72rem !important;
          filter: drop-shadow(0 0 4px rgba(74, 222, 128, 0.34));
        }

        .ll-music-controls .ll-music-play {
          width: 2rem !important;
          height: 2rem !important;
          min-width: 2rem !important;
          border: 1px solid rgba(253, 224, 71, 0.95) !important;
          background: linear-gradient(145deg, #4ade80 0%, #16a34a 100%) !important;
          color: #050505 !important;
          box-shadow:
            0 0 0 2px rgba(250, 204, 21, 0.10),
            0 0 16px rgba(74, 222, 128, 0.34) !important;
        }

        .ll-music-controls .ll-music-play svg {
          width: 0.82rem !important;
          height: 0.82rem !important;
          filter: none !important;
        }

        .ll-music-reopen {
          left: 0.5rem !important;
          right: auto !important;
          bottom: calc(0.5rem + env(safe-area-inset-bottom)) !important;
          padding: 0.48rem 0.7rem !important;
          font-size: 0.56rem !important;
        }

        .ll-feedback-card {
          left: 0.5rem !important;
          bottom: calc(4.15rem + env(safe-area-inset-bottom)) !important;
          width: calc(50% - 0.75rem) !important;
          height: 3.25rem !important;
          padding: 0.28rem !important;
          border-radius: 0.85rem !important;
        }

        .ll-feedback-mobile {
          display: flex !important;
          height: 100%;
          min-width: 0;
          align-items: center;
          gap: 0.4rem;
          padding-right: 1.15rem;
          text-align: left;
        }

        .ll-feedback-mobile img {
          width: 2.5rem;
          height: 2.5rem;
          flex: 0 0 2.5rem;
          border-radius: 0.55rem;
          object-fit: cover;
          object-position: top;
          border: 1px solid rgba(250, 204, 21, 0.45);
          animation: llFeedbackSwap 0.32s ease-out;
        }

        @keyframes llFeedbackSwap {
          from { opacity: 0.35; transform: scale(0.96); }
          to { opacity: 1; transform: scale(1); }
        }

        .ll-feedback-desktop {
          display: none !important;
        }

        .ll-tetris-mobile {
          display: flex !important;
          left: 0.5rem !important;
          bottom: calc(7.72rem + env(safe-area-inset-bottom)) !important;
          width: calc(50% - 0.75rem) !important;
          height: 2.35rem;
          align-items: center;
          justify-content: space-between;
          gap: 0.35rem;
          overflow: hidden;
          border-radius: 0.85rem;
          padding: 0.35rem 0.55rem !important;
        }

        .ll-tetris-mobile[data-feedback="chiuso"] {
          bottom: calc(4.15rem + env(safe-area-inset-bottom)) !important;
        }

        .lalinea-mobile-shell[data-player="chiuso"] .ll-feedback-card {
          bottom: calc(3.55rem + env(safe-area-inset-bottom)) !important;
        }

        .lalinea-mobile-shell[data-player="chiuso"] .ll-tetris-mobile {
          bottom: calc(7.12rem + env(safe-area-inset-bottom)) !important;
        }

        .lalinea-mobile-shell[data-player="chiuso"] .ll-tetris-mobile[data-feedback="chiuso"] {
          bottom: calc(3.55rem + env(safe-area-inset-bottom)) !important;
        }

        .ll-best-sellers {
          right: 0.5rem !important;
          bottom: calc(0.5rem + env(safe-area-inset-bottom)) !important;
          width: calc(50% - 0.75rem) !important;
          max-height: 7.4rem;
          border-radius: 1rem !important;
        }

        .ll-best-sellers-title {
          padding: 0.55rem 1.8rem 0.55rem 0.45rem !important;
          font-size: 0.52rem !important;
          line-height: 1.1 !important;
          letter-spacing: 0.05em !important;
        }

        .ll-best-sellers-grid {
          gap: 0.2rem !important;
          padding: 0.35rem !important;
        }

        .ll-best-sellers-grid button {
          border-radius: 0.7rem !important;
        }

        .ll-best-seller-label {
          min-height: 1.55rem;
          display: flex !important;
          align-items: center;
          justify-content: center;
          padding: 0.22rem 0.12rem !important;
          font-size: 0.43rem !important;
          font-weight: 700 !important;
          line-height: 1.08 !important;
          white-space: normal !important;
          text-align: center;
        }

        .ll-best-sellers-ticker-wrap {
          display: none !important;
        }

        .ll-best-sellers > button[aria-label="Chiudi prodotti più venduti"],
        .ll-music-player > button[aria-label="Chiudi player musicale"] {
          right: 0.28rem !important;
          top: 0.28rem !important;
          height: 1.45rem !important;
          width: 1.45rem !important;
          font-size: 0.65rem !important;
        }
      }


      /* LaLinea 2.0 — micro-interazioni, accessibilità e superfici più pulite */
      .lalinea-neon {
        --ll-yellow: 250 204 21;
        --ll-green: 74 222 128;
        --ll-panel: 9 9 11;
        background-color: #000;
      }

      .lalinea-neon button,
      .lalinea-neon a,
      .lalinea-neon input,
      .lalinea-neon select,
      .lalinea-neon textarea {
        transition:
          border-color 180ms ease,
          background-color 180ms ease,
          color 180ms ease,
          box-shadow 180ms ease,
          transform 120ms ease,
          opacity 180ms ease;
      }

      .lalinea-neon button:focus-visible,
      .lalinea-neon a:focus-visible,
      .lalinea-neon input:focus-visible,
      .lalinea-neon select:focus-visible,
      .lalinea-neon textarea:focus-visible {
        outline: 2px solid rgb(var(--ll-yellow));
        outline-offset: 3px;
      }

      .lalinea-neon button:active {
        transform: scale(0.985);
      }

      .ll-loading-shell {
        position: relative;
        overflow: hidden;
        background:
          radial-gradient(circle at 50% 24%, rgba(250, 204, 21, 0.13), transparent 28%),
          radial-gradient(circle at 18% 72%, rgba(74, 222, 128, 0.07), transparent 26%),
          linear-gradient(180deg, #050505 0%, #000 72%);
      }

      .ll-loading-shell::before {
        content: "";
        position: absolute;
        inset: 0;
        pointer-events: none;
        background-image:
          linear-gradient(rgba(255,255,255,.018) 1px, transparent 1px),
          linear-gradient(90deg, rgba(255,255,255,.018) 1px, transparent 1px);
        background-size: 28px 28px;
        mask-image: linear-gradient(to bottom, black, transparent 78%);
      }

      .ll-loading-card {
        position: relative;
        width: min(92vw, 520px);
        border: 1px solid rgba(250, 204, 21, 0.32);
        border-radius: 2rem;
        background: linear-gradient(180deg, rgba(18,18,18,.78), rgba(0,0,0,.72));
        padding: 2rem 1.4rem 1.5rem;
        box-shadow:
          inset 0 1px 0 rgba(255,255,255,.04),
          0 28px 80px rgba(0,0,0,.58),
          0 0 40px rgba(250,204,21,.08);
        backdrop-filter: blur(14px);
      }

      .ll-loading-brand {
        color: #facc15;
        -webkit-text-stroke: 1.4px rgba(0,0,0,.98);
        text-shadow:
          0 4px 0 #000,
          0 10px 30px rgba(0,0,0,.9),
          0 0 18px rgba(250,204,21,.42);
      }

      .ll-loading-progress {
        position: relative;
        height: 4px;
        overflow: hidden;
        border-radius: 999px;
        background: rgba(255,255,255,.08);
      }

      .ll-loading-progress::after {
        content: "";
        position: absolute;
        inset: 0;
        width: 42%;
        border-radius: inherit;
        background: linear-gradient(90deg, #facc15, #fde68a, #4ade80);
        box-shadow: 0 0 14px rgba(250,204,21,.72);
        animation: llLoadingSweep 1.15s ease-in-out infinite alternate;
      }

      @keyframes llLoadingSweep {
        from { transform: translateX(-10%); }
        to { transform: translateX(150%); }
      }

      .ll-cart-toast {
        animation: llToastIn 220ms ease-out both;
      }

      @keyframes llToastIn {
        from { opacity: 0; transform: translate(-50%, -8px) scale(.98); }
        to { opacity: 1; transform: translate(-50%, 0) scale(1); }
      }

      .ll-shop-intro {
        position: relative;
        overflow: hidden;
        border: 1px solid rgba(250, 204, 21, 0.28);
        border-radius: 2rem;
        background:
          radial-gradient(circle at 92% 0%, rgba(250,204,21,.10), transparent 28%),
          linear-gradient(145deg, rgba(24,24,27,.84), rgba(0,0,0,.92));
        padding: clamp(1.4rem, 3vw, 2.25rem);
        box-shadow: inset 0 1px 0 rgba(255,255,255,.035), 0 20px 55px rgba(0,0,0,.28);
      }

      .ll-shop-intro::after {
        content: "";
        position: absolute;
        top: 0;
        left: 8%;
        right: 8%;
        height: 1px;
        background: linear-gradient(90deg, transparent, rgba(250,204,21,.9), transparent);
      }

      .ll-category-nav button,
      #shop button {
        -webkit-tap-highlight-color: transparent;
      }

      @media (hover: hover) and (pointer: fine) {
        .ll-mobile-category-card:hover {
          border-color: rgba(253,224,71,.95);
          box-shadow: 0 16px 38px rgba(0,0,0,.38), 0 0 24px rgba(250,204,21,.18);
          transform: translateY(-2px);
        }

        #shop button:hover {
          box-shadow: 0 0 24px rgba(250,204,21,.16);
        }
      }

      @media (prefers-reduced-motion: reduce) {
        .lalinea-neon *,
        .lalinea-neon *::before,
        .lalinea-neon *::after {
          animation-duration: 0.001ms !important;
          animation-iteration-count: 1 !important;
          scroll-behavior: auto !important;
          transition-duration: 0.001ms !important;
        }
      }
    `}</style>
  );
}

const PLAYLIST_MUSICALE = [
  { titolo: "Dictature", artista: "Dj Quick x La Hasba22", file: "/canzone.mp3" },
  { titolo: "The Team", artista: "Central Cee", file: "/canzone2.mp3" },
  { titolo: "Ecart - Fumee", artista: "La Hasba", file: "/canzone3.mp3" },
  { titolo: "Bracialet", artista: "Ninho x La Rvfluenze", file: "/canzone4.mp3" },
  { titolo: "Serrure XXX", artista: "La Rvfluenze", file: "/canzone5.mp3" },
  { titolo: "Manualidades", artista: "Skinny Flex", file: "/canzone6.mp3" },
];

const VPN_SECURITY_ROUTES = [
  "Bangkok",
  "Singapore",
  "Tokyo",
  "Zurich",
  "Reykjavik",
  "Toronto",
  "Stockholm",
  "Amsterdam",
  "Seoul",
  "Helsinki",
] as const;

export default function Home() {
  const [popupConsegne, setPopupConsegne] = useState<string | null>(null);
  const [vpnRouteIndex, setVpnRouteIndex] = useState(0);

  useEffect(() => {
    const cambiaRoute = () => {
      setVpnRouteIndex((indiceAttuale) => {
        if (VPN_SECURITY_ROUTES.length <= 1) return 0;
        const salto = 1 + Math.floor(Math.random() * (VPN_SECURITY_ROUTES.length - 1));
        return (indiceAttuale + salto) % VPN_SECURITY_ROUTES.length;
      });
    };

    cambiaRoute();
    const timer = window.setInterval(cambiaRoute, 7000);
    return () => window.clearInterval(timer);
  }, []);

  const vpnRoute = VPN_SECURITY_ROUTES[vpnRouteIndex];

  useEffect(() => {
    const oraItaliana = Number(
      new Intl.DateTimeFormat("it-IT", {
        timeZone: "Europe/Rome",
        hour: "2-digit",
        hourCycle: "h23",
      }).format(new Date())
    );

    if (oraItaliana >= 13 && oraItaliana < 14) {
      setPopupConsegne("CONSEGNE INIZIATE");
    } else if (oraItaliana >= 14 && oraItaliana < 19) {
      setPopupConsegne("LE CONSEGNE RIPRENDONO ALLE ORE 19:00");
    } else if (oraItaliana >= 19 || oraItaliana < 2) {
      setPopupConsegne("CONSEGNE IN CORSO");
    } else {
      setPopupConsegne("LE CONSEGNE RIPRENDONO ALLE ORE 13:00");
    }
  }, []);
  const [carrello, setCarrello] = useState<
    { id: number; nome: string; prezzo: number; quantita: number }[]
  >([]);
  const totalePrecedente = useRef(0);
  const [toastCarrello, setToastCarrello] = useState("");
  const [fotoAnteprima, setFotoAnteprima] = useState<string | null>(null);
  const [tipoAnteprima, setTipoAnteprima] = useState<"img" | "video">("img");
const audioRef = useRef<HTMLAudioElement | null>(null);
const [musicaAvviata, setMusicaAvviata] = useState(false);
const [indiceCanzone, setIndiceCanzone] = useState(0);
const [tempoMusica, setTempoMusica] = useState(0);
const [durataMusica, setDurataMusica] = useState(0);
const riproduciDopoCambio = useRef(false);

useEffect(() => {
  setIndiceCanzone(Math.floor(Math.random() * PLAYLIST_MUSICALE.length));
}, []);

useEffect(() => {
  const audio = audioRef.current;
  if (!audio) return;

  audio.load();
  setTempoMusica(0);
  setDurataMusica(0);

  if (riproduciDopoCambio.current) {
    audio
      .play()
      .then(() => setMusicaAvviata(true))
      .catch(() => setMusicaAvviata(false));
    riproduciDopoCambio.current = false;
  }
}, [indiceCanzone]);

const cambiaCanzonePlayer = (direzione: number) => {
  riproduciDopoCambio.current = true;
  setIndiceCanzone(
    (indiceAttuale) =>
      (indiceAttuale + direzione + PLAYLIST_MUSICALE.length) %
      PLAYLIST_MUSICALE.length
  );
};

const canzoneCasualeSuccessiva = () => {
  riproduciDopoCambio.current = true;
  setIndiceCanzone((indiceAttuale) => {
    if (PLAYLIST_MUSICALE.length <= 1) return indiceAttuale;
    const salto = 1 + Math.floor(Math.random() * (PLAYLIST_MUSICALE.length - 1));
    return (indiceAttuale + salto) % PLAYLIST_MUSICALE.length;
  });
};

const togglePlayerMusicale = () => {
  const audio = audioRef.current;
  if (!audio) return;

  if (audio.paused) {
    audio
      .play()
      .then(() => setMusicaAvviata(true))
      .catch(() => setMusicaAvviata(false));
  } else {
    audio.pause();
    setMusicaAvviata(false);
  }
};

const formattaTempoMusica = (secondi: number) => {
  if (!Number.isFinite(secondi) || secondi < 0) return "0:00";
  const minuti = Math.floor(secondi / 60);
  const resto = Math.floor(secondi % 60);
  return `${minuti}:${String(resto).padStart(2, "0")}`;
};

useEffect(() => {
  const fermaOgniAudio = () => {
    audioRef.current?.pause();

    document
      .querySelectorAll<HTMLMediaElement>("audio, video")
      .forEach((elemento) => elemento.pause());

    setMusicaAvviata(false);
  };

  const quandoLaPaginaScompare = () => {
    if (document.visibilityState === "hidden") {
      fermaOgniAudio();
    }
  };

  document.addEventListener(
    "visibilitychange",
    quandoLaPaginaScompare
  );
  window.addEventListener("pagehide", fermaOgniAudio);
  window.addEventListener("blur", fermaOgniAudio);

  return () => {
    fermaOgniAudio();

    document.removeEventListener(
      "visibilitychange",
      quandoLaPaginaScompare
    );
    window.removeEventListener("pagehide", fermaOgniAudio);
    window.removeEventListener("blur", fermaOgniAudio);
  };
}, [])
const [caricamentoIniziale, setCaricamentoIniziale] = useState(true);
const [recensioniAperte, setRecensioniAperte] = useState(false);
const tutteLeRecensioni = [
  ...Array.from({ length: 39 }, (_, indice) => indice + 1),
  ...Array.from({ length: 11 }, (_, indice) => indice + 41),
];
const feedbackRecenti = [34, 35, 36, 37, 38, 39, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51];
const [ordineRecensioni, setOrdineRecensioni] = useState<number[]>(() =>
  mescolaNumeri(tutteLeRecensioni)
);
const [recensioniVisibili, setRecensioniVisibili] = useState(8);
const [feedbackPopupVisibile, setFeedbackPopupVisibile] = useState(true);
const [ordineFeedback, setOrdineFeedback] = useState<number[]>(() =>
  mescolaNumeri(feedbackRecenti)
);
const [feedbackIndice, setFeedbackIndice] = useState(0);
const feedbackInEvidenza = ordineFeedback[feedbackIndice] ?? feedbackRecenti[0];

const prodottiInEvidenza = [
  "COOKIES X RUNTZ 2.0",
  "LEMON GUMP",
  "GOLD PACK",
  "LEMON CHERRY GELATO",
  "ORANGE PUNCH",
  "TROPICANA COOKIES",
  "TOBACCO BIO SHELDIA X JOINT",
  "GROVE STREET OG",
  "LAUGHING BUDDHA",
  "LEMON STATIC",
];

const [prodottoInEvidenza, setProdottoInEvidenza] = useState(
  prodottiInEvidenza[0]
);

useEffect(() => {
  const aggiornaProdottoInEvidenza = () => {
    const bloccoDueOre = Math.floor(Date.now() / (2 * 60 * 60 * 1000));
    const indice = Math.abs((bloccoDueOre * 9301 + 49297) % prodottiInEvidenza.length);
    setProdottoInEvidenza(prodottiInEvidenza[indice]);
  };

  aggiornaProdottoInEvidenza();
  const timer = window.setInterval(aggiornaProdottoInEvidenza, 60 * 1000);

  return () => window.clearInterval(timer);
}, []);

useEffect(() => {
  if (!feedbackPopupVisibile || ordineFeedback.length === 0) return;

  const timer = window.setInterval(() => {
    setFeedbackIndice((indiceCorrente) => {
      const prossimo = indiceCorrente + 1;
      if (prossimo < ordineFeedback.length) return prossimo;

      setOrdineFeedback((ordineCorrente) => {
        const ultimo = ordineCorrente[ordineCorrente.length - 1];
        let nuovoOrdine = mescolaNumeri(feedbackRecenti);

        if (nuovoOrdine.length > 1 && nuovoOrdine[0] === ultimo) {
          [nuovoOrdine[0], nuovoOrdine[1]] = [nuovoOrdine[1], nuovoOrdine[0]];
        }

        return nuovoOrdine;
      });

      return 0;
    });
  }, 6500);

  return () => window.clearInterval(timer);
}, [feedbackPopupVisibile, ordineFeedback.length]);

useEffect(() => {
  if (!recensioniAperte) return;
  setOrdineRecensioni(mescolaNumeri(tutteLeRecensioni));
  setRecensioniVisibili(8);
}, [recensioniAperte]);

const apriRecensioniComplete = () => {
  setRecensioniAperte(true);
  setOrdineRecensioni(mescolaNumeri(tutteLeRecensioni));
  setRecensioniVisibili(8);

  if (window.matchMedia("(max-width: 767px)").matches) {
    setVistaMobile("dicono-di-noi");
  }

  window.requestAnimationFrame(() => {
    document.getElementById("dicono-di-noi")?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  });
};
const [tetrisAperto, setTetrisAperto] = useState(false);
useEffect(() => {
  if (!tetrisAperto) return;
  const overflow = document.body.style.overflow;
  const focus = document.activeElement as HTMLElement | null;
  document.body.style.overflow = "hidden";
  const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") setTetrisAperto(false); };
  window.addEventListener("keydown", onKey);
  const frame = requestAnimationFrame(() => document.getElementById("lalinea-game-close")?.focus());
  return () => {
    cancelAnimationFrame(frame);
    window.removeEventListener("keydown", onKey);
    document.body.style.overflow = overflow;
    focus?.focus();
  };
}, [tetrisAperto]);

const [tetrisSchedaVisibile, setTetrisSchedaVisibile] = useState(true);
const avviaMusica = () => {
  if (!musicaAvviata && audioRef.current) {
    audioRef.current.play().catch(() => {});
    setMusicaAvviata(true);
  }
};
useEffect(() => {
  const fermaMusica = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setMusicaAvviata(false);
    }
  };

  const gestisciVisibilita = () => {
    if (document.hidden) {
      fermaMusica();
    }
  };

  document.addEventListener("visibilitychange", gestisciVisibilita);
  window.addEventListener("pagehide", fermaMusica);

  return () => {
    document.removeEventListener("visibilitychange", gestisciVisibilita);
    window.removeEventListener("pagehide", fermaMusica);
  };
}, []);
useEffect(() => {
  const timer = setTimeout(() => {
    setCaricamentoIniziale(false);
  }, 2500);

  return () => clearTimeout(timer);
}, []);
useEffect(() => {
  const totaleAttuale = carrello.reduce(
    (totale, item) => totale + item.quantita,
    0
  );

  const aggiunto = totaleAttuale > totalePrecedente.current;
  totalePrecedente.current = totaleAttuale;

  if (!aggiunto) return;

  setToastCarrello("AGGIUNTO AL CARRELLO");
  const timer = window.setTimeout(() => setToastCarrello(""), 1800);
  return () => window.clearTimeout(timer);
}, [carrello]);
useEffect(() => {
  const apriAnteprima = (event: MouseEvent) => {
    const target = event.target as HTMLElement;

    if (target.closest("button, a, header, [data-no-preview='true']")) return;

    const media = target.closest("img, video") as
      | HTMLImageElement
      | HTMLVideoElement
      | null;

    if (!media) return;

    const src = media.currentSrc || media.getAttribute("src");

    if (!src) return;

    setTipoAnteprima(media.tagName.toLowerCase() === "video" ? "video" : "img");
    setFotoAnteprima(src);
  };

  document.addEventListener("click", apriAnteprima);

  return () => {
    document.removeEventListener("click", apriAnteprima);
  };
}, []);

  const [checkoutAperto, setCheckoutAperto] = useState(false);
const [datiCliente, setDatiCliente] = useState({
  nome: "",
  cognome: "",
  email: "",
  telefono: "",
  indirizzo: "",
});
const [orarioConsegna, setOrarioConsegna] = useState("");

const oggiItalia = () =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Rome",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());

const oraItalia = () => {
  const parti = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Europe/Rome",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(new Date());

  const ora =
    parti.find((parte) => parte.type === "hour")?.value ?? "00";

  const minuto =
    parti.find((parte) => parte.type === "minute")?.value ?? "00";

  return `${ora}:${minuto}`;
};

const [dataConsegna, setDataConsegna] = useState(() => oggiItalia());
const [orariOccupati, setOrariOccupati] = useState<string[]>([]);
const [caricamentoOrari, setCaricamentoOrari] = useState(false);
const [erroreSlot, setErroreSlot] = useState("");
const orariConsegnaDisponibili = [
  "13:00",
  "13:30",
  "19:00",
  "19:30",
  "20:00",
  "20:30",
  "21:00",
  "21:30",
  "22:00",
  "22:30",
  "23:00",
  "23:30",
  "00:00",
  "00:30",
  "01:00",
  "01:30",
  "02:00",
];
const [modalitaOrdine, setModalitaOrdine] = useState("");
useEffect(() => {
  if (modalitaOrdine !== "delivery" || !dataConsegna) {
    setOrariOccupati([]);
    setErroreSlot("");
    return;
  }

  const controller = new AbortController();

  const caricaOrariOccupati = async () => {
    setCaricamentoOrari(true);
    setErroreSlot("");

    try {
      const risposta = await fetch(
        `/api/delivery-slots?date=${encodeURIComponent(dataConsegna)}`,
        {
          cache: "no-store",
          signal: controller.signal,
        }
      );

      const risultato = await risposta.json();

      if (!risposta.ok) {
        throw new Error(
          risultato.error || "Impossibile caricare gli orari"
        );
      }

      const occupati = Array.isArray(risultato.occupati)
        ? risultato.occupati
        : [];

      setOrariOccupati(occupati);

      if (orarioConsegna && occupati.includes(orarioConsegna)) {
        setOrarioConsegna("");
      }
    } catch (errore: any) {
      if (errore?.name !== "AbortError") {
        setErroreSlot(
          errore?.message || "Errore durante il caricamento degli orari"
        );
      }
    } finally {
      setCaricamentoOrari(false);
    }
  };

  caricaOrariOccupati();

  return () => controller.abort();
}, [dataConsegna, modalitaOrdine]);

const orarioPrenotabile = (orario: string) => {
  if (orariOccupati.includes(orario)) return false;

  const oggi = oggiItalia();

  if (dataConsegna < oggi) return false;
  if (dataConsegna > oggi) return true;

  return orario > oraItalia();
};
const [codiceSconto, setCodiceSconto] = useState("");
const [scontoPercentuale, setScontoPercentuale] = useState(0);
const [messaggioSconto, setMessaggioSconto] = useState("");
const [codiceTetrisValidato, setCodiceTetrisValidato] = useState("");
const [categoriaAttiva, setCategoriaAttiva] = useState("");  
const [menuAperto, setMenuAperto] = useState(false);
const [playerVisibile, setPlayerVisibile] = useState(true);
const [piuVendutiVisibili, setPiuVendutiVisibili] = useState(true);
const [password, setPassword] = useState("");
const [mostraPassword, setMostraPassword] = useState(false)
const [accessoConsentito, setAccessoConsentito] = useState(false);
const [accessoInCorso, setAccessoInCorso] = useState(false);
const [errorePassword, setErrorePassword] = useState(false);
const [codiceScontoCheckout, setCodiceScontoCheckout] = useState("");
const [erroreSconto, setErroreSconto] = useState("");
const [vistaMobile, setVistaMobile] = useState("home");

useEffect(() => {
  if (!accessoConsentito) return;

  const videoAutoplay = Array.from(
    document.querySelectorAll<HTMLVideoElement>("video[autoplay]")
  );

  if (videoAutoplay.length === 0) return;

  const osservatore = new IntersectionObserver(
    (voci) => {
      voci.forEach((voce) => {
        const video = voce.target as HTMLVideoElement;

        if (voce.isIntersecting && voce.intersectionRatio >= 0.2) {
          if (video.muted) video.play().catch(() => {});
        } else {
          video.pause();
        }
      });
    },
    { threshold: [0, 0.2, 0.6] }
  );

  videoAutoplay.forEach((video) => osservatore.observe(video));

  return () => osservatore.disconnect();
}, [accessoConsentito, categoriaAttiva, vistaMobile]);

const navigazioneMobileAttiva = () =>
  typeof window !== "undefined" &&
  window.matchMedia("(max-width: 767px)").matches;

const apriCategoriaCatalogo = (categoria: string) => {
  const gift = document.querySelector<HTMLDetailsElement>("#gift-card");

  if (categoria === "Gift Card") {
    setCategoriaAttiva("");

    if (navigazioneMobileAttiva()) {
      setVistaMobile("gift-card");
      window.setTimeout(() => {
        const dettaglio = document.querySelector<HTMLDetailsElement>("#gift-card");
        if (dettaglio) dettaglio.open = true;
        document.getElementById("shop")?.scrollTo({ top: 0, behavior: "auto" });
      }, 60);
      return;
    }

    if (gift) gift.open = true;
    document.getElementById("gift-card")?.scrollIntoView({
      behavior: "auto",
      block: "start",
    });
    return;
  }

  setCategoriaAttiva(categoria);
  if (gift) gift.open = false;

  if (navigazioneMobileAttiva()) {
    setVistaMobile("shop");
    window.setTimeout(() => {
      document.getElementById("shop")?.scrollTo({ top: 0, behavior: "auto" });
    }, 60);
    return;
  }

  window.setTimeout(() => {
    document.getElementById("shop")?.scrollIntoView({
      behavior: "auto",
      block: "start",
    });
  }, 50);
};

const apriServizioCatalogo = (id: string) => {
  if (id === "dicono-di-noi") setRecensioniAperte(true);

  if (navigazioneMobileAttiva()) {
    setVistaMobile(id);
    window.setTimeout(() => {
      const sezione = document.getElementById(id);
      if (sezione) sezione.scrollTop = 0;
    }, 60);
    return;
  }

  requestAnimationFrame(() => {
    const sezione = document.getElementById(id);
    if (sezione) {
      sezione.style.scrollMarginTop = `${document.querySelector("header")?.clientHeight || 0}px`;
      sezione.scrollIntoView({ behavior: "auto", block: "start" });
    }
  });
};

const apriCarrelloCatalogo = () => {
  if (navigazioneMobileAttiva()) {
    setVistaMobile("carrello");
    window.setTimeout(() => {
      document.getElementById("shop")?.scrollTo({ top: 0, behavior: "auto" });
    }, 60);
    return;
  }

  document.getElementById("ll-carrello")?.scrollIntoView({
    behavior: "auto",
    block: "start",
  });
};

const apriProdottoCatalogo = (
  categoria: string,
  targetId: string,
  vista: "shop" | "promo" = "shop"
) => {
  if (categoria) setCategoriaAttiva(categoria);

  if (navigazioneMobileAttiva()) {
    setVistaMobile(vista);
    window.setTimeout(() => {
      document.getElementById(targetId)?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }, 90);
    return;
  }

  window.setTimeout(() => {
    document.getElementById(targetId)?.scrollIntoView({
      behavior: "smooth",
      block: "center",
    });
  }, 50);
};
const apriProdottoInEvidenza = () => {
  const destinazioni: Record<
    string,
    { categoria: string; targetId: string; vista?: "shop" | "promo" }
  > = {
    "COOKIES X RUNTZ 2.0": { categoria: "Frozen e Static", targetId: "cookies-x-runtz" },
    "LEMON GUMP": { categoria: "Flowers", targetId: "lemon-gump" },
    "GOLD PACK": { categoria: "", targetId: "gold-pack-card", vista: "promo" },
    "LEMON CHERRY GELATO": { categoria: "Flowers", targetId: "lemon-cherry-gelato" },
    "ORANGE PUNCH": { categoria: "Frozen e Static", targetId: "orange-punch-frozen" },
    "TROPICANA COOKIES": { categoria: "Flowers", targetId: "tropicana-cookies" },
    "TOBACCO BIO SHELDIA X JOINT": { categoria: "Tabacchi biologici", targetId: "tobacco-bio-sheldia" },
    "GROVE STREET OG": { categoria: "Dry Work", targetId: "grove-street-og" },
    "LAUGHING BUDDHA": { categoria: "Flowers", targetId: "laughing-buddha" },
    "LEMON STATIC": { categoria: "Frozen e Static", targetId: "lemon-static-premium" },
  };

  const destinazione = destinazioni[prodottoInEvidenza];
  if (!destinazione) return;

  apriProdottoCatalogo(
    destinazione.categoria,
    destinazione.targetId,
    destinazione.vista ?? "shop"
  );
};

const aggiungiAlCarrello = () => {
    setCarrello((prev) => {
      const esistente = prev.find((item) => item.id === 1);

      if (esistente) {
        return prev.map((item) =>
          item.id === 1
            ? { ...item, quantita: item.quantita + 1 }
            : item
        );
      }

      return [
        ...prev,
        {
          id: 1,
          nome: "Cover iPhone LaLinea UltraResistente",
          prezzo: 10,
          quantita: 1,
        },
      ];
    });
  };
const aggiungiCoverConPunti = () => {
  setCarrello((prev) => {
    const esistente = prev.find(
      (item) => item.id === 10001
    );

    if (esistente) {
      return prev.map((item) =>
        item.id === 10001
          ? {
              ...item,
              quantita: item.quantita + 1,
            }
          : item
      );
    }

    return [
      ...prev,
      {
        id: 10001,
        nome: "Cover LaLinea - Riscatto 500 punti",
        prezzo: 0,
        quantita: 1,
      },
    ];
  });
};
const aggiungiPortachiaviConPunti = () => {
  setCarrello((prev) => {
    const esistente = prev.find((item) => item.id === 10002);

    if (esistente) {
      return prev.map((item) =>
        item.id === 10002
          ? { ...item, quantita: item.quantita + 1 }
          : item
      );
    }

    return [
      ...prev,
      {
        id: 10002,
        nome: "Portachiavi in resina - Riscatto 200 punti",
        prezzo: 0,
        quantita: 1,
      },
    ];
  });
};
const aggiungiCalzeConPunti = () => {
  setCarrello((prev) => {
    const esistente = prev.find((item) => item.id === 10003);

    if (esistente) {
      return prev.map((item) =>
        item.id === 10003
          ? { ...item, quantita: item.quantita + 1 }
          : item
      );
    }

    return [
      ...prev,
      {
        id: 10003,
        nome: "Calze LaLinea - Riscatto 300 punti",
        prezzo: 0,
        quantita: 1,
      },
    ];
  });
};
  const aggiungiGiftCardEuro = (prezzo: number, valore: number) => {
    const id = 200000 + valore;

    setCarrello((prev) => {
      const esistente = prev.find((item) => item.id === id);

      if (esistente) {
        return prev.map((item) =>
          item.id === id
            ? { ...item, quantita: item.quantita + 1 }
            : item
        );
      }

      return [
        ...prev,
        {
          id,
          nome: `Gift Card LaLinea ${prezzo} € - Valore ${valore} €`,
          prezzo,
          quantita: 1,
        },
      ];
    });
  };

  const aggiungiGiftCardConPunti = (
    valore: number,
    punti: number
  ) => {
    const id = 300000 + valore;

    setCarrello((prev) => {
      const esistente = prev.find((item) => item.id === id);

      if (esistente) {
        return prev.map((item) =>
          item.id === id
            ? { ...item, quantita: item.quantita + 1 }
            : item
        );
      }

      return [
        ...prev,
        {
          id,
          nome: `Gift Card LaLinea valore ${valore} € - Riscatto ${punti} punti`,
          prezzo: 0,
          quantita: 1,
        },
      ];
    });
  };
const aggiungiOrangeAlCarrello = (grammi: string, prezzo: number) => {
  const id = `orange-${grammi}`;

  setCarrello((prev) => {
    const esistente = prev.find((item) => String(item.id) === id);

    if (esistente) {
      return prev.map((item) =>
        String(item.id) === id
          ? { ...item, quantita: item.quantita + 1 }
          : item
      );
    }

    return [
      ...prev,
      {
        id: id as any,
        nome: `Orange Punch Frozen ${grammi}`,
        prezzo,
        quantita: 1,
      },
    ];
  });
};
const aggiungiHoneyBananaAcaiMintAlCarrello = (quantita: string, prezzo: number) => {
  const id = `honey-banana-acai-mint-dual-${quantita.toLowerCase().replace(/\s+/g, "-")}`;

  setCarrello((prev) => {
    const esistente = prev.find((item) => String(item.id) === id);

    if (esistente) {
      return prev.map((item) =>
        String(item.id) === id
          ? { ...item, quantita: item.quantita + 1 }
          : item
      );
    }

    return [
      ...prev,
      {
        id: id as any,
        nome: `HONEY BANANA x ACAI MINT 2G DIAMOND + LIVE - ${quantita}`,
        prezzo,
        quantita: 1,
      },
    ];
  });
};

const aggiungiWholeMeltDualAlCarrello = (quantita: string, prezzo: number) => {
  const id = `whole-melt-dual-key-lime-cake-zazaya-${quantita.toLowerCase().replace(/\s+/g, "-")}`;

  setCarrello((prev) => {
    const esistente = prev.find((item) => String(item.id) === id);

    if (esistente) {
      return prev.map((item) =>
        String(item.id) === id
          ? { ...item, quantita: item.quantita + 1 }
          : item
      );
    }

    return [
      ...prev,
      {
        id: id as any,
        nome: `WHOLE MELT DUAL CHAMBER - KEY LIME CAKE x ZAZAYA - ${quantita}`,
        prezzo,
        quantita: 1,
      },
    ];
  });
};

const aggiungiRosinAlCarrello = (grammi: string, prezzo: number) => {
  const id = `rosin-${grammi}`;

  setCarrello((prev) => {
    const esistente = prev.find((item) => String(item.id) === id);

    if (esistente) {
      return prev.map((item) =>
        String(item.id) === id
          ? { ...item, quantita: item.quantita + 1 }
          : item
      );
    }

    return [
      ...prev,
      {
        id: id as any,
        nome: `ROSIN H HOMEMADE 37u ${grammi}`,
        prezzo,
        quantita: 1,
      },
    ];
  });
};
const sourDieselOpzioni = [
  { grammi: "5g", prezzo: 50 },
  { grammi: "10g", prezzo: 80 },
  { grammi: "25g", prezzo: 170 },
  { grammi: "50g", prezzo: 330 },
];
const aggiungiSourDieselAlCarrello = (
  grammi: string,
  prezzo: number
) => {
  const id = `sour-diesel-${grammi}`;

  setCarrello((prev) => {
    const esistente = prev.find(
      (item) => String(item.id) === id
    );

    if (esistente) {
      return prev.map((item) =>
        String(item.id) === id
          ? { ...item, quantita: item.quantita + 1 }
          : item
      );
    }

    return [
      ...prev,
      {
        id: id as any, 
        nome: `Sour Diesel X Forbidden Fruit ${grammi}`,
        prezzo,
        quantita: 1,
      },
    ];
  });
};
const lemonStaticOpzioni = [
  { grammi: "5g", prezzo: 50 },
  { grammi: "10g", prezzo: 80 },
  { grammi: "25g", prezzo: 170 },
  { grammi: "50g", prezzo: 330 },
  { grammi: "100g", prezzo: 550 },
];

const aggiungiLemonStaticAlCarrello = (
  grammi: string,
  prezzo: number
) => {
  const id = `lemon-static-${grammi}`;

  setCarrello((prev) => {
    const esistente = prev.find(
      (item) => String(item.id) === id
    );

    if (esistente) {
      return prev.map((item) =>
        String(item.id) === id
          ? { ...item, quantita: item.quantita + 1 }
          : item
      );
    }

    return [
      ...prev,
      {
        id: id as any,
        nome: `Lemon Static Premium ${grammi}`,
        prezzo,
        quantita: 1,
      },
    ];
  });
};


const aggiungiGorillaAlCarrello = (
  grammi: string,
  prezzo: number
) => {
  const id = `gorilla-${grammi}`;

  setCarrello((prev) => {
    const esistente = prev.find(
      (item) => String(item.id) === id
    );

    if (esistente) {
      return prev.map((item) =>
        String(item.id) === id
          ? { ...item, quantita: item.quantita + 1 }
          : item
      );
    }

    return [
      ...prev,
      {
        id: id as any,
        nome: `#Gorilla Glue 2 CaliSpain ${grammi}`,
        prezzo,
        quantita: 1,
      },
    ];
  });
};
const aggiungiMaradonaAlCarrello = (grammi: string, prezzo: number) => {
  const id = `maradona-${grammi}`;

  setCarrello((prev) => {
    const esistente = prev.find((item) => String(item.id) === id);

    if (esistente) {
      return prev.map((item) =>
        String(item.id) === id
          ? { ...item, quantita: item.quantita + 1 }
          : item
      );
    }

    return [
      ...prev,
      {
        id: id as any,
        nome: `Maradona ${grammi}`,
        prezzo,
        quantita: 1,
      },
    ];
  });
};  
const cambiaQuantita = (id: number, differenza: number) => {
    setCarrello((prev) =>
      prev
        .map((item) =>
          item.id === id
            ? { ...item, quantita: item.quantita + differenza }
            : item
        )
        .filter((item) => item.quantita > 0)
    );
  };

  const eliminaDalCarrello = (id: number) => {
    setCarrello((prev) => prev.filter((item) => item.id !== id));
  };

  const totaleCarrello = carrello.reduce(
    (totale, item) => totale + item.prezzo * item.quantita,
    0
  );
const costoConsegna = 10;

const importoSconto =
  scontoPercentuale < 0
    ? Math.abs(scontoPercentuale)
    : totaleCarrello * (scontoPercentuale / 100);

const totaleCarrelloScontato = Math.max(
  0,
  totaleCarrello - importoSconto
);

const totaleOrdine = totaleCarrelloScontato + costoConsegna;

const applicaCodiceSconto = async () => {
  const codice = codiceSconto.trim().toUpperCase();

  if (!codice) {
    setScontoPercentuale(0);
    setMessaggioSconto("Inserisci un codice sconto");
    return;
  }

  setCodiceTetrisValidato("");

  // CODICI VECCHI GIÀ ESISTENTI
  if (codice === "CESOLOLALINEA26") {
    setScontoPercentuale(10);
    setMessaggioSconto("Codice applicato: sconto del 10%");
    return;
  }

  if (codice === "VIP15") {
    setScontoPercentuale(15);
    setMessaggioSconto("Codice applicato: sconto del 15%");
    return;
  }

  if (codice === "AMICO PAL 20") {
    setScontoPercentuale(20);
    setMessaggioSconto("Codice applicato: sconto del 20%");
    return;
  }

  if (/^LLT(?:5|10)-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(codice)) {
    try {
      const rispostaPremio = await fetch("/api/tetris-reward", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "validate", code: codice }),
      });

      const premio = await rispostaPremio.json();

      if (!rispostaPremio.ok || !premio?.valido) {
        setScontoPercentuale(0);
        setMessaggioSconto(premio?.error || "Premio Tetris non valido o già utilizzato");
        return;
      }

      const valorePremio = Number(premio.valore);
      if (valorePremio !== 5 && valorePremio !== 10) {
        setScontoPercentuale(0);
        setMessaggioSconto("Valore premio Tetris non valido");
        return;
      }

      setCodiceTetrisValidato(codice);
      setScontoPercentuale(-valorePremio);
      setMessaggioSconto(
        `Premio personale LaLinea Tetris verificato: -${valorePremio} € · verrà utilizzato solo alla conferma dell'ordine`
      );
      return;
    } catch {
      setScontoPercentuale(0);
      setMessaggioSconto("Errore durante la verifica del premio Tetris");
      return;
    }
  }

  if (codice === "LALINEA15") {
    setScontoPercentuale(-15);
    setMessaggioSconto("Premio LaLinea applicato: -15 €");
    return;
  }

  if (codice === "LALINEA20") {
    setScontoPercentuale(-20);
    setMessaggioSconto("Premio LaLinea applicato: -20 €");
    return;
  }

  try {
    const risposta = await fetch("/api/discount/validate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ codice }),
    });

    const risultato = await risposta.json();

    if (!risposta.ok || !risultato.valido) {
      setScontoPercentuale(0);
      setMessaggioSconto(
        risultato.error || "Codice sconto non valido"
      );
      return;
    }

    if (risultato.tipo === "percentuale") {
      setScontoPercentuale(Number(risultato.valore));
      setMessaggioSconto(
        `Codice applicato: sconto del ${risultato.valore}%`
      );
    } else {
      setScontoPercentuale(-Number(risultato.valore));
      setMessaggioSconto(
        `Codice applicato: -${risultato.valore} €`
      );
    }
  } catch {
    setScontoPercentuale(0);
    setMessaggioSconto("Errore durante la verifica del codice");
  }
};

 const inviaOrdineTelegram = async () => {
  const prodottiOrdine = carrello
    .map(
      (item) =>
        `${item.nome} x${item.quantita} - ${
          item.prezzo * item.quantita
        } €`
    )
    .join("\n");

  const messaggio = `
NUOVO ORDINE LALINEA

Nome: ${datiCliente.nome}
Cognome: ${datiCliente.cognome}
Email: ${datiCliente.email}
Telefono: ${datiCliente.telefono}
Indirizzo: ${datiCliente.indirizzo || "Non specificato"}

Modalità: ${modalitaOrdine || "Non specificata"}
Data: ${dataConsegna || "Non specificata"}
Orario: ${orarioConsegna || "Non specificato"}

PRODOTTI:
${prodottiOrdine}

Totale prodotti: ${totaleCarrello} €
Consegna: ${costoConsegna} €
TOTALE ORDINE: ${totaleOrdine} €
  `.trim();
  let prenotazioneSlotId: string | null = null;

if (modalitaOrdine === "delivery") {
  if (!dataConsegna || !orarioConsegna) {
    window.alert("Seleziona data e orario di consegna");
    return;
  }

  try {
    const rispostaSlot = await fetch("/api/delivery-slots", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        date: dataConsegna,
        time: orarioConsegna,
      }),
    });

    const risultatoSlot = await rispostaSlot.json();

    if (!rispostaSlot.ok) {
      if (rispostaSlot.status === 409) {
        window.alert(
          "Questo orario è stato appena prenotato. Scegline un altro."
        );

        const aggiorna = await fetch(
          `/api/delivery-slots?date=${encodeURIComponent(dataConsegna)}`,
          { cache: "no-store" }
        );

        if (aggiorna.ok) {
          const datiAggiornati = await aggiorna.json();

          setOrariOccupati(
            Array.isArray(datiAggiornati.occupati)
              ? datiAggiornati.occupati
              : []
          );
        }

        setOrarioConsegna("");
        return;
      }

      window.alert(
        risultatoSlot.error || "Impossibile prenotare questo orario"
      );
      return;
    }

    prenotazioneSlotId = risultatoSlot.id ?? null;
  } catch {
    window.alert(
      "Errore di collegamento durante la prenotazione dell'orario"
    );
    return;
  }
}
const liberaSlotPrenotato = async () => {
  if (!prenotazioneSlotId) return;

  await fetch("/api/delivery-slots", {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      id: prenotazioneSlotId,
    }),
  }).catch(() => {});

  prenotazioneSlotId = null;
};
if (codiceTetrisValidato) {
  try {
    const verificaPremio = await fetch("/api/tetris-reward", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "validate",
        code: codiceTetrisValidato,
      }),
    });

    const risultatoPremio = await verificaPremio.json();
    if (!verificaPremio.ok || !risultatoPremio?.valido) {
      window.alert(
        risultatoPremio?.error ||
          "Il premio Tetris non è più valido. Inserisci un altro codice."
      );
      setScontoPercentuale(0);
      setCodiceTetrisValidato("");
      await liberaSlotPrenotato();
      return;
    }
  } catch {
    window.alert("Errore durante la verifica finale del premio Tetris");
    await liberaSlotPrenotato();
    return;
  }
}

const premiConPunti = carrello.filter((item) =>
      [
        10001,
        10003,
        300060,
        300120,
        300275,
        300550,
        301200,
      ].includes(Number(item.id))
    );

    if (premiConPunti.length > 0) {
      const pinVip = window.prompt(
        "Inserisci il PIN VIP per riscattare i premi"
      );

      if (!pinVip) {
  window.alert("Riscatto annullato: PIN mancante");
  await liberaSlotPrenotato();
  return;
}

      try {
        const rispostaRiscatto = await fetch(
          "/api/vip/redeem",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              telefono: datiCliente.telefono,
              pin: pinVip,
              premi: premiConPunti.map((item) => ({
                id: Number(item.id),
                quantita: item.quantita,
              })),
            }),
          }
        );

        const risultatoRiscatto =
          await rispostaRiscatto.json();

        if (!rispostaRiscatto.ok) {
          window.alert(
            risultatoRiscatto.error ||
              "Impossibile riscattare i premi"
          );
            await liberaSlotPrenotato();
          return;
        }

        window.alert(
          `Premi riscattati. Punti utilizzati: ${risultatoRiscatto.puntiUtilizzati}. Punti rimasti: ${risultatoRiscatto.puntiResidui}`
        );
      } catch {
        window.alert(
          "Errore di collegamento durante il riscatto"
        );
          await liberaSlotPrenotato();
        return;
      }
    }
  if (codiceTetrisValidato) {
    try {
      const consumaPremio = await fetch("/api/tetris-reward", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "consume",
          code: codiceTetrisValidato,
        }),
      });

      const risultatoConsumo = await consumaPremio.json();
      if (!consumaPremio.ok || !risultatoConsumo?.valido) {
        window.alert(
          risultatoConsumo?.error ||
            "Non è stato possibile utilizzare il premio Tetris."
        );
        await liberaSlotPrenotato();
        return;
      }

      setCodiceTetrisValidato("");
    } catch {
      window.alert("Errore durante l'utilizzo del premio Tetris");
      await liberaSlotPrenotato();
      return;
    }
  }

  const testo = encodeURIComponent(messaggio);
await fetch("/api/vip/order", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    telefono: datiCliente.telefono,
    totaleProdotti: totaleCarrello,
    costoConsegna: costoConsegna,
  }),
}).catch(() => {});
  window.location.assign(
    `https://t.me/LaLineaMiOrdini?text=${testo}`
  );
};
if (caricamentoIniziale) {
  return (
    <main className="lalinea-neon ll-loading-shell min-h-screen bg-black text-white flex items-center justify-center px-5">
      <NeonGlobalStyle />

      <section className="ll-loading-card text-center" aria-live="polite">
        <div className="mx-auto mb-5 flex w-fit items-center gap-2 rounded-full border border-green-400/35 bg-green-400/[0.06] px-3 py-1.5 text-[9px] font-black uppercase tracking-[0.22em] text-green-300">
          <span className="h-1.5 w-1.5 rounded-full bg-green-400 shadow-[0_0_10px_rgba(74,222,128,.9)]" />
          Sessione protetta
        </div>

        <p className="text-[10px] font-black uppercase tracking-[0.42em] text-zinc-300 md:text-xs">
          Milano · Official
        </p>

        <h1
          className="ll-loading-brand mt-3 text-[clamp(3.7rem,17vw,6.6rem)] font-black italic uppercase leading-[0.86] tracking-[0.025em]"
          style={{ fontFamily: 'Impact, "Arial Black", sans-serif' }}
        >
          LALINEA
        </h1>

        <p className="mt-4 text-[10px] font-black uppercase tracking-[0.28em] text-yellow-200/90">
          Catalogo privato · Milano
        </p>

        <div className="ll-loading-progress mx-auto mt-7 w-full max-w-[310px]" aria-hidden="true" />

        <div className="mt-5 flex items-center justify-center gap-2 text-[10px] font-black uppercase tracking-[0.18em] text-zinc-300 md:text-xs">
          <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-yellow-300 shadow-[0_0_8px_rgba(250,204,21,.9)]" />
          Sta caricando la tua sessione
        </div>
      </section>
    </main>
  );
}
    if (!accessoConsentito) {
  return (
    <main className="lalinea-neon min-h-screen bg-black text-white flex items-center justify-center px-6">
      <NeonGlobalStyle />
      <div className="relative w-full max-w-md overflow-hidden rounded-3xl border-2 border-yellow-300 bg-black/35 p-8 text-center shadow-[0_0_34px_rgba(250,204,21,0.28)]">
        <img
  src="/logo-lalinea.png"
  alt="LaLinea"
  className="mx-auto mb-4 w-full max-w-[280px] bg-trnsparent object-contain"
/>

        <p
          className="mt-3 text-white uppercase font-black tracking-[0.16em]"
          style={{
            WebkitTextStroke: "0.55px rgba(0,0,0,0.98)",
            textShadow:
              "1px 0 0 #000, -1px 0 0 #000, 0 1px 0 #000, 0 -1px 0 #000, 0 0 8px rgba(250,204,21,0.95), 0 0 18px rgba(250,204,21,0.55)",
          }}
        >
          AREA RISERVATA
        </p>

        <form
          className="mt-8"
          onSubmit={(e) => {
            e.preventDefault();

            if (password === "LaLineaOrGoHome26") {
              setErrorePassword(false);
              setAccessoInCorso(true);

              window.setTimeout(() => {
                setAccessoConsentito(true);
                setAccessoInCorso(false);
              }, 900);
            } else {
              setAccessoInCorso(false);
              setErrorePassword(true);
            }
          }}
        >
          <div className="relative">
  <input
    type={mostraPassword ? "text" : "password"}
    value={password}
    onChange={(e) => {
      setPassword(e.target.value);
      setErrorePassword(false);
    }}
    placeholder="Password"
    className="w-full rounded-xl border border-zinc-700 bg-black/70 px-4 py-4 pr-14 text-center text-white placeholder:text-zinc-400 outline-none shadow-[0_0_14px_rgba(250,204,21,0.14)]"
  />

  <button
    type="button"
    onClick={() => setMostraPassword((prev) => !prev)}
    aria-label={mostraPassword ? "Nascondi password" : "Mostra password"}
    className="absolute right-3 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-lg border border-yellow-400/70 bg-black/80 text-yellow-400 shadow-[0_0_14px_rgba(250,204,21,0.14)]"
  >
    <svg
      viewBox="0 0 64 64"
      className="h-5 w-5"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M32 8 L56 52 H8 Z" />
      <path d="M20 34 C24 28, 40 28, 44 34 C40 40, 24 40, 20 34 Z" />
      <circle cx="32" cy="34" r="4" />
    </svg>
  </button>
</div>

          {errorePassword && (
            <p className="mt-3 text-sm font-bold uppercase text-red-500">
              Password non corretta
            </p>
          )}

          <button
            type="submit"
            disabled={accessoInCorso}
            className="mt-5 w-full rounded-2xl border-2 border-yellow-200 bg-yellow-400 px-6 py-4 font-black uppercase text-emerald-800 shadow-[0_0_24px_rgba(250,204,21,0.55)] transition active:scale-[0.98] disabled:cursor-wait disabled:opacity-80"
          >
            {accessoInCorso ? "Accesso in corso..." : "Entra"}
          </button>
        </form>

        {accessoInCorso && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center rounded-3xl bg-black/95 px-6 backdrop-blur-sm">
            <div className="lalinea-access-pulse relative flex h-28 w-28 items-center justify-center overflow-hidden rounded-full border-2 border-yellow-200 bg-yellow-400/10 shadow-[0_0_30px_rgba(250,204,21,0.65)]">
              <div className="absolute inset-3 rounded-full border border-yellow-300/70 shadow-[0_0_14px_rgba(250,204,21,0.14)]" />
              <div className="lalinea-access-scan absolute left-3 right-3 h-[2px] bg-yellow-200 shadow-[0_0_14px_rgba(250,204,21,1)]" />
              <span className="text-xs font-black uppercase tracking-[0.22em] text-yellow-300">
                LaLinea
              </span>
            </div>

            <p className="mt-6 text-lg font-black uppercase tracking-[0.2em] text-yellow-300">
              Accesso autorizzato
            </p>
            <p className="mt-2 text-xs font-bold uppercase tracking-[0.18em] text-zinc-300">
              Apertura area riservata
            </p>
          </div>
        )}
      </div>
    </main>
  );
}

return (
    <main
      id="lalinea-pagina"
      data-vista-mobile={vistaMobile}
      onClick={avviaMusica}
      className="lalinea-neon lalinea-mobile-shell min-h-screen text-white"
    >
      <NeonGlobalStyle />
      {toastCarrello && (
        <div
          role="status"
          aria-live="polite"
          className="ll-cart-toast fixed left-1/2 top-[5.6rem] z-[12000] -translate-x-1/2 rounded-full border border-green-300/70 bg-black/95 px-4 py-2 text-[10px] font-black uppercase tracking-[0.16em] text-green-300 shadow-[0_0_22px_rgba(74,222,128,.28)] backdrop-blur-md md:top-5 md:text-xs"
        >
          ✓ {toastCarrello}
        </div>
      )}
      {popupConsegne && (
        <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/80 px-4">
          <div
            role="dialog"
            aria-modal="true"
            className="relative w-full max-w-lg border-2 border-yellow-400 bg-zinc-950 px-6 py-12 text-center shadow-2xl rounded-2xl"
          >
            <button
              type="button"
              onClick={(evento) => {
                evento.stopPropagation();
                setPopupConsegne(null);
              }}
              aria-label="Chiudi popup"
              className="absolute right-4 top-4 flex h-12 w-12 items-center justify-center rounded-full border-2 border-yellow-400 text-3xl font-black text-yellow-400 shadow-[0_0_14px_rgba(250,204,21,0.14)]"
            >
              ×
            </button>

            <p className="text-sm font-black uppercase tracking-[0.3em] text-yellow-400">
              LALINEA
            </p>

            <h2 className="mt-5 text-3xl font-black uppercase text-white md:text-4xl">
              {popupConsegne}
            </h2>

            <button
              type="button"
              onClick={(evento) => {
                evento.stopPropagation();
                setPopupConsegne(null);
              }}
              className="mt-8 bg-yellow-400 px-8 py-4 font-black uppercase text-black"
            >
              Entra nel sito
            </button>
          </div>
        </div>
      )}
  <a
  href="/vip"
  className="absolute right-20 top-[18px] z-[9999] rounded-full bg-yellow-400 px-3 py-2 text-[10px] font-black uppercase tracking-widest text-black md:right-4 md:top-4 md:px-4 md:py-3 md:text-xs"
>
  AREA VIP
</a>
 

{feedbackPopupVisibile && (
  <div
    data-player={playerVisibile ? "aperto" : "chiuso"}
    className="ll-feedback-card ll-featured-product fixed bottom-[17.5rem] left-3 z-[9998] w-[calc(46%-12px)] overflow-hidden rounded-2xl border border-yellow-300 bg-black/95 p-2 text-left shadow-[0_0_20px_rgba(250,204,21,0.28)] md:bottom-4 md:left-4 md:h-auto md:w-[240px]"
    aria-label="Ultimi feedback LaLinea"
  >
    <span className="pointer-events-none absolute inset-x-0 top-0 flex h-[3px]">
      <span className="flex-1 bg-yellow-300" />
      <span className="flex-1 bg-green-400" />
      <span className="flex-1 bg-yellow-300" />
    </span>

    <button
      type="button"
      onClick={(evento) => {
        evento.stopPropagation();
        setFeedbackPopupVisibile(false);
      }}
      className="absolute right-1 top-1 z-20 flex h-5 w-5 items-center justify-center rounded-full border border-yellow-400 bg-black text-[9px] font-black text-yellow-300 md:right-1.5 md:top-1.5 md:h-6 md:w-6 md:text-xs"
      aria-label="Chiudi ultimi feedback"
    >
      ×
    </button>

    <button
      type="button"
      onClick={(evento) => {
        evento.stopPropagation();
        apriRecensioniComplete();
      }}
      className="ll-feedback-mobile w-full md:hidden"
      aria-label={`Apri feedback ${feedbackInEvidenza}`}
    >
      <img
        key={feedbackInEvidenza}
        src={`/reviews/review${feedbackInEvidenza}.jpg`}
        alt={`Ultimo feedback ${feedbackInEvidenza}`}
        loading="eager"
        decoding="async"
        onError={(evento) => {
          evento.currentTarget.src = "/reviews/review33.jpg";
        }}
      />
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-1">
          <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-green-400 shadow-[0_0_7px_rgba(74,222,128,0.9)]" />
          <span className="block truncate text-[7px] font-black uppercase tracking-[0.10em] text-yellow-300">
            ULTIMI FEEDBACK
          </span>
        </span>
        <span className="mt-1 flex items-center justify-between gap-1 text-[8px] font-black uppercase text-white">
          <span className="truncate">Feedback #{feedbackInEvidenza}</span>
          <span className="shrink-0 text-[6px] text-zinc-400">
            {feedbackIndice + 1}/{ordineFeedback.length}
          </span>
        </span>
        <span className="mt-0.5 block truncate text-[6px] font-bold uppercase tracking-[0.08em] text-green-300">
          Cambia automaticamente · tocca per vederli tutti
        </span>
      </span>
    </button>

    <div className="ll-feedback-desktop md:block">
      <div className="pr-7">
        <div className="flex items-center gap-1.5">
          <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-green-400 shadow-[0_0_8px_rgba(74,222,128,0.9)]" />
          <p className="text-[10px] font-black uppercase tracking-[0.14em] text-yellow-300">
            ULTIMI FEEDBACK
          </p>
        </div>
        <p className="mt-0.5 text-[9px] font-bold uppercase tracking-[0.08em] text-zinc-400">
          Rotazione automatica senza ripetizioni
        </p>
      </div>

      <div className="mt-2 overflow-hidden rounded-xl border border-zinc-700 bg-zinc-950">
        <button
          type="button"
          onClick={(evento) => {
            evento.stopPropagation();
            apriRecensioniComplete();
          }}
          className="block w-full"
          aria-label="Apri tutti i feedback"
        >
          <img
            key={feedbackInEvidenza}
            src={`/reviews/review${feedbackInEvidenza}.jpg`}
            alt={`Ultimo feedback ${feedbackInEvidenza}`}
            loading="eager"
            decoding="async"
            onError={(evento) => {
              evento.currentTarget.src = "/reviews/review33.jpg";
            }}
            className="h-[130px] w-full object-cover object-top"
          />
        </button>
      </div>

      <div className="mt-1.5 flex items-center justify-between gap-2">
        <span className="text-[9px] font-black uppercase tracking-[0.10em] text-white">
          Feedback #{feedbackInEvidenza}
        </span>
        <span className="text-[9px] font-black uppercase tracking-[0.10em] text-green-300">
          {feedbackIndice + 1}/{ordineFeedback.length} · VEDI TUTTI
        </span>
      </div>
    </div>
  </div>
)}

<button
  type="button"
  data-feedback={feedbackPopupVisibile ? "aperto" : "chiuso"}
  onClick={(evento) => {
    evento.stopPropagation();
    setTetrisAperto(true);
  }}
  className="ll-tetris-mobile fixed z-[9998] hidden border border-yellow-300 bg-black/95 text-left shadow-[0_0_16px_rgba(250,204,21,0.22)] md:hidden"
  aria-label="Apri LaLinea Game"
>
  <span className="absolute inset-x-0 top-0 flex h-[2px]">
    <span className="flex-1 bg-cyan-400" />
    <span className="flex-1 bg-fuchsia-400" />
    <span className="flex-1 bg-yellow-300" />
    <span className="flex-1 bg-green-400" />
  </span>
  <span className="min-w-0 flex-1">
    <span className="block truncate text-[7px] font-black uppercase tracking-[0.10em] text-yellow-300">
      GIOCA AL NUOVO GIOCO
    </span>
    <span className="mt-0.5 block truncate text-[9px] font-black uppercase text-white">
      LALINEA GAME · MILANO
    </span>
  </span>
  <span className="shrink-0 rounded-full border border-green-400/70 px-1.5 py-1 text-[6px] font-black uppercase text-green-300">
    GIOCA
  </span>
</button>

{!playerVisibile && (
  <button
    type="button"
    onClick={(evento) => {
      evento.stopPropagation();
      setPlayerVisibile(true);
    }}
    className="ll-music-reopen fixed bottom-3 left-3 z-[9999] rounded-full border border-yellow-400 bg-black/95 px-4 py-3 text-xs font-black uppercase tracking-widest text-yellow-300 shadow-[0_0_18px_rgba(250,204,21,0.22)] md:bottom-4 md:left-4"
    aria-label="Apri player musicale"
  >
    ♫ MUSICA
  </button>
)}

<div
  style={{ display: playerVisibile ? undefined : "none" }}
  onClick={(evento) => evento.stopPropagation()}
  className="ll-music-player fixed bottom-3 left-3 z-[9999] w-[calc(46%-12px)] min-w-0 overflow-hidden rounded-2xl border border-yellow-400 bg-black/95 text-white shadow-2xl md:bottom-4 md:left-1/2 md:w-[calc(100%-2rem)] md:max-w-md md:-translate-x-1/2"
>
  <button
    type="button"
    onClick={() => {
      audioRef.current?.pause();
      setMusicaAvviata(false);
      setPlayerVisibile(false);
    }}
    className="absolute left-1 top-1/2 z-20 flex h-4 w-4 -translate-y-1/2 items-center justify-center rounded-full border border-yellow-400/70 bg-black text-[8px] font-black leading-none text-yellow-300 md:left-auto md:right-2 md:top-2 md:h-7 md:w-7 md:translate-y-0 md:text-sm md:shadow-[0_0_12px_rgba(250,204,21,0.30)]"
    aria-label="Chiudi player musicale"
  >
    ×
  </button>

  <div className="ll-music-title flex min-h-[72px] items-center justify-between gap-2 rounded-t-2xl border-b border-yellow-400/80 bg-black px-4 py-3 pr-11 text-[11px] font-bold uppercase leading-relaxed tracking-[0.12em] text-white md:min-h-[64px] md:px-5 md:pr-12 md:text-xs">
    <span className="block min-w-0">
      LA SELEZIONE MUSICALE
      <br />
      DELLA SETTIMANA
    </span>
    <span className="ll-music-shuffle shrink-0 rounded-full border border-yellow-400/60 bg-yellow-400/10 px-2 py-1 text-[8px] font-black tracking-wider text-yellow-300">
      ⤨ RANDOM
    </span>
  </div>

  <div className="ll-music-body rounded-b-2xl p-3 md:p-4">
    <div className="flex min-w-0 items-start justify-between gap-2">
      <div className="min-w-0">
        <p
          data-titolo-canzone
          className="ll-music-track truncate text-sm font-black uppercase text-white"
        >
          {PLAYLIST_MUSICALE[indiceCanzone].titolo}
        </p>
        <p className="ll-music-artist truncate text-[10px] font-bold uppercase tracking-wide text-yellow-300">
          {PLAYLIST_MUSICALE[indiceCanzone].artista}
        </p>
      </div>
      <span className="ll-music-counter shrink-0 rounded-full border border-zinc-700 px-2 py-1 text-[9px] font-black text-zinc-300">
        {indiceCanzone + 1}/{PLAYLIST_MUSICALE.length}
      </span>
    </div>

    <audio
      ref={audioRef}
      src={PLAYLIST_MUSICALE[indiceCanzone].file}
      preload="metadata"
      className="hidden"
      onPlay={() => setMusicaAvviata(true)}
      onPause={() => setMusicaAvviata(false)}
      onLoadedMetadata={(evento) =>
        setDurataMusica(evento.currentTarget.duration || 0)
      }
      onTimeUpdate={(evento) =>
        setTempoMusica(evento.currentTarget.currentTime || 0)
      }
      onEnded={canzoneCasualeSuccessiva}
    />

    <div className="ll-music-progress mt-2 flex items-center gap-2">
      <span className="w-8 text-right text-[9px] font-bold tabular-nums text-zinc-400">
        {formattaTempoMusica(tempoMusica)}
      </span>
      <input
        type="range"
        min="0"
        max={durataMusica || 0}
        step="0.1"
        value={Math.min(tempoMusica, durataMusica || 0)}
        onChange={(evento) => {
          const nuovoTempo = Number(evento.target.value);
          if (audioRef.current) audioRef.current.currentTime = nuovoTempo;
          setTempoMusica(nuovoTempo);
        }}
        className="min-w-0 flex-1 accent-yellow-400"
        aria-label="Posizione brano"
      />
      <span className="w-8 text-[9px] font-bold tabular-nums text-zinc-400">
        {formattaTempoMusica(durataMusica)}
      </span>
    </div>

    <div className="ll-music-controls mt-2 flex items-center justify-center gap-3">
      <button
        type="button"
        onClick={() => cambiaCanzonePlayer(-1)}
        className="flex h-10 w-10 items-center justify-center rounded-full border border-yellow-400/70 bg-black text-base font-black text-yellow-300 shadow-[0_0_10px_rgba(250,204,21,0.18)] transition active:scale-90"
        aria-label="Brano precedente"
      >
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M7 5v14M19 6.5 10.5 12 19 17.5V6.5Z" fill="currentColor" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
        </svg>
      </button>

      <button
        type="button"
        onClick={togglePlayerMusicale}
        className="ll-music-play flex h-12 w-12 items-center justify-center rounded-full bg-yellow-400 text-lg font-black text-black shadow-[0_0_20px_rgba(250,204,21,0.36)] transition active:scale-90"
        aria-label={musicaAvviata ? "Metti in pausa" : "Riproduci"}
      >
        {musicaAvviata ? (
          <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <rect x="6" y="5" width="4" height="14" rx="1" />
            <rect x="14" y="5" width="4" height="14" rx="1" />
          </svg>
        ) : (
          <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M8 5.5v13L18.5 12 8 5.5Z" />
          </svg>
        )}
      </button>

      <button
        type="button"
        onClick={() => cambiaCanzonePlayer(1)}
        className="flex h-10 w-10 items-center justify-center rounded-full border border-yellow-400/70 bg-black text-base font-black text-yellow-300 shadow-[0_0_10px_rgba(250,204,21,0.18)] transition active:scale-90"
        aria-label="Brano successivo"
      >
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M17 5v14M5 6.5 13.5 12 5 17.5V6.5Z" fill="currentColor" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
        </svg>
      </button>
    </div>
  </div>
</div>

      {fotoAnteprima && (
  <div
    className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/90 p-4"
    onClick={() => setFotoAnteprima(null)}
  >
    <button
      type="button"
      onClick={() => setFotoAnteprima(null)}
      className="absolute right-4 top-4 z-[10000] text-4xl font-black text-white"
    >
      ×
    </button>

    <div
      className="max-h-[90vh] max-w-[95vw]"
      onClick={(e) => e.stopPropagation()}
    >
      {tipoAnteprima === "video" ? (
        <video
          src={fotoAnteprima}
          controls
          autoPlay
          className="max-h-[90vh] max-w-[95vw] object-contain"
         preload="metadata"/>
      ) : (
        <img
          src={fotoAnteprima}
          alt="Anteprima"
          className="max-h-[90vh] max-w-[95vw] object-contain"
        />
      )}
    </div>
  </div>
)}
{/* VIDEO BANNER */}
<section className="ll-hero-banner relative w-full overflow-hidden">
  <video
  autoPlay
  muted
  loop
  playsInline
  preload="auto"
  className="block w-full h-[220px] sm:h-[300px] md:h-[420px] object-cover"
>
  <source src="/banner.mp4" type="video/mp4" />
</video>

  <div className="pointer-events-none absolute inset-0 bg-black/20" />
</section>
   {/* HEADER */}
<header className="sticky top-0 z-50 border-b border-yellow-400/30 bg-black/95 backdrop-blur">
  <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 md:h-auto md:px-6 md:py-4">
    <img
      src="/logo-lalinea.png"
      alt="LaLinea"
      data-no-preview="true"
      className="h-14 w-auto object-contain md:h-40"
    />

    <button
      type="button"
      onClick={() => setMenuAperto(true)}
      aria-label="Apri menu"
      aria-haspopup="dialog"
      aria-expanded={menuAperto}
      className="h-11 rounded-full border border-yellow-400 px-4 font-black text-yellow-400 md:hidden shadow-[0_0_14px_rgba(250,204,21,0.14)]"
    >
      ☰ MENU
    </button><button
  type="button"
  onClick={() => {
    setMenuAperto(false);
    apriCarrelloCatalogo();
  }}
  aria-label="Apri carrello"
  className="flex h-11 items-center gap-2 rounded-xl border-2 border-green-300 bg-green-500 px-4 font-black text-black shadow-lg shadow-green-500/30 md:hidden"
>
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.5"
    className="h-6 w-6"
    aria-hidden="true"
  >
    <circle cx="9" cy="20" r="1" />
    <circle cx="19" cy="20" r="1" />
    <path d="M3 4h2l2.4 11.2a2 2 0 0 0 2 1.6h7.8a2 2 0 0 0 2-1.6L21 8H7" />
  </svg>

  <span>CARRELLO</span>

  <span className="rounded-full bg-black px-2 py-0.5 text-xs text-green-400">
    {carrello.reduce((totale, item) => totale + item.quantita, 0)}
  </span>
</button>

    <nav className="hidden flex-wrap items-center justify-end gap-6 text-lg font-black tracking-widest md:flex">
      <button type="button" onClick={() => setMenuAperto(true)} className="hover:text-yellow-400">
        SHOP ▾
      </button>
      {[
        ["tracking", "TRACKING"],
        ["promo", "LE PROMO"],
        ["dicono-di-noi", "DICONO DI NOI"],
        ["point", "I NOSTRI POINT"],
        ["delivery", "DELIVERY"],
        ["contatti", "CONTATTI"],
      ].map(([id, titolo]) => (
        <a key={id} href={`#${id}`} onClick={() => {
          if (id === "dicono-di-noi") setRecensioniAperte(true);
        }} className="hover:text-yellow-400">
          {titolo}
        </a>
      ))}
    </nav>
  </div>
</header>

<div className="ll-mobile-home md:hidden" aria-label="Catalogo mobile LaLinea">
  <div className="mb-3 flex items-end justify-between gap-3">
    <div>
      <p className="ll-catalog-kicker text-[10px] font-black uppercase tracking-[0.32em] text-yellow-400">
        LALINEA / CATALOGO
      </p>
      <h1 className="mt-1 text-[1.55rem] font-black uppercase leading-none tracking-[-0.03em] text-white">
        Scegli la categoria
      </h1>
    </div>
    <div className="flex flex-col items-end gap-1">
      <div
        className="ll-vpn-security"
        aria-label={`Indicatore grafico VPN simulato: ${vpnRoute}, sicurezza alta`}
        title="Indicatore grafico: percorso VPN simulato"
      >
        <span className="ll-vpn-orb" aria-hidden="true">
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
            <circle cx="12" cy="12" r="9" />
            <path d="M3.5 9h17M3.5 15h17M12 3c2.2 2.4 3.3 5.4 3.3 9S14.2 18.6 12 21M12 3C9.8 5.4 8.7 8.4 8.7 12S9.8 18.6 12 21" />
          </svg>
          <span className="ll-vpn-lock">
            <svg viewBox="0 0 24 24" className="h-2.5 w-2.5" fill="none" stroke="currentColor" strokeWidth="2.4">
              <rect x="5" y="10" width="14" height="10" rx="2" />
              <path d="M8 10V7a4 4 0 0 1 8 0v3" />
            </svg>
          </span>
        </span>
        <span className="ll-vpn-copy">
          <span className="ll-vpn-label">VPN ROUTE</span>
          <span className="ll-vpn-city">{vpnRoute}</span>
          <span className="ll-vpn-high">
            <span className="ll-vpn-high-dot" aria-hidden="true" />
            SECURITY: HIGH
            <span className="ll-vpn-demo">VISUAL</span>
          </span>
        </span>
      </div>
    </div>
  </div>

  <div className="ll-mobile-category-grid">
    {[
      { nome: "Premium Filtred", immagine: "/products/premium-filtred/voltus1.jpg" },
      { nome: "Frozen e Static", immagine: "/products/frozen-static/arancia1.jpeg" },
      { nome: "Rosin & Pen", immagine: "/products/rosin/etere1.jpg" },
      { nome: "Flowers", immagine: "/products/flowers/lmg2.jpg" },
      { nome: "Dry Work", immagine: "/products/Dry work/cj2.jpg" },
      { nome: "White", immagine: "/products/other/soda2.jpg" },
      { nome: "Tabacchi biologici", immagine: "/products/other/tab2.jpg", fallback: "/products/other/tab3.jpg" },
      { nome: "Gadget", immagine: "/cover1.jpg" },
      { nome: "Abbigliamento", immagine: "/products/abbigliamento/calza1.jpg" },
    ].map(({ nome, immagine, fallback }) => (
      <button
        key={`mobile-home-${nome}`}
        type="button"
        onClick={() => apriCategoriaCatalogo(nome)}
        className="ll-mobile-category-card group text-left"
        aria-label={`Apri categoria ${nome}`}
      >
        <img
          src={immagine}
          alt=""
          decoding="async"
          draggable={false}
          data-no-preview="true"
          onError={(evento) => {
            if (!fallback) return;
            const immagineErrore = evento.currentTarget;
            if (immagineErrore.dataset.fallbackUsato === "true") return;
            immagineErrore.dataset.fallbackUsato = "true";
            immagineErrore.src = fallback;
          }}
          className="absolute inset-0 h-full w-full object-cover opacity-80 transition duration-300 group-active:scale-105"
        />
        <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black via-black/25 to-transparent" />
        <span className="pointer-events-none absolute inset-x-0 bottom-0 p-2.5">
          <span className="block text-[10px] font-black uppercase leading-[1.05] tracking-[0.02em] text-white sm:text-xs">
            {nome}
          </span>
          <span className="mt-1 block text-[8px] font-black uppercase tracking-[0.16em] text-yellow-300">
            Apri →
          </span>
        </span>
      </button>
    ))}
  </div>

  <p className="mt-2 text-center text-[9px] font-bold uppercase tracking-[0.16em] text-zinc-500">
    Tocca una categoria · servizi dal menu
  </p>
</div>

<div className="ll-mobile-toolbar md:hidden">
  <button
    type="button"
    onClick={() => {
      setVistaMobile("home");
      setCategoriaAttiva("");
    }}
    className="flex h-10 shrink-0 items-center rounded-xl border border-yellow-300/60 bg-black px-3 text-[10px] font-black uppercase tracking-wide text-yellow-300"
  >
    ← Home
  </button>

  <p className="min-w-0 flex-1 truncate text-center text-[11px] font-black uppercase tracking-[0.08em] text-white">
    {vistaMobile === "shop"
      ? categoriaAttiva
      : ({
          "gift-card": "Gift Card",
          carrello: "Carrello",
          promo: "Le promo",
          tracking: "Tracking",
          "dicono-di-noi": "Dicono di noi",
          point: "I nostri point",
          delivery: "Delivery",
          contatti: "Contatti",
        } as Record<string, string>)[vistaMobile] || "LaLinea"}
  </p>

  <button
    type="button"
    onClick={apriCarrelloCatalogo}
    className="flex h-10 shrink-0 items-center gap-1 rounded-xl bg-green-400 px-3 text-[10px] font-black uppercase text-black shadow-[0_0_16px_rgba(74,222,128,.28)]"
  >
    🛒 {carrello.reduce((totale, item) => totale + item.quantita, 0)}
  </button>
</div>

{menuAperto && (
  <dialog
    ref={(elemento) => {
      if (elemento && !elemento.open) elemento.showModal();
    }}
    onCancel={() => setMenuAperto(false)}
    onClose={() => setMenuAperto(false)}
    onClick={(evento) => {
      if (evento.target === evento.currentTarget) evento.currentTarget.close();
    }}
    aria-label="Menu LaLinea"
    className="m-auto w-[calc(100%-2rem)] max-w-lg max-h-[82dvh] overflow-x-hidden overflow-y-auto overscroll-contain rounded-2xl border border-yellow-400 bg-zinc-950 p-4 pb-[calc(1rem+env(safe-area-inset-bottom))] text-white backdrop:bg-black/80 shadow-[0_0_14px_rgba(250,204,21,0.14)] sm:max-h-[90dvh]"
  >
    <div className="mb-4 flex items-center justify-between gap-3">
      <h2 className="text-xl font-black text-yellow-400">MENU LALINEA</h2>
      <form method="dialog">
        <button aria-label="Chiudi menu" className="h-11 w-11 rounded-full border border-zinc-600 text-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">×</button>
      </form>
    </div>

    <p className="mb-3 text-sm font-black text-yellow-400">CATEGORIE SHOP</p>
    <div className="grid grid-cols-2 gap-2">
      {[
        "Premium Filtred", "Frozen e Static", "Rosin & Pen", "Flowers",
        "Dry Work", "White", "Tabacchi biologici", "Gadget", "Abbigliamento", "Gift Card",
      ].map((categoria) => (
        <button
          key={categoria}
          type="button"
          onClick={(evento) => {
            evento.currentTarget.closest("dialog")?.close();
            setMenuAperto(false);
            apriCategoriaCatalogo(categoria);
          }}
          className="min-h-12 min-w-0 rounded-lg border border-zinc-700 bg-black px-3 py-3 text-left text-xs font-black uppercase [overflow-wrap:anywhere] hover:border-yellow-400 sm:text-sm shadow-[0_0_14px_rgba(250,204,21,0.14)]"
        >
          {categoria}
          {categoria === "Gift Card" && <span className="ml-2 inline-block rounded-full bg-yellow-400 px-2 py-1 text-[10px] text-black">NUOVA</span>}
        </button>
      ))}
    </div>

    <p className="mb-3 mt-5 text-sm font-black text-yellow-400">SERVIZI</p>
    <div className="grid grid-cols-2 gap-2">
      {[
        ["promo", "Le promo"], ["tracking", "Tracking"],
        ["dicono-di-noi", "Recensioni"], ["point", "I nostri point"],
        ["delivery", "Delivery"], ["contatti", "Contatti"],
      ].map(([id, titolo]) => (
        <button key={id} type="button" onClick={(evento) => {
          evento.currentTarget.closest("dialog")?.close();
          setMenuAperto(false);
          apriServizioCatalogo(id);
        }} className="min-h-11 rounded-lg border border-zinc-700 bg-black px-3 py-3 text-left text-sm font-bold hover:border-yellow-400 shadow-[0_0_14px_rgba(250,204,21,0.14)]">
          {titolo}
        </button>
      ))}
    </div>

    <div className="sticky bottom-0 z-20 mt-2 grid grid-cols-2 gap-2 border-t border-yellow-400/20 bg-zinc-950 pt-2 pb-[env(safe-area-inset-bottom)]">
      <button type="button" onClick={(evento) => {
        evento.currentTarget.closest("dialog")?.close();
        setMenuAperto(false);
        setTetrisAperto(true);
      }} className="min-h-11 rounded-lg border border-yellow-400/70 bg-black px-3 py-3 text-left text-sm font-bold text-yellow-300 shadow-[0_0_14px_rgba(250,204,21,0.14)]">Gioca a LaLinea Game</button>
      <a href="/vip" className="flex min-h-11 items-center rounded-lg bg-yellow-400 px-3 py-3 text-sm font-black text-black shadow-[0_0_14px_rgba(250,204,21,0.18)]">Area VIP</a>
    </div>
  </dialog>
)}
      {/* MARQUEE */}
      <section className="overflow-hidden bg-yellow-400 py-4 text-black">
        <div className="whitespace-nowrap text-center text-sm font-black tracking-[0.3em]">
          LALINEA • MILANO • STREET CULTURE • LALINEA • MILANO • STREET CULTURE •
        </div>
      </section>
      {/* LE PROMO */}
<section id="promo" className="border-b border-zinc-800 bg-black">
  <div className="mx-auto max-w-7xl px-6 py-24">

    <p className="font-bold uppercase tracking-[0.3em] text-yellow-400">
      LaLinea Promo
    </p>

    <h2 className="mt-3 text-4xl font-black uppercase text-white md:text-5xl">
      LE PROMO
    </h2>

    <p className="mt-4 max-w-3xl text-zinc-400">
      Pack promozionali LaLinea con più prodotti selezionati a prezzo speciale.
    </p>

    <div className="mt-12 grid grid-cols-1 gap-6 lg:grid-cols-3">

      {/* SILVER PACK */}
      <div id="silver-pack-card"className="flex flex-col border border-zinc-700 bg-zinc-950 p-6 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">

        <video
  src="/products/promo/silver.mp4"
  autoPlay
  muted
  loop
  playsInline
  className="mb-6 aspect-square w-full border border-zinc-800 object-cover rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
 preload="metadata"/>
        <p className="text-sm font-black uppercase tracking-[0.3em] text-zinc-400">
          Promo Pack
        </p>

        <h3 className="mt-3 text-3xl font-black uppercase text-white">
          SILVER PACK
        </h3>

        <div className="mt-6 flex-1 space-y-2 text-zinc-300">
          <p>• 3.5 Orange Punch</p>
          <p>• 3.5 Tropicana Cookies</p>
          <p>• 1 Rosin Home Made Lamponi 37ü</p>
          <p>• 1 Pack cartine + Filtri Raw</p>
          <p>• 1 Portachiavi LaLinea</p>
        </div>

        <p className="mt-8 text-4xl font-black lalinea-price-neon">
          50 €
        </p>

        <button
          type="button"
          onClick={() => {
            const id = "silver-pack";

            setCarrello((prev) => {
              const esistente = prev.find(
                (item) => String(item.id) === id
              );

              if (esistente) {
                return prev.map((item) =>
                  String(item.id) === id
                    ? { ...item, quantita: item.quantita + 1 }
                    : item
                );
              }

              return [
                ...prev,
                {
                  id: id as any,
                  nome: "SILVER PACK",
                  prezzo: 50,
                  quantita: 1,
                },
              ];
            });
          }}
          className="mt-6 w-full border border-yellow-400 bg-yellow-400 px-5 py-4 font-black uppercase text-black rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
        >
          Aggiungi al carrello
        </button>
      </div>

      {/* GOLD PACK */}
      <div id="gold-pack-card" className="flex flex-col border border-yellow-400/60 bg-zinc-950 p-6 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
      <video
  src="/products/promo/gold.mp4"
  autoPlay
  muted
  loop
  playsInline
  className="mb-6 aspect-square w-full border border-zinc-800 object-cover rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
 preload="metadata"/>
        <p className="text-sm font-black uppercase tracking-[0.3em] text-yellow-400">
          Promo Pack
        </p>

        <h3 className="mt-3 text-3xl font-black uppercase text-white">
          GOLD PACK
        </h3>

        <div className="mt-6 flex-1 space-y-2 text-zinc-300">
          <p>• 10 Lamponi 120u Filtred</p>
          <p>• 10 Gorilla Glue #2 Calispain</p>
          <p>• 5 Sour Diesel X FF Frozen</p>
          <p>• 1 Cover LaLinea (previa disponibilità modello)</p>
          <p>• 1 Filtro in vetro Raw</p>
          <p>• 1 Pack Cartine + Filtri Raw</p>
        </div>

        <p className="mt-8 text-4xl font-black lalinea-price-neon">
          150 €
        </p>

        <button
          type="button"
          onClick={() => {
            const id = "gold-pack";

            setCarrello((prev) => {
              const esistente = prev.find(
                (item) => String(item.id) === id
              );

              if (esistente) {
                return prev.map((item) =>
                  String(item.id) === id
                    ? { ...item, quantita: item.quantita + 1 }
                    : item
                );
              }

              return [
                ...prev,
                {
                  id: id as any,
                  nome: "GOLD PACK",
                  prezzo: 150,
                  quantita: 1,
                },
              ];
            });
          }}
          className="mt-6 w-full border border-yellow-400 bg-yellow-400 px-5 py-4 font-black uppercase text-black rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
        >
          Aggiungi al carrello
        </button>
      </div>

      {/* BE A HERO PACK */}
      <div className="flex flex-col border border-yellow-400 bg-zinc-950 p-6 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
        <video
  src="/products/promo/hero.mp4"
  autoPlay
  muted
  loop
  playsInline
  className="mb-6 aspect-square w-full border border-zinc-800 object-cover rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
 preload="metadata"/>
        <p className="text-sm font-black uppercase tracking-[0.3em] text-yellow-400">
          Top Promo
        </p>

        <h3 className="mt-3 text-3xl font-black uppercase text-white">
          BE A HERO PACK
        </h3>

        <div className="mt-6 flex-1 space-y-2 text-zinc-300">
          <p>• 10 Gorilla Glue #2</p>
          <p>• 10 Blueberry Filtred 73Ü</p>
          <p>• 10 Lemon Cherry Gelato 120ü</p>
          <p>• 10 SnowHeads 90ü</p>
          <p>• 3.5 Orange Soda Frozen</p>
          <p>• 3.5 SD X FF Frozen</p>
          <p>• 3 Rosin Home Made LaLinea</p>
          <p>• 1 Paio calzini LaLinea</p>
          <p>• 1 Pack Filtri + Cartine Raw</p>
          <p>• 1 Mese abbonamento Spotify</p>
        </div> +

        <p className="mt-8 text-4xl font-black lalinea-price-neon">
          300 €
        </p>

        <button
          type="button"
          onClick={() => {
            const id = "be-a-hero-pack";

            setCarrello((prev) => {
              const esistente = prev.find(
                (item) => String(item.id) === id
              );

              if (esistente) {
                return prev.map((item) =>
                  String(item.id) === id
                    ? { ...item, quantita: item.quantita + 1 }
                    : item
                );
              }

              return [
                ...prev,
                {
                  id: id as any,
                  nome: "BE A HERO PACK",
                  prezzo: 300,
                  quantita: 1,
                },
              ];
            });
          }}
          className="mt-6 w-full border border-yellow-400 bg-yellow-400 px-5 py-4 font-black uppercase text-black rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
        >
          Aggiungi al carrello
        </button>
      </div>

    </div>

    {/* INFO MODIFICHE PACK */}
    <div className="mt-10 border border-yellow-400/40 bg-zinc-950 p-6 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
      <p className="font-black uppercase leading-relaxed text-yellow-400">
        È POSSIBILE APPORTARE MODIFICHE AI PACCHETTI SU RICHIESTA,
        AGGIUNGENDO ANCHE PRODOTTI DELLA CATEGORIA WHITE.
      </p>

      <p className="mt-3 text-zinc-300">
        Per maggiori informazioni:{" "}
        <a
          href="https://t.me/LaLineaInfoAssistenza"
          target="_blank"
          rel="noopener noreferrer"
          className="font-black text-yellow-400"
        >
          @LaLineaInfoAssistenza
        </a>
      </p>
    </div>

  </div>
</section>

{/* TRACKING */}
<section id="tracking" className="border-b border-zinc-800 bg-black">
  <div className="mx-auto max-w-7xl px-6 py-24">

    <p className="font-bold uppercase tracking-[0.3em] text-yellow-400">
      Tracking
    </p>

    <h2 className="mt-3 text-5xl font-black uppercase tracking-tight">
      Traccia il tuo ordine
    </h2>

    <p className="mt-4 text-zinc-400">
      Inserisci il codice tracking ricevuto con il tuo ordine.
    </p>

    <form
      className="mt-8 flex flex-col gap-4 sm:flex-row"
      onSubmit={(e) => {
        e.preventDefault();

        const form = new FormData(e.currentTarget);
        const codice = String(form.get("tracking") || "").trim();

        if (!codice) return;

        window.open(
  `https://www.17track.net/it?nums=${encodeURIComponent(codice)}`,
  "_blank",
  "noopener,noreferrer"
);
      }}
    >
      <input
        type="text"
        name="tracking"
        required
        placeholder="Inserisci codice tracking"
        className="w-full border border-zinc-700 bg-black p-4 text-white outline-none focus:border-yellow-400 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
      />

      <button
        type="submit"
        className="bg-yellow-400 px-8 py-4 font-black uppercase text-black"
      >
        Cerca
      </button>
    </form>

  </div>
</section>
     
{/* SHOP */}
      <section id="shop" className="mx-auto max-w-7xl px-6 py-24">
        <div className="ll-shop-intro mb-14">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="font-black uppercase tracking-[0.28em] text-yellow-300">
              LALINEA OFFICIAL · MILANO
            </p>
            <span className="rounded-full border border-green-400/30 bg-green-400/[0.06] px-3 py-1 text-[10px] font-black uppercase tracking-[0.16em] text-green-300">
              Selezione attuale
            </span>
          </div>

          <h2 className="mt-5 max-w-4xl text-4xl font-black uppercase leading-[0.95] tracking-[-0.03em] text-white md:text-6xl">
            Prodotti selezionati.
            <span className="block text-yellow-300">Identità LaLinea.</span>
          </h2>

          <p className="mt-5 max-w-3xl text-base font-medium leading-relaxed text-zinc-300 md:text-lg">
            Da 10 anni selezioniamo prodotti da tutto il mondo per la community LaLinea.
            Qui trovi la selezione disponibile in questo momento.
          </p>

          <div className="mt-7 grid gap-3 sm:grid-cols-3">
            {[
              ["10 ANNI", "di attività"],
              ["1.000+", "feedback positivi"],
              ["MILANO", "selezione LaLinea"],
            ].map(([valore, etichetta]) => (
              <div key={valore} className="rounded-2xl border border-white/10 bg-black/35 px-4 py-4">
                <p className="text-xl font-black uppercase text-yellow-300">{valore}</p>
                <p className="mt-1 text-xs font-bold uppercase tracking-[0.12em] text-zinc-400">{etichetta}</p>
              </div>
            ))}
          </div>
        </div>
{/* CATEGORIE SHOP */}
<div className="ll-category-nav mb-12">
  {/* MOBILE: navigazione categorie in stile catalogo */}
  <div className="md:hidden">
    <div className="rounded-[28px] border border-yellow-300/40 bg-zinc-950/90 p-5 shadow-[0_0_24px_rgba(250,204,21,0.10)]">
      <h3 className="text-2xl font-black text-white">Categorie</h3>

      <div className="-mx-1 mt-5 flex gap-3 overflow-x-auto px-1 pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {[
          "Premium Filtred",
          "Frozen e Static",
          "Rosin & Pen",
          "Flowers",
          "Dry Work",
          "White",
          "Tabacchi biologici",
          "Gadget",
          "Abbigliamento",
        ].map((categoria) => (
          <button
            key={`pill-${categoria}`}
            type="button"
            onClick={() => apriCategoriaCatalogo(categoria)}
            className={`shrink-0 rounded-2xl border px-5 py-4 text-sm font-black uppercase tracking-wide transition ${
              categoriaAttiva === categoria
                ? "border-yellow-300 bg-yellow-400 text-black shadow-[0_0_18px_rgba(250,204,21,0.45)]"
                : "border-zinc-700 bg-black text-white"
            }`}
          >
            <span className="flex items-center gap-3">
              {categoria}
              <span aria-hidden="true" className="text-xl leading-none">›</span>
            </span>
          </button>
        ))}
      </div>
    </div>

    <div className="mt-12">
      <p className="text-sm font-black uppercase tracking-[0.28em] text-yellow-400">
        Esplora il catalogo
      </p>
      <h3 className="mt-2 text-4xl font-black tracking-tight text-white">
        Categorie
      </h3>

      <div className="mt-6 grid grid-cols-2 gap-3">
        {[
          { nome: "Premium Filtred", immagine: "/products/premium-filtred/voltus1.jpg" },
          { nome: "Frozen e Static", immagine: "/products/frozen-static/arancia1.jpeg" },
          { nome: "Rosin & Pen", immagine: "/products/rosin/etere1.jpg" },
          { nome: "Flowers", immagine: "/products/flowers/lmg2.jpg" },
          { nome: "Dry Work", immagine: "/products/Dry work/cj2.jpg" },
          { nome: "White", immagine: "/products/other/soda2.jpg" },
          { nome: "Tabacchi biologici", immagine: "/products/other/tab2.jpg" },
          { nome: "Gadget", immagine: "/cover1.jpg" },
          { nome: "Abbigliamento", immagine: "/products/abbigliamento/calza1.jpg" },
        ].map(({ nome, immagine }) => (
          <button
            key={`card-${nome}`}
            type="button"
            onClick={() => apriCategoriaCatalogo(nome)}
            aria-pressed={categoriaAttiva === nome}
            className={`group overflow-hidden rounded-[26px] border bg-black text-left transition active:scale-[0.98] ${
              categoriaAttiva === nome
                ? "border-yellow-300 ring-1 ring-yellow-300 shadow-[0_0_20px_rgba(250,204,21,0.30)]"
                : "border-yellow-300/20 shadow-[0_0_12px_rgba(250,204,21,0.08)]"
            }`}
          >
            <div className="relative aspect-[4/5] overflow-hidden bg-zinc-950">
              <img
                src={immagine}
                alt={nome}
                loading="lazy"
                draggable={false}
                data-no-preview="true"
                onError={(evento) => {
                  if (nome !== "Tabacchi biologici") return;
                  const immagineErrore = evento.currentTarget;
                  if (immagineErrore.dataset.fallbackUsato === "true") return;
                  immagineErrore.dataset.fallbackUsato = "true";
                  immagineErrore.src = "/products/other/tab3.jpg";
                }}
                className="pointer-events-none h-full w-full object-cover transition duration-300 group-active:scale-105"
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black via-black/10 to-transparent" />

              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-2 p-4">
                <span className="max-w-[75%] text-base font-black uppercase leading-tight text-white">
                  {nome}
                </span>
                <span
                  aria-hidden="true"
                  className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full border text-xl font-black ${
                    categoriaAttiva === nome
                      ? "border-yellow-300 bg-yellow-400 text-black shadow-[0_0_18px_rgba(250,204,21,0.45)]"
                      : "border-white/50 bg-black/60 text-white"
                  }`}
                >
                  →
                </span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  </div>

  {/* DESKTOP: selettore originale invariato */}
  <div className="hidden gap-3 md:grid md:grid-cols-4">
    {[
      "Premium Filtred",
      "Frozen e Static",
      "Rosin & Pen",
      "Flowers",
      "Dry Work",
      "White",
      "Tabacchi biologici",
      "Gadget",
      "Abbigliamento",
    ].map((categoria) => (
      <button
        key={categoria}
        type="button"
        onClick={() => apriCategoriaCatalogo(categoria)}
        className={`rounded-2xl border px-4 py-4 text-sm font-black uppercase tracking-wider transition ${
          categoriaAttiva === categoria
            ? "border-yellow-300 bg-yellow-400 text-black shadow-[0_0_18px_rgba(250,204,21,0.45)]"
            : "border-yellow-300/25 bg-zinc-950 text-white hover:border-yellow-300 hover:text-yellow-300 hover:shadow-[0_0_16px_rgba(250,204,21,0.25)]"
        }`}
      >
        {categoria}
      </button>
    ))}
  </div>
</div>
{/* PRODOTTI PREMIUM FILTRED */}
{categoriaAttiva === "Premium Filtred" && (
<>
  <div className="mt-10">
  
    <div className="rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">

      <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
        Premium Filtred
      </p>

      <h3 className="mt-2 text-3xl font-black uppercase text-white">
        LAMPONI 120U
      </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="FARM">Maradona Selection</InfoRiga>
      <InfoRiga etichetta="BILANCIAMENTO">Indica 50% — Sativa 50%</InfoRiga>
      <InfoRiga etichetta="GUSTO">Presenta note dolci di agrumi, frutti di bosco, vaniglia e uva</InfoRiga>
      <InfoRiga etichetta="EFFETTO">Offre un mix di gioia mentale edificante e delicato rilassamento fisico senza una pesante sedazione.</InfoRiga>
    </div>


      <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">

  {/* VIDEO A SINISTRA */}
  <video
    src="/products/premium-filtred/maradona1.mp4"
    autoPlay
    muted
    loop
    playsInline
    className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
   preload="metadata"/>

  {/* FOTO A DESTRA */}
  <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">
    {[2, 3, 4, 5, 6, 7, 8].map((numero) => (
      <img
        key={numero}
        src={`/products/premium-filtred/maradona${numero}.jpg`}
        alt={`LAMPONI 120U - foto ${numero}`}
        className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
      />
    ))}
  </div>

</div>

      <a
        href="https://t.me/+UIRWbzgEJ8w4ZWI0"
        target="_blank"
        rel="noopener noreferrer"
        className="mt-6 inline-block border border-yellow-400 bg-yellow-400 px-6 py-4 font-black uppercase tracking-widest text-black rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
      >
        Informazioni su Telegram
      </a>
<div className="mt-6">
  <p className="mb-3 font-bold uppercase text-white">
    Quantità disponibili
  </p>

  <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
    {[
      { grammi: "5g", prezzo: 30 },
      { grammi: "10g", prezzo: 55 },
      { grammi: "25g", prezzo: 150 },
      { grammi: "50g", prezzo: 240 },
      { grammi: "100g", prezzo: 350 },
   ].map((opzione) => (
  <button
    key={opzione.grammi}
    type="button"
    onClick={() =>
      aggiungiMaradonaAlCarrello(opzione.grammi, opzione.prezzo)
    }
    className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)] hover:bg-yellow-400 hover:text-black"
  >
    <p className="font-black text-white">
      {opzione.grammi}
    </p>

    <p className="mt-1 font-bold lalinea-price-neon">
      {opzione.prezzo} €
    </p>

    <p className="mt-2 text-xs font-black uppercase">
      Aggiungi al carrello
    </p>
  </button>
))}
</div>
  <p className="mt-4 text-sm font-bold uppercase text-zinc-400">
    Per quantità maggiori, contattare in privato. Nella sezione Contatti
    troverete tutte le info.
  </p>
</div>
    </div>
  </div>
{/* VOLTUS Z */}
<div id="voltus-z"className="mt-10">
  <div className="rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Premium Filtred
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      VOLTUS Z
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="BILANCIAMENTO">60% Indica — 40% Sativa</InfoRiga>
      <InfoRiga etichetta="EDIZIONE">Limitata, prodotta da Greatfull Seed</InfoRiga>
      <InfoRiga etichetta="INCROCIO">Key Lime Peach Sunset Z &amp; Head 6</InfoRiga>
    </div>

    {/* VIDEO + FOTO */}
    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/premium-filtred/voltus.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      <div className="flex-1 grid grid-cols-2 gap-3 md:grid-cols-3">
        <img
          src="/products/premium-filtred/voltus1.jpg"
          alt="Voltus Z 1"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/premium-filtred/voltus2.jpg"
          alt="Voltus Z 2"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/premium-filtred/voltus3.jpg"
          alt="Voltus Z 3"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/premium-filtred/voltus4.jpg"
          alt="Voltus Z 4"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/premium-filtred/voltus5.jpg"
          alt="Voltus Z 5"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/premium-filtred/voltus6.jpg"
          alt="Voltus Z 6"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>
      </div>
    </div>

    {/* QUANTITÀ */}
    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { grammi: "5G", prezzo: 35 },
          { grammi: "10G", prezzo: 65 },
          { grammi: "25G", prezzo: 150 },
          { grammi: "50G", prezzo: 220 },
          { grammi: "100G", prezzo: 400 },
          { grammi: "500G", prezzo: 1900 },
          { grammi: "1K", prezzo: 2900 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `voltus-z-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? {
                          ...item,
                          quantita: item.quantita + 1,
                        }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `Voltus Z ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)]"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>

    <p className="mt-4 text-sm font-bold uppercase text-zinc-400">
      Per quantità maggiori, contattare in privato. Nella sezione Contatti
      troverete tutte le info.
    </p>
  </div>
</div>
  {/* LEMON CHERRY GELATO - MAGIC MOUNTAIN FARMERS */}
<div className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">
  <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
    Premium Filtred
  </p>

  <h3 className="mt-2 text-3xl font-black uppercase text-white">
    LEMON CHERRY GELATO 
  </h3>

  <div className="mt-6 space-y-3">
    <InfoRiga etichetta="FARM">Magic Mountain Farmers</InfoRiga>
    <InfoRiga etichetta="BILANCIAMENTO">60% Indica — 40% Sativa</InfoRiga>
    <InfoRiga etichetta="GENETICA">Sunset Sherbet x Girl Scout Cookies</InfoRiga>
    <InfoRiga etichetta="AROMA">Fruttato, di limone, ciliegia e sfumature cremose.</InfoRiga>
    <InfoRiga etichetta="EFFETTO">Inizia con una sensazione di euforia e lucidità per poi evolvere in un forte rilassamento del corpo.</InfoRiga>
  </div>

  {/* LEMON CHERRY GELATO - MAGIC MOUNTAIN FARMERS */}
<div className="mt-10">
  <div className="rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">

    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Premium Filtred
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      LEMON CHERRY GELATO
    </h3>

    <p className="mt-1 font-bold uppercase text-zinc-400">
      BY MAGIC MOUNTAIN FARMERS
    </p>

    {/* VIDEO + FOTO */}
<div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">

  {/* VIDEO A SINISTRA */}
  <video
    src="/products/premium-filtred/lm4.mp4"
    autoPlay
    muted
    loop
    playsInline
    className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
   preload="metadata"/>

  {/* FOTO A DESTRA */}
  <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">
    <img
      src="/products/premium-filtred/lm1.jpg"
      alt="Lemon Cherry Gelato 1"
      className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
     loading="lazy" decoding="async"/>

    <img
      src="/products/premium-filtred/lm2.jpg"
      alt="Lemon Cherry Gelato 2"
      className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
     loading="lazy" decoding="async"/>

    <img
      src="/products/premium-filtred/lm3.jpg"
      alt="Lemon Cherry Gelato 3"
      className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
     loading="lazy" decoding="async"/>

    <img
      src="/products/premium-filtred/lm4.jpg"
      alt="Lemon Cherry Gelato 4"
      className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
     loading="lazy" decoding="async"/>

    <img
      src="/products/premium-filtred/lm5.jpg"
      alt="Lemon Cherry Gelato 5"
      className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
     loading="lazy" decoding="async"/>
  </div>
</div>


    {/* QUANTITÀ */}
    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { grammi: "5g", prezzo: 40 },
          { grammi: "10g", prezzo: 70 },
          { grammi: "25g", prezzo: 160 },
          { grammi: "50g", prezzo: 270 },
          { grammi: "100g", prezzo: 430 },
          { grammi: "250g", prezzo: 900 },
          { grammi: "500g", prezzo: 1500 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `lemon-cherry-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? {
                          ...item,
                          quantita: item.quantita + 1,
                        }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `Lemon Cherry Gelato By Magic Mountain Farmers ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)]"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>

    <p className="mt-4 text-sm font-bold uppercase text-zinc-400">
      Per quantità maggiori, contattare in privato. Nella sezione Contatti
      troverete tutte le info.
    </p>

  </div>
</div>
{/* BLUEBERRY PREMIUM 73ü */}
<div className="mt-10">
  <div className="rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">

    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Premium Filtred
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      BLUEBERRY PREMIUM 73ü
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="FARM">Zaza Farm Morocco</InfoRiga>
      <InfoRiga etichetta="BILANCIAMENTO">80% Indica — 20% Sativa</InfoRiga>
      <InfoRiga etichetta="GENETICA">Afghani x Thai</InfoRiga>
      <InfoRiga etichetta="AROMA">Dolce, con un forte profumo di mirtillo fresco e frutti di bosco.</InfoRiga>
      <InfoRiga etichetta="EFFETTO">Molto rilassante per il corpo, ideale per la sera o per alleviare lo stress e il dolore.</InfoRiga>
    </div>

    {/* VIDEO + FOTO */}
    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">

      {/* VIDEO A SINISTRA */}
      <video
        src="/products/premium-filtred/blu1.MOV"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      {/* FOTO A DESTRA */}
      <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">

        <img
          src="/products/premium-filtred/blu2.jpg"
          alt="BlueBerry Premium 73ü 1"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/premium-filtred/blu3.jpg"
          alt="BlueBerry Premium 73ü 2"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/premium-filtred/blu4.jpg"
          alt="BlueBerry Premium 73ü 3"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/premium-filtred/blu5.jpg"
          alt="BlueBerry Premium 73ü 4"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

      </div>
    </div>

    {/* QUANTITÀ */}
    <div className="mt-6">

      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">

        {[
          { grammi: "5g", prezzo: 45 },
          { grammi: "7g", prezzo: 60 },
          { grammi: "25g", prezzo: 170 },
          { grammi: "50g", prezzo: 250 },
        ].map((opzione) => (

          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `blueberry-premium-73u-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? {
                          ...item,
                          quantita: item.quantita + 1,
                        }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `BlueBerry Premium 73ü ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)]"
          >

            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase text-white">
              Aggiungi al carrello
            </p>

          </button>

        ))}

      </div>
    </div>

    <p className="mt-4 text-sm font-bold uppercase text-zinc-400">
      Per quantità maggiori, contattare in privato. Nella sezione Contatti
      troverete tutte le info.
    </p>

  </div>
</div>
  {/* SNOWHEADS 90u */}
<div className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">
  <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
    Premium Filtred
  </p>

  <h3 className="mt-2 text-3xl font-black uppercase text-white">
    SNOWHEADS 90u
  </h3>

  <div className="mt-6 space-y-3">
    <InfoRiga etichetta="INDICA">Dato non specificato</InfoRiga>
    <InfoRiga etichetta="SATIVA">Dato non specificato</InfoRiga>
    <InfoRiga etichetta="GUSTO">Note di buccia di limone, gas e mentolo</InfoRiga>
    <InfoRiga etichetta="EFFETTO">Un ibrido a prevalenza sativa che offre una rapida stimolazione cerebrale, lucidità e una carica energizzante. È comunemente utilizzato per favorire la produttività diurna o alleviare lo stress.</InfoRiga>
  </div>

  {/* VIDEO + FOTO */}
  <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">

    {/* VIDEO A SINISTRA */}
    <video
      src="/products/premium-filtred/head2.MOV"
      autoPlay
      muted
      loop
      playsInline
      className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
     preload="metadata"/>

    {/* FOTO A DESTRA */}
    <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">
      <img
        src="/products/premium-filtred/head1.jpg"
        alt="SNOWHEADS 90u 1"
        className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
       loading="lazy" decoding="async"/>

      <img
        src="/products/premium-filtred/head3.jpg"
        alt="SNOWHEADS 90u 2"
        className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
       loading="lazy" decoding="async"/>

      <img
        src="/products/premium-filtred/head4.jpg"
        alt="SNOWHEADS 90u 3"
        className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
       loading="lazy" decoding="async"/>

      <img
        src="/products/premium-filtred/head5.jpg"
        alt="SNOWHEADS 90u 4"
        className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
       loading="lazy" decoding="async"/>
    </div>
  </div>

  {/* QUANTITÀ */}
  <div className="mt-6">
    <p className="mb-3 font-bold uppercase text-white">
      Seleziona quantità
    </p>

    <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
      {[
        { grammi: "5g", prezzo: 40 },
        { grammi: "10g", prezzo: 70 },
        { grammi: "25g", prezzo: 160 },
        { grammi: "50g", prezzo: 270 },
        { grammi: "100g", prezzo: 430 },
        { grammi: "250g", prezzo: 900 },
        { grammi: "500g", prezzo: 1500 },
      ].map((opzione) => (
        <button
          key={opzione.grammi}
          type="button"
          onClick={() => {
            const id = `snowheads-90u-${opzione.grammi}`;

            setCarrello((prev) => {
              const esistente = prev.find(
                (item) => String(item.id) === id
              );

              if (esistente) {
                return prev.map((item) =>
                  String(item.id) === id
                    ? {
                        ...item,
                        quantita: item.quantita + 1,
                      }
                    : item
                );
              }

              return [
                ...prev,
                {
                  id: id as any,
                  nome: `SNOWHEADS 90u ${opzione.grammi}`,
                  prezzo: opzione.prezzo,
                  quantita: 1,
                },
              ];
            });
          }}
          className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)]"
        >
          <p className="text-xl font-black text-white">
            {opzione.grammi}
          </p>

          <p className="mt-3 text-xl font-black lalinea-price-neon">
            {opzione.prezzo} €
          </p>

          <p className="mt-2 text-xs font-black uppercase text-white">
            Aggiungi al carrello
          </p>
        </button>
      ))}
    </div>
  </div>

  <p className="mt-4 text-sm font-bold uppercase text-zinc-400">
    Per quantità maggiori, contattare in privato. Nella sezione Contatti
    troverete tutte le info.
  </p>
</div>
</div>
</>
)}

{/* PINK LEMON 120U PREMIUM */}
{categoriaAttiva === "Premium Filtred" && (
  <div className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Premium Filtred
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      PINK LEMON 120U PREMIUM
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="BILANCIAMENTO">Indica 80% — Sativa 20%</InfoRiga>
      <InfoRiga etichetta="GENETICA">Purple Kush × Lemon Skunk × Anonymous St.</InfoRiga>
    </div>

    <p className="mt-4 rounded-2xl border border-yellow-200 bg-yellow-400 px-3 py-2 font-black uppercase text-black shadow-[0_0_18px_rgba(250,204,21,0.35)]">
      Prodotto in promozione — lancio domenica
      <br />
      I prezzi verranno aggiornati
    </p>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/premium-filtred/pivo.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      <div className="flex-1 grid grid-cols-2 gap-3 md:grid-cols-4">
        {[2, 3, 4, 6].map((numero) => (
          <img
            key={numero}
            src={`/products/premium-filtred/pivo${numero}.jpg`}
            alt={`PINK LEMON 120U PREMIUM foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {[
          { grammi: "10G", prezzo: 60 },
          { grammi: "25G", prezzo: 130 },
          { grammi: "50G", prezzo: 215 },
          { grammi: "100G", prezzo: 400 },
          { grammi: "250G", prezzo: 760 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `pink-lemon-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? {
                          ...item,
                          quantita: item.quantita + 1,
                        }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `PINK LEMON 120U PREMIUM ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)]"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-5 text-sm font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}
{/* BRUCE BANNER F.F IN DISCHI PREMIUM */}
{categoriaAttiva === "Frozen e Static" && (
  <div
    id="bruce-banner-ff-premium"
    className="mt-8 rounded-3xl border border-yellow-300/80 bg-black/85 p-4 shadow-lg sm:p-6"
  >
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Frozen e Static
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      Bruce Banner F.F in dischi Premium
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="GENETICA">
        OG Kush X Strawberry OG
      </InfoRiga>

      <InfoRiga etichetta="PROPRIETARIO DEL SEME">
        Dark Horse Genetics
      </InfoRiga>

      <InfoRiga etichetta="BILANCIAMENTO">
        Sativa 70% — Indica 30%
      </InfoRiga>

      <InfoRiga etichetta="GUSTO">
        Diesel, Fragola, Terraceo
      </InfoRiga>

      <InfoRiga etichetta="STATO DI CONSERVAZIONE">
        Glassy 100%
      </InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/frozen-static/milka1.mp4"
        poster="/products/frozen-static/milka2.jpg"
        autoPlay
        muted
        loop
        playsInline
        preload="metadata"
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover sm:w-1/2"
      />

      <div className="grid flex-1 grid-cols-2 gap-3 md:grid-cols-3">
        {[2, 4, 5, 6, 7].map((numero) => (
          <img
            key={numero}
            src={`/products/frozen-static/milka${numero}.jpg`}
            alt={`Bruce Banner F.F in dischi Premium foto ${numero}`}
            loading="lazy"
            decoding="async"
            className="aspect-square w-full rounded-xl border border-yellow-300/50 object-cover"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { grammi: "7G", prezzo: 50, promo: true },
          { grammi: "5G", prezzo: 50, promo: false },
          { grammi: "10G", prezzo: 90, promo: false },
          { grammi: "25G", prezzo: 200, promo: false },
          { grammi: "50G", prezzo: 380, promo: false },
          { grammi: "100G", prezzo: 600, promo: false },
          { grammi: "500G", prezzo: 2500, promo: false },
          { grammi: "1K", prezzo: 3500, promo: false },
          { grammi: "5K", prezzo: 15000, promo: false },
        ]
          .filter(
            (opzione) =>
              !opzione.promo ||
              Date.now() < Date.parse("2026-10-10T00:00:00+02:00")
          )
          .map((opzione) => (
            <button
              key={opzione.grammi}
              type="button"
              onClick={() => {
                if (
                  opzione.promo &&
                  Date.now() >= Date.parse("2026-10-10T00:00:00+02:00")
                ) {
                  return;
                }

                const id = `bruce-banner-ff-premium-${opzione.grammi}`;

                setCarrello((prev) => {
                  const esistente = prev.find(
                    (item) => String(item.id) === id
                  );

                  if (esistente) {
                    return prev.map((item) =>
                      String(item.id) === id
                        ? { ...item, quantita: item.quantita + 1 }
                        : item
                    );
                  }

                  return [
                    ...prev,
                    {
                      id: id as any,
                      nome: `BRUCE BANNER F.F IN DISCHI PREMIUM ${
                        opzione.grammi
                      }${opzione.promo ? " - PROMO LANCIO" : ""}`,
                      prezzo: opzione.prezzo,
                      quantita: 1,
                    },
                  ];
                });
              }}
              className={`flex flex-col items-start rounded-xl border px-4 py-4 text-left transition-colors ${
                opzione.promo
                  ? "border-green-400 bg-green-400/10 hover:bg-green-400/20"
                  : "border-yellow-300 bg-zinc-950 hover:bg-zinc-900"
              }`}
            >
              {opzione.promo && (
                <>
                  <p className="mb-1 text-xs font-black uppercase text-green-400">
                    Promo lancio
                  </p>

                  <p className="mb-3 text-xs text-white">
                    Valida fino al 09/10/2026
                  </p>
                </>
              )}

              <p className="text-xl font-black text-white">
                {opzione.grammi}
              </p>

              <p className="mt-1 text-xl font-bold lalinea-price-neon">
                {opzione.prezzo.toLocaleString("it-IT")} €
              </p>

              <p className="mt-2 text-xs font-black uppercase text-white">
                Aggiungi al carrello
              </p>
            </button>
          ))}
      </div>
    </div>
  </div>
)}

{/* G.M.O */}
{categoriaAttiva === "Frozen e Static" && (
  <div
    id="gmo"
    className="mt-8 rounded-3xl border border-yellow-300/80 bg-black/80 p-4 sm:p-6"
  >
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-300">
      Frozen e Static
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      G.M.O
    </h3>

    <p className="mt-2 font-bold text-white">
      Brand: no farm
    </p>

    <p className="mt-1 font-bold text-white">
      Bilanciamento: 50% indica / 50% sativa
    </p>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/frozen-static/gmo1.mp4"
        autoPlay
        muted
        loop
        playsInline
        preload="metadata"
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover sm:w-1/2"
      />

      <div className="grid flex-1 grid-cols-2 gap-3">
        {[2, 3, 4, 5].map((numero) => (
          <img
            key={numero}
            src={`/products/frozen-static/gmo${numero}.jpg`}
            alt={`G.M.O foto ${numero}`}
            loading="lazy"
            decoding="async"
            className="aspect-square w-full rounded-xl border border-yellow-300/50 object-cover"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { grammi: "15", prezzo: 100, promo: true },
          { grammi: "5", prezzo: 40, promo: false },
          { grammi: "10", prezzo: 80, promo: false },
          { grammi: "25", prezzo: 200, promo: false },
          { grammi: "50", prezzo: 275, promo: false },
          { grammi: "100", prezzo: 550, promo: false },
          { grammi: "500", prezzo: 2000, promo: false },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `gmo-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? { ...item, quantita: item.quantita + 1 }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `G.M.O ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className={`rounded-2xl border p-4 transition-colors ${
              opzione.promo
                ? "border-yellow-300 bg-yellow-300/10 hover:bg-yellow-300/20"
                : "border-yellow-300 bg-zinc-950 hover:bg-zinc-900"
            }`}
          >
            {opzione.promo && (
              <p className="mb-2 text-xs font-black uppercase text-yellow-300">
                Promo lancio
              </p>
            )}

            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo.toLocaleString("it-IT")} €
            </p>

            <p className="mt-2 text-xs font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}
{/* TUNA OG STATIC */}
{categoriaAttiva === "Frozen e Static" && (
  <div
    id="tuna-og-static"
    className="mt-8 rounded-3xl border border-yellow-300/80 bg-black/85 p-4 shadow-[0_0_30px_rgba(250,204,21,0.20)] sm:p-5"
  >
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Frozen e Static
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      TUNA OG STATIC
    </h3>

    <p className="mt-1 text-xl font-black uppercase text-yellow-400">
      TUNA OG · TUNA KUSH
    </p>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="TIPOLOGIA">
        Ibrido a predominanza indica
      </InfoRiga>
      <InfoRiga etichetta="BILANCIAMENTO">
        Indica 70% — Sativa 30%
      </InfoRiga>
      <InfoRiga etichetta="GENETICA">
        Si ritiene sia un fenotipo particolarmente potente di Hindu Kush oppure un incrocio tra OG Kush e Black Tuna
      </InfoRiga>
      <InfoRiga etichetta="EFFETTO">
        Potente, marcatamente sedativo e a predominanza fisica
      </InfoRiga>
      <InfoRiga etichetta="GUSTO">
        Molto intenso e pungente: insoliti sentori di pesce o alghe, note terrose e Skunk, con un marcato retrogusto Kush
      </InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/frozen-static/tonno1.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      <div className="flex-1 grid grid-cols-2 gap-3 md:grid-cols-3">
        {[2, 3, 4, 5, 6, 7].map((numero) => (
          <img
            key={numero}
            src={`/products/frozen-static/tonno${numero}.jpg`}
            alt={`Tuna OG Static foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {lemonStaticOpzioni.map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `tuna-og-static-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? { ...item, quantita: item.quantita + 1 }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `TUNA OG STATIC ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)] hover:bg-yellow-400 hover:text-black transition"
          >
            <p className="font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-1 font-bold lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}

{/* ALIEN OG PLASMA X1 - ALIEN PLASMA STATIC */}
{categoriaAttiva === "Frozen e Static" && (
  <div
    id="alien-og-plasma-x1"
    className="mt-8 rounded-3xl border border-yellow-300/80 bg-black/85 p-4 shadow-[0_0_30px_rgba(250,204,21,0.20)] sm:p-5"
  >
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Frozen e Static
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      ALIEN OG PLASMA X1
    </h3>

    <p className="mt-1 text-xl font-black uppercase text-yellow-400">
      ALIEN PLASMA STATIC
    </p>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/frozen-static/alien1.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      <div className="flex-1 grid grid-cols-2 gap-3 md:grid-cols-3">
        {[2, 3, 4, 5, 6, 7].map((numero) => (
          <img
            key={numero}
            src={`/products/frozen-static/alien${numero}.jpg`}
            alt={`Alien OG Plasma X1 foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { grammi: "5G", prezzo: 50 },
          { grammi: "10G", prezzo: 90 },
          { grammi: "25G", prezzo: 220 },
          { grammi: "50G", prezzo: 350 },
          { grammi: "100G", prezzo: 600 },
          { grammi: "500G", prezzo: 2500 },
          { grammi: "1K", prezzo: 4000 },
          { grammi: "5K", prezzo: 18500 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `alien-og-plasma-x1-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? { ...item, quantita: item.quantita + 1 }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `ALIEN OG PLASMA X1 ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-2xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_16px_rgba(250,204,21,0.18)] hover:bg-yellow-400"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>
            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo.toLocaleString("it-IT")} €
            </p>
            <p className="mt-2 text-xs font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}

{/* COOKIES X RUNTZ 2.0 - PREMIUM STATIC 120ü */}
{categoriaAttiva === "Frozen e Static" && (
  <div id="cookies-x-runtz" className="mt-8 rounded-3xl border border-yellow-300/80 bg-black/85 p-4 shadow-[0_0_30px_rgba(250,204,21,0.20)] sm:p-5">

    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Frozen e Static
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      COOKIES X RUNTZ 2.0
    </h3>

    <p className="mt-1 text-xl font-black uppercase text-yellow-400">
      PREMIUM STATIC 120ü
    </p>

    {/* DESCRIZIONE */}
    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="FARM">Zaza Farm Morocco Lansarr</InfoRiga>
      <InfoRiga etichetta="GENETICA">Cookies X Runtz 2.0</InfoRiga>
      <InfoRiga etichetta="FILTRAGGIO">220 / 160 / 120</InfoRiga>
      <InfoRiga etichetta="BILANCIAMENTO">Indica 50% — Sativa 50%</InfoRiga>
      <InfoRiga etichetta="GUSTO">Caramella alla frutta, Terraceo, Nocciola</InfoRiga>
      <InfoRiga etichetta="EFFETTO">Euforico e rilassante allo stesso tempo, crea molta socialità e poca fame chimica</InfoRiga>
      <InfoRiga etichetta="TERPENE DOMINANTE">Myrcene</InfoRiga>
      <InfoRiga etichetta="STATO">Completamente vetro</InfoRiga>
      <InfoRiga etichetta="FORMATO">Bolle da 100</InfoRiga>
    </div>

    {/* VIDEO + FOTO */}
    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">

      <video
        src="/products/frozen-static/cokru1.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      <div className="flex-1 grid grid-cols-2 gap-3 md:grid-cols-3">
        {[2, 3, 4, 5, 6, 7].map((numero) => (
          <img
            key={numero}
            src={`/products/frozen-static/cokru${numero}.jpg`}
            alt={`Cookies X Runtz 2.0 foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>

    </div>

    {/* PREZZI */}
    <div className="mt-6">

      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">

        {[
          { grammi: "5G", prezzo: 40 },
          { grammi: "10G", prezzo: 70 },
          { grammi: "17G PROMO LANCIO", prezzo: 100 },
          { grammi: "25G", prezzo: 180 },
          { grammi: "50G", prezzo: 250 },
          { grammi: "100G", prezzo: 450 },
          { grammi: "250G", prezzo: 990 },
          { grammi: "500G", prezzo: 1990 },
          { grammi: "1K", prezzo: 3300 },
          { grammi: "2K", prezzo: 5600 },
          { grammi: "5K", prezzo: 11750 },
          { grammi: "10K", prezzo: 23000 },
        ].map((opzione) => (

          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {

              const id = `cookies-runtz-2-${opzione.grammi}`;

              setCarrello((prev) => {

                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? {
                          ...item,
                          quantita: item.quantita + 1,
                        }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `COOKIES X RUNTZ 2.0 PREMIUM STATIC 120ü ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}

            className={`rounded-2xl border px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.14)] ${
              opzione.grammi === "17G PROMO LANCIO"
                ? "border-yellow-300 bg-yellow-400 text-black shadow-[0_0_18px_rgba(250,204,21,0.45)]"
                : "border-yellow-400 bg-zinc-950"
            }`}
          >

            <p
              className={`text-lg font-black ${
                opzione.grammi === "17G PROMO LANCIO"
                  ? "text-black"
                  : "text-white"
              }`}
            >
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo.toLocaleString("it-IT")} €
            </p>

            <p
              className={`mt-5 text-sm font-black uppercase ${
                opzione.grammi === "17G PROMO LANCIO"
                  ? "text-black"
                  : "text-white"
              }`}
            >
              Aggiungi al carrello
            </p>

          </button>

        ))}

      </div>
    </div>

  </div>
)}
{/* PRODOTTO FROZEN E STATIC */}
{categoriaAttiva === "Frozen e Static" && (
  <div id="orange-punch-frozen" className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Frozen e Static
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      ORANGE PUNCH FROZEN
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="FARM">Pablito Farm</InfoRiga>
      <InfoRiga etichetta="FORMATO">Bolle Glassy da 50gr</InfoRiga>
      <InfoRiga etichetta="BILANCIAMENTO">Indica 70% — Sativa 30%</InfoRiga>
      <InfoRiga etichetta="GUSTO">Arancia candita, buccia di arancia, caramella alla frutta</InfoRiga>
      <InfoRiga etichetta="EFFETTO">Genetica già a forte predominanza indica; il setaccio congelato e il formato da 50gr fanno da contenitore per un vero pugno alla Joshua che ti manderà a letto in totale relax, con un retrogusto di zeste di arancia. Buona fumata.</InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/frozen-static/arancia2.mov"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">
        {[1, 3, 4, 5].map((numero) => (
          <img
            key={numero}
            src={`/products/frozen-static/arancia${numero}.jpeg`}
            alt={`Orange Punch Frozen foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { grammi: "5g", prezzo: 50 },
          { grammi: "10g", prezzo: 80 },
          { grammi: "25g", prezzo: 170 },
          { grammi: "50g", prezzo: 330 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() =>
              aggiungiOrangeAlCarrello(opzione.grammi, opzione.prezzo)
            }
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)]"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-5 text-sm font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}
{/* SOUR DIESEL X FORBIDDEN FRUIT */}
{categoriaAttiva === "Frozen e Static" && (
  <div className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Frozen e Static
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      SOUR DIESEL X FORBIDDEN FRUIT
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="FARM">Pablito Farm</InfoRiga>
      <InfoRiga etichetta="FORMATO">Bolle Glassy da 50gr</InfoRiga>
      <InfoRiga etichetta="BILANCIAMENTO">Indica 40% — Sativa 60%</InfoRiga>
      <InfoRiga etichetta="GUSTO">Frutta tropicale, kiwi, papaya e uva dolce, carburante jet-fuel, pino e scorza di limone. A detta di molti il cross del decennio.</InfoRiga>
      <InfoRiga etichetta="EFFETTO">Focus cerebrale ed energizzante all'inizio, abbinato a una graduale e rilassante euforia corporea.</InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/frozen-static/sdff2.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">
        <img
          src="/products/frozen-static/sdff1.jpg"
          alt="Sour Diesel X Forbidden Fruit foto 1"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/frozen-static/sdff3.jpg"
          alt="Sour Diesel X Forbidden Fruit foto 2"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/frozen-static/sdff4.jpg"
          alt="Sour Diesel X Forbidden Fruit foto 3"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/frozen-static/sdff5.jpg"
          alt="Sour Diesel X Forbidden Fruit foto 4"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {sourDieselOpzioni.map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() =>
              aggiungiSourDieselAlCarrello(
                opzione.grammi,
                opzione.prezzo
              )
            }
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)] hover:bg-yellow-400 hover:text-black"
          >
            <p className="font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-1 font-bold lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}
{/* LEMON STATIC PREMIUM */}
{categoriaAttiva === "Frozen e Static" && (
  <div id="lemon-static-premium" className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Frozen e Static
    </p>

    <h3 className="mt-2 text-2xl font-black uppercase text-white">
      LEMON STATIC PREMIUM
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="BILANCIAMENTO">Indica 50% — Sativa 50%</InfoRiga>
      <InfoRiga etichetta="GUSTO">Buccia di limone, cedro, sentori di Kush e pino</InfoRiga>
      <InfoRiga etichetta="EFFETTO">Uplifting totale, mentale e fisico, ottimo per il sollievo dal dolore. Questa genetica viene utilizzata da circa vent&apos;anni anche a livello palliativo.</InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/frozen-static/lemon1.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-4">
        <img
          src="/products/frozen-static/lemon2.jpg"
          alt="Lemon Static Premium foto 1"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/frozen-static/lemon3.jpg"
          alt="Lemon Static Premium foto 2"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/frozen-static/lemon4.jpg"
          alt="Lemon Static Premium foto 3"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/frozen-static/lemon5.jpg"
          alt="Lemon Static Premium foto 4"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/frozen-static/lemon6.jpg"
          alt="Lemon Static Premium foto 5"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>

        <img
          src="/products/frozen-static/lemon7.jpg"
          alt="Lemon Static Premium foto 6"
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
         loading="lazy" decoding="async"/>
      </div>
    </div>

    <div className="mt-6">
      <p className="text-sm font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        {lemonStaticOpzioni.map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() =>
              aggiungiLemonStaticAlCarrello(
                opzione.grammi,
                opzione.prezzo
              )
            }
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)] hover:bg-yellow-400 hover:text-black transition"
          >
            <p className="font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-1 font-bold lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}
{/* WHOLE MELT SUGAR SPRITZ */}
{categoriaAttiva === "Rosin & Pen" && (
  <div
    id="whole-melt-sugar-spritz"
    className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-lg sm:p-6"
  >
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Rosin & Pen
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      WHOLE MELT
    </h3>

    <p className="mt-2 text-lg font-black uppercase tracking-wide text-yellow-300">
      Sugar Spritz x Melted Strawberry Banana
    </p>

    <div className="mt-6 grid gap-3 sm:grid-cols-2">
      <InfoRiga etichetta="GENETICA">
        Sugar Spritz x Melted Strawberry Banana
      </InfoRiga>

      <InfoRiga etichetta="PROPRIETARIO DEL SEME">
        Whole Melt Genetics
      </InfoRiga>

      <InfoRiga etichetta="BILANCIAMENTO">
        Sativa 50% — Indica 50%
      </InfoRiga>

      <InfoRiga etichetta="GUSTO">
        Banana, Fragola, Miele
      </InfoRiga>

      <InfoRiga etichetta="STATO DI CONSERVAZIONE">
        In scatola
      </InfoRiga>

      <InfoRiga etichetta="CONFEZIONE">
        1 pezzo equivale a 1 confezione
      </InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/rosin/wholespritz1.mp4"
        poster="/products/rosin/wholespritz2.jpg"
        autoPlay
        muted
        loop
        playsInline
        preload="metadata"
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover sm:w-1/2"
      />

      <div className="grid flex-1 grid-cols-2 gap-3">
        {[2, 3, 4, 5].map((numero) => (
          <img
            key={numero}
            src={"/products/rosin/wholespritz" + numero + ".jpg"}
            alt={"Whole Melt Sugar Spritz foto " + numero}
            loading="lazy"
            decoding="async"
            className="aspect-square w-full rounded-xl border border-yellow-300/50 object-cover"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-2 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <p className="mb-4 text-sm text-zinc-300">
        1 pezzo = 1 confezione. Massimo 10 confezioni per ordine.
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          {
            pezzi: 1,
            prezzo:
              Date.now() < Date.parse("2026-10-13T00:00:00+02:00")
                ? 90
                : 120,
          },
          { pezzi: 3, prezzo: 290 },
          { pezzi: 5, prezzo: 320 },
          { pezzi: 10, prezzo: 650 },
        ].map((opzione) => {
          const confezioniNelCarrello = carrello.reduce(
            (totale, item) => {
              const formato = String(item.id).match(
                /^whole-melt-sugar-spritz-(1|3|5|10)pz$/
              );

              return (
                totale +
                (formato ? Number(formato[1]) * item.quantita : 0)
              );
            },
            0
          );

          const limiteSuperato =
            confezioniNelCarrello + opzione.pezzi > 10;

          const inPromo =
            opzione.pezzi === 1 && opzione.prezzo === 90;

          return (
            <button
              key={opzione.pezzi}
              type="button"
              disabled={limiteSuperato}
              onClick={() => {
                const prezzoAttuale =
                  opzione.pezzi === 1
                    ? Date.now() <
                      Date.parse("2026-10-13T00:00:00+02:00")
                      ? 90
                      : 120
                    : opzione.prezzo;

                if (prezzoAttuale !== opzione.prezzo) {
                  setCarrello((prev) => [...prev]);
                  return;
                }

                const id =
                  "whole-melt-sugar-spritz-" + opzione.pezzi + "pz";

                setCarrello((prev) => {
                  const totaleConfezioni = prev.reduce(
                    (totale, item) => {
                      const formato = String(item.id).match(
                        /^whole-melt-sugar-spritz-(1|3|5|10)pz$/
                      );

                      return (
                        totale +
                        (formato
                          ? Number(formato[1]) * item.quantita
                          : 0)
                      );
                    },
                    0
                  );

                  if (totaleConfezioni + opzione.pezzi > 10) {
                    return prev;
                  }

                  const esistente = prev.find(
                    (item) => String(item.id) === id
                  );

                  if (esistente) {
                    return prev.map((item) =>
                      String(item.id) === id
                        ? {
                            ...item,
                            prezzo: prezzoAttuale,
                            quantita: item.quantita + 1,
                          }
                        : item
                    );
                  }

                  return [
                    ...prev,
                    {
                      id: id as any,
                      nome:
                        "WHOLE MELT Sugar Spritz x Melted Strawberry Banana - " +
                        opzione.pezzi +
                        (opzione.pezzi === 1
                          ? " confezione"
                          : " confezioni"),
                      prezzo: prezzoAttuale,
                      quantita: 1,
                    },
                  ];
                });
              }}
              className="flex flex-col items-start rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-left transition-colors enabled:hover:bg-zinc-900 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {inPromo && (
                <>
                  <p className="mb-1 text-xs font-black uppercase text-green-400">
                    Promo lancio
                  </p>

                  <p className="mb-3 text-xs text-white">
                    Fino al 12/10/2026, poi 120 €
                  </p>
                </>
              )}

              <p className="text-lg font-black uppercase text-white sm:text-xl">
                {opzione.pezzi}{" "}
                {opzione.pezzi === 1 ? "pezzo" : "pezzi"}
              </p>

              <p className="mt-3 text-xl font-black lalinea-price-neon">
                {opzione.prezzo.toLocaleString("it-IT")} €
              </p>

              <p className="mt-3 text-xs font-black uppercase text-white">
                {limiteSuperato
                  ? "Limite di 10 confezioni"
                  : "Aggiungi al carrello"}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  </div>
)}

{/* HONEY BANANA x ACAI MINT 2G DIAMOND + LIVE */}
{categoriaAttiva === "Rosin & Pen" && (
  <div className="mt-8 rounded-3xl border border-green-300/70 bg-black/90 p-4 shadow-[0_0_30px_rgba(74,222,128,0.16)] sm:p-5">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
        Rosin & Pen
      </p>
      <span className="rounded-full border border-green-400/60 bg-green-400/10 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-green-300">
        Nuovo drop
      </span>
    </div>

    <h3 className="mt-3 text-3xl font-black uppercase text-white sm:text-4xl">
      HONEY BANANA x ACAI MINT
    </h3>

    <p className="mt-2 text-lg font-black uppercase tracking-wide text-green-300">
      2G DIAMOND + LIVE
    </p>

    <div className="mt-6 grid gap-3 sm:grid-cols-2">
      <InfoRiga etichetta="PROVENIENZA">🇺🇸 USA</InfoRiga>
      <InfoRiga etichetta="CAPACITÀ">2G DIAMOND + LIVE</InfoRiga>
      <InfoRiga etichetta="GENETICA LATO 1">INDICA</InfoRiga>
      <InfoRiga etichetta="GENETICA LATO 2">HYBRID</InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/rosin/keytwo1.mp4"
        autoPlay
        muted
        loop
        playsInline
        preload="metadata"
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-green-300/50 object-cover shadow-[0_0_18px_rgba(74,222,128,0.16)] sm:aspect-square sm:w-1/4"
      />

      <div className="flex-1 grid grid-cols-2 gap-3 md:grid-cols-3">
        {[2, 3, 4, 5, 6].map((numero) => (
          <img
            key={numero}
            src={`/products/rosin/keytwo${numero}.jpg`}
            alt={`HONEY BANANA x ACAI MINT foto ${numero}`}
            loading="lazy"
            decoding="async"
            className="aspect-square w-full rounded-xl border border-green-300/35 object-cover shadow-[0_0_12px_rgba(74,222,128,0.10)]"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { quantita: "1 PEN DUAL", prezzo: 110 },
          { quantita: "2 PEN DUAL", prezzo: 190 },
          { quantita: "3 PEN DUAL", prezzo: 270 },
          { quantita: "5 PEN DUAL", prezzo: 400 },
        ].map((opzione) => (
          <button
            key={opzione.quantita}
            type="button"
            onClick={() =>
              aggiungiHoneyBananaAcaiMintAlCarrello(
                opzione.quantita,
                opzione.prezzo
              )
            }
            className="rounded-xl border border-green-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(74,222,128,0.16)] transition hover:bg-green-400 hover:text-black"
          >
            <p className="text-lg font-black text-white sm:text-xl">
              {opzione.quantita}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-5 text-sm font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}

{/* WHOLE MELT DUAL CHAMBER - KEY LIME CAKE x ZAZAYA */}
{categoriaAttiva === "Rosin & Pen" && (
  <div className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Rosin & Pen
    </p>

    <h3
  id="zazaya-key-lime-pie-cake"
  className="mt-2 text-3xl font-black uppercase text-white"
>
  WHOLE MELT DUAL CHAMBER
</h3>

    <p className="mt-2 text-lg font-black uppercase tracking-wide text-yellow-300">
      KEY LIME CAKE x ZAZAYA
    </p>

    <div className="mt-6 grid gap-3 sm:grid-cols-2">
      <InfoRiga etichetta="PROVENIENZA">USA</InfoRiga>
      <InfoRiga etichetta="CAPACITÀ">2G DIAMOND + LIVE</InfoRiga>
      <InfoRiga etichetta="GENETICA 1">SATIVA</InfoRiga>
      <InfoRiga etichetta="GENETICA 2">INDICA</InfoRiga>
    </div>

    <div className="mt-5 rounded-2xl border border-yellow-300/40 bg-yellow-400/[0.06] p-4">
      <p className="text-sm font-bold leading-relaxed text-zinc-200 sm:text-base">
        Le nuove Dual Chamber di Whole Melt, pioniere dell&apos;estrazione, ti permettono di
        switchare la genetica con un solo clic oppure di mischiarle assieme. Un&apos;esperienza
        sensazionale: questa volta si sono davvero superati.
      </p>
      <p className="mt-3 text-lg font-black uppercase tracking-[0.18em] text-yellow-300">
        DA PROVARE
      </p>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/rosin/key1.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      <div className="flex-1 grid grid-cols-2 gap-3 md:grid-cols-3">
        {[2, 3, 4, 5, 6, 7].map((numero) => (
          <img
            key={numero}
            src={`/products/rosin/key${numero}.jpg`}
            alt={`WHOLE MELT DUAL CHAMBER KEY LIME CAKE x ZAZAYA foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { quantita: "1 PEN DUAL", prezzo: 110 },
          { quantita: "2 PEN DUAL", prezzo: 190 },
          { quantita: "3 PEN DUAL", prezzo: 270 },
          { quantita: "5 PEN DUAL", prezzo: 400 },
        ].map((opzione) => (
          <button
            key={opzione.quantita}
            type="button"
            onClick={() =>
              aggiungiWholeMeltDualAlCarrello(
                opzione.quantita,
                opzione.prezzo
              )
            }
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)]"
          >
            <p className="text-lg font-black text-white sm:text-xl">
              {opzione.quantita}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-5 text-sm font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}

{/* ROSIN H HOMEMADE 37u */}
{categoriaAttiva === "Rosin & Pen" && (
  <div className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Rosin & Pen
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      ROSIN H HOMEMADE 37u
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="PRODUZIONE">Rosin prodotto a Milano da noi</InfoRiga>
      <InfoRiga etichetta="PROCESSO">Presse Qnubu, crioterapia e una lunga cura</InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/rosin/rosin1.MOV"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">
        {[1, 2, 3, 5].map((numero) => (
          <img
            key={numero}
            src={`/products/rosin/rosint${numero}.jpg`}
            alt={`ROSIN H HOMEMADE 37u foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {[
          { grammi: "2.5G", prezzo: 60 },
          { grammi: "5G", prezzo: 100 },
          { grammi: "10G", prezzo: 200 },
          { grammi: "25G", prezzo: 375 },
          { grammi: "50G", prezzo: 450 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() =>
              aggiungiRosinAlCarrello(
                opzione.grammi,
                opzione.prezzo
              )
            }
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)]"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-5 text-sm font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}

{/* ROSIN & PEN - LIVE ROS ETH TROPICANA COOKIES 45u */}
{categoriaAttiva === "Rosin & Pen" && (
  <div className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Rosin & Pen
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      LIVE ROS ETH TROPICANA COOKIES 45u
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="NOTA">Per quantitativi più grossi, vi preghiamo di ordinare con qualche giorno di anticipo.</InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <img
        src="/products/rosin/etere1.jpg"
        alt="LIVE ROS ETH TROPICANA COOKIES 45u foto 1"
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       loading="lazy" decoding="async"/>

      <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">
        {[2, 3, 4, 5].map((numero) => (
          <img
            key={numero}
            src={`/products/rosin/etere${numero}.jpg`}
            alt={`LIVE ROS ETH TROPICANA COOKIES 45u foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { grammi: "1G", prezzo: 22 },
          { grammi: "3G", prezzo: 60 },
          { grammi: "5G", prezzo: 90 },
          { grammi: "10G", prezzo: 160 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `live-ros-eth-tropicana-cookies-45u-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? { ...item, quantita: item.quantita + 1 }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `LIVE ROS ETH TROPICANA COOKIES 45u ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)]"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-5 text-sm font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}
{/* FLOWERS - CALISPAIN TOP SHELF PINEAPPLE DONUT */}
{categoriaAttiva === "Flowers" && (
  <div
    id="pineapple-donut"
    className="mt-8 rounded-3xl border border-yellow-300/80 bg-black/85 p-4 shadow-lg"
  >
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Flowers
    </p>

    <div className="mt-3 space-y-2 text-center">
      <p className="text-2xl font-black uppercase text-yellow-400">
        🇺🇸CALISPAIN🇪🇸
      </p>
      <p className="text-xl font-black uppercase text-yellow-300">
        🏆TOP SHELF🏆
      </p>
      <h3 className="text-2xl font-black uppercase text-white sm:text-3xl">
        🍍🍩PINEAPPLE DONUT 🍩🍍
      </h3>
    </div>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="BILANCIAMENTO">
        Sativa 70% - Indica 30%
      </InfoRiga>
      <InfoRiga etichetta="GENETICA">
        Franken Cakes x Gorilla Diesel #3
      </InfoRiga>
      <InfoRiga etichetta="GUSTO">
        Ananas🍍, Dolce🍰, Pino🌲
      </InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/flowers/ananas1.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/35 object-cover sm:w-1/2"
        preload="metadata"
      />

      <div className="grid flex-1 grid-cols-2 gap-3 md:grid-cols-4">
        {[2, 3, 4, 5, 6, 7, 8].map((numero) => (
          <img
            key={numero}
            src={`/products/flowers/ananas${numero}.jpg`}
            alt={`CALISPAIN TOP SHELF PINEAPPLE DONUT foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover"
            loading="lazy"
            decoding="async"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { grammi: "3.5G", prezzo: 35 },
          { grammi: "5G", prezzo: 45 },
          { grammi: "10G", prezzo: 85 },
          { grammi: "25G", prezzo: 200 },
          { grammi: "50G", prezzo: 375 },
          { grammi: "100G", prezzo: 550 },
          { grammi: "250G", prezzo: 1250 },
          { grammi: "500G", prezzo: 2200 },
          { grammi: "1KG", prezzo: 3800 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `pineapple-donut-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? { ...item, quantita: item.quantita + 1 }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `CALISPAIN TOP SHELF - PINEAPPLE DONUT ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-2xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-left transition hover:border-green-400"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}

{/* FLOWERS - LEMON CHERRY GELATO 2.0 */}
{categoriaAttiva === "Flowers" && (
  <div id="lemon-cherry-gelato" className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">

    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Flowers
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      LEMON CHERRY GELATO 2.0
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="GENETICA">Sunset Sherbert x Girls Scout Cookies</InfoRiga>
      <InfoRiga etichetta="BILANCIAMENTO">Ibrida a predominanza Indica</InfoRiga>
      <InfoRiga etichetta="GUSTO">Ciliegia, frutti di bosco, gas</InfoRiga>
    </div>

   <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">

  <video
    src="/products/flowers/lmg1.mp4"
    autoPlay
    muted
    loop
    playsInline
    className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
   preload="metadata"/>

  <div className="flex-1 grid grid-cols-2 md:grid-cols-3 gap-3">
    <img
      src="/products/flowers/lmg2.jpg"
      alt="Lemon Cherry Gelato 2.0 foto 2"
      className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
     loading="lazy" decoding="async"/>
    <img
      src="/products/flowers/lmg3.jpg"
      alt="Lemon Cherry Gelato 2.0 foto 3"
      className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
     loading="lazy" decoding="async"/>
    <img
      src="/products/flowers/lmg4.jpg"
      alt="Lemon Cherry Gelato 2.0 foto 4"
      className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
     loading="lazy" decoding="async"/>
    <img
      src="/products/flowers/lmg5.jpg"
      alt="Lemon Cherry Gelato 2.0 foto 5"
      className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
     loading="lazy" decoding="async"/>
    <img
      src="/products/flowers/lmg6.jpg"
      alt="Lemon Cherry Gelato 2.0 foto 6"
      className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
     loading="lazy" decoding="async"/>
    <img
      src="/products/flowers/lmg7.jpg"
      alt="Lemon Cherry Gelato 2.0 foto 7"
      className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
     loading="lazy" decoding="async"/>
  </div>

</div>
    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { grammi: "5G", prezzo: 45 },
          { grammi: "10G", prezzo: 80 },
          { grammi: "25G", prezzo: 180 },
          { grammi: "50G", prezzo: 350 },
          { grammi: "100G", prezzo: 550 },
          { grammi: "500G", prezzo: 2000 },
          { grammi: "1K", prezzo: 3500 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `lemon-cherry-gelato-2-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? {
                          ...item,
                          quantita: item.quantita + 1,
                        }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `Lemon Cherry Gelato 2.0 ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)] hover:bg-yellow-400"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}


{/* FLOWERS - GORILLA GLUE 2 CALISPAIN */}
{categoriaAttiva === "Flowers" && (
  <div className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">

    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Flowers
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      #GORILLA GLUE 2 CALISPAIN
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="BILANCIAMENTO">Indica 70% — Sativa 30%</InfoRiga>
      <InfoRiga etichetta="GUSTO">Diesel, colla, pino, gas</InfoRiga>
      <InfoRiga etichetta="EFFETTO">Indica 2.0, come amiamo chiamarle noi: effetto Kush immediato, fisico e mentale, senza lasciarti spalmato 5 ore senza far nulla.</InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">

      {/* VIDEO A SINISTRA */}
      <video
        src="/products/flowers/gorilla1.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      {/* FOTO A DESTRA */}
      <div className="flex-1 grid grid-cols-2 md:grid-cols-5 gap-3">
        {[2, 3, 4, 5, 6].map((numero) => (
          <img
            key={numero}
            src={`/products/flowers/gorilla${numero}.jpg`}
            alt={`Gorilla Glue 2 CaliSpain foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>

    </div>

    {/* QUANTITÀ */}
    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {[
          { grammi: "5g", prezzo: 40 },
          { grammi: "10g", prezzo: 70 },
          { grammi: "25g", prezzo: 190 },
          { grammi: "50g", prezzo: 300 },
          { grammi: "100g", prezzo: 520 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() =>
              aggiungiGorillaAlCarrello(
                opzione.grammi,
                opzione.prezzo
              )
            }
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)] hover:bg-yellow-400 hover:text-black"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
    {/* FLOWERS - TROPICANA COOKIES CALISPAIN */}
{categoriaAttiva === "Flowers" && (
  <div id="tropicana-cookies" className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Flowers
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      TROPICANA COOKIES CALISPAIN
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="BILANCIAMENTO">Sativa 70% — Indica 30%</InfoRiga>
      <InfoRiga etichetta="GUSTO">Cedro, biscotti, limone, fiori tropicali</InfoRiga>
      <InfoRiga etichetta="EFFETTO">Sativa decisa: ti lascia bello attivo e lucido, stimolando la creatività; mette molta voglia di socialità e una discreta fame chimica a fine sessione.</InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">

      {/* VIDEO A SINISTRA */}
      <video
        src="/products/flowers/tropicana1.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      {/* FOTO A DESTRA */}
      <div className="flex-1 grid grid-cols-2 md:grid-cols-5 gap-3">
        {[2, 3, 4, 5, 6].map((numero) => (
          <img
            key={numero}
            src={`/products/flowers/tropicana${numero}.jpg`}
            alt={`Tropicana Cookies CaliSpain foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>
    </div>

    {/* QUANTITÀ */}
    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {[
          { grammi: "5g", prezzo: 50 },
          { grammi: "10g", prezzo: 80 },
          { grammi: "25g", prezzo: 175 },
          { grammi: "50g", prezzo: 300 },
          { grammi: "100g", prezzo: 550 },
          { grammi: "500g", prezzo: 2500 },
          { grammi: "1k", prezzo: 4000 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `tropicana-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? {
                          ...item,
                          quantita: item.quantita + 1,
                        }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `Tropicana Cookies CaliSpain ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)]"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}
{/* FLOWERS - LEMON GUMP */}
<div id="lemon-gump" className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">

  <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
    Flowers
  </p>

  <h3 className="mt-2 text-3xl font-black uppercase text-white">
    LEMON GUMP
  </h3>

<div className="mt-6 space-y-3">
      <InfoRiga etichetta="BILANCIAMENTO">Indica 50% — Sativa 50%</InfoRiga>
      <InfoRiga etichetta="GUSTO">Lime, agrumi, pompelmo</InfoRiga>
      <InfoRiga etichetta="EFFETTO">Effetto bilanciato, lievemente predominante la parte indica rispetto a quanto indicato in scheda tecnica dai breeder.</InfoRiga>
    </div>

  <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">

    {/* VIDEO A SINISTRA */}
    <video
      src="/products/flowers/lemgump1.MP4"
      autoPlay
      muted
      loop
      playsInline
      className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
     preload="metadata"/>

    {/* FOTO A DESTRA */}
    <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">
      {[2, 3, 4, 5].map((numero) => (
        <img
          key={numero}
          src={`/products/flowers/lemgump${numero}.jpg`}
          alt={`Lemon Gump foto ${numero}`}
          className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
        />
      ))}
    </div>

  </div>

  {/* QUANTITÀ */}
  <div className="mt-6">
    <p className="mb-3 font-bold uppercase text-white">
      Seleziona quantità
    </p>

    <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
      {[
        { grammi: "5g", prezzo: 30 },
        { grammi: "10g", prezzo: 60 },
        { grammi: "25g", prezzo: 160 },
        { grammi: "50g", prezzo: 260 },
        { grammi: "100g", prezzo: 440 },
        { grammi: "500g", prezzo: 1850 },
        { grammi: "1kg", prezzo: 3500 },
      ].map((opzione) => (
        <button
          key={opzione.grammi}
          type="button"
          onClick={() => {
            const id = `lemon-gump-${opzione.grammi}`;

            setCarrello((prev) => {
              const esistente = prev.find(
                (item) => String(item.id) === id
              );

              if (esistente) {
                return prev.map((item) =>
                  String(item.id) === id
                    ? {
                        ...item,
                        quantita: item.quantita + 1,
                      }
                    : item
                );
              }

              return [
                ...prev,
                {
                  id: id as any,
                  nome: `LEMON GUMP ${opzione.grammi}`,
                  prezzo: opzione.prezzo,
                  quantita: 1,
                },
              ];
            });
          }}
          className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)] hover:bg-yellow-400"
        >
          <p className="text-xl font-black text-white">
            {opzione.grammi}
          </p>

          <p className="mt-3 text-xl font-black lalinea-price-neon">
            {opzione.prezzo} €
          </p>

          <p className="mt-2 text-xs font-black uppercase">
            Aggiungi al carrello
          </p>
        </button>
      ))}
    </div>
  </div>

</div>
  </div>
)}

{/* FLOWERS - LAUGHING BUDDHA */}
{categoriaAttiva === "Flowers" && (
  <div id="laughing-buddha" className="mt-8 rounded-3xl border border-yellow-300/80 bg-black/85 p-4 shadow-[0_0_30px_rgba(250,204,21,0.20)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Flowers
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      LAUGHING BUDDHA
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="PROPRIETARIO DEL SEME">Rare Seed</InfoRiga>
      <InfoRiga etichetta="PAESE DI COLTIVAZIONE">Spagna</InfoRiga>
      <InfoRiga etichetta="BILANCIAMENTO">80% Sativa — Indica 20%</InfoRiga>
      <InfoRiga etichetta="GENETICA">Thai Landrace x Jamaican Scout</InfoRiga>
      <InfoRiga etichetta="EFFETTO">Effetto indico di carattere fisico predominante, crea molta fame chimica.</InfoRiga>
      <InfoRiga etichetta="GUSTO">Tropicale, zeste di agrume, menta piperita</InfoRiga>
      <InfoRiga etichetta="TERPENE DOMINANTE">Terpinolene</InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/flowers/lab1.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      <div className="flex-1 grid grid-cols-2 gap-3 md:grid-cols-4">
        {[2, 3, 4, 5, 6, 7, 9].map((numero) => (
          <img
            key={numero}
            src={`/products/flowers/lab${numero}.jpg`}
            alt={`Laughing Buddha foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { grammi: "5G", prezzo: 40 },
          { grammi: "10G", prezzo: 70 },
          { grammi: "25G", prezzo: 200 },
          { grammi: "50G", prezzo: 300 },
          { grammi: "100G", prezzo: 500 },
          { grammi: "500G", prezzo: 1900 },
          { grammi: "1K", prezzo: 3000 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `laughing-buddha-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? { ...item, quantita: item.quantita + 1 }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `LAUGHING BUDDHA ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-2xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_16px_rgba(250,204,21,0.18)] hover:bg-yellow-400"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>
            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>
            <p className="mt-2 text-xs font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}

{/* DRY WORK - FRANCO FULLGAS */}
{categoriaAttiva === "Dry Work" && (
  <div
    id="franco-fullgas"
    className="mt-8 rounded-3xl border border-yellow-300/80 bg-black/85 p-4 shadow-lg"
  >
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Dry Work
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      FRANCO FULLGAS
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="GENETICA">
        Sunset Sherbert x Diagonal Og
      </InfoRiga>
      <InfoRiga etichetta="PROPRIETARI DELLO STRAIN">
        Cannarado Genetics
      </InfoRiga>
      <InfoRiga etichetta="GUSTO">
        Se avete in mente Exodus Cheese, bene: preparatevi a un flashback.
        Per gli altri mi serve un po’ di scuola.
      </InfoRiga>
      <InfoRiga etichetta="BILANCIAMENTO">
        Sativa 60% - Indica 40%
      </InfoRiga>
      <InfoRiga etichetta="FORMATO">
        50 congelati
      </InfoRiga>
    </div>

    <div className="mt-6 rounded-2xl border border-green-400/70 bg-green-950/40 p-4">
      <p className="text-sm font-black uppercase tracking-wide text-green-400">
        PROMO LANCIO
      </p>
      <p className="mt-2 text-2xl font-black text-white">
        100G a 330€
      </p>
      <p className="mt-1 text-sm text-zinc-300">
        Prezzo ordinario: <span className="line-through">350€</span>
      </p>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/Dry work/TAVOLALAVORO1.MP4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/35 object-cover sm:w-1/2"
        preload="metadata"
      />

      <div className="grid flex-1 grid-cols-2 gap-3 md:grid-cols-3">
        {[2, 3, 4, 5, 6, 8].map((numero) => (
          <img
            key={numero}
            src={`/products/Dry work/TAVOLALAVORO${numero}.JPG`}
            alt={`FRANCO FULLGAS foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover"
            loading="lazy"
            decoding="async"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { grammi: "10G", prezzo: 40, ordinario: 40 },
          { grammi: "25G", prezzo: 90, ordinario: 90 },
          { grammi: "50G", prezzo: 180, ordinario: 180 },
          { grammi: "100G", prezzo: 330, ordinario: 350 },
          { grammi: "500G", prezzo: 1500, ordinario: 1500 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `franco-fullgas-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? { ...item, quantita: item.quantita + 1 }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `FRANCO FULLGAS ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-2xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-left transition hover:border-green-400"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            {opzione.ordinario > opzione.prezzo && (
              <p className="mt-2 text-xs font-black uppercase text-green-400">
                Promo lancio
              </p>
            )}

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            {opzione.ordinario > opzione.prezzo && (
              <p className="mt-1 text-sm text-zinc-400 line-through">
                {opzione.ordinario} €
              </p>
            )}

            <p className="mt-2 text-xs font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}

{/* DRY WORK - GROVE STREET OG */}
{categoriaAttiva === "Dry Work" && (
  <div id="grove-street-og" className="mt-8 rounded-3xl border border-yellow-300/80 bg-black/85 p-4 shadow-[0_0_30px_rgba(250,204,21,0.20)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Dry Work
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      GROVE STREET OG
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="FATTORIA">Sconosciuta</InfoRiga>
      <InfoRiga etichetta="BILANCIAMENTO">Indica 60% — Sativa 40%</InfoRiga>
      <InfoRiga etichetta="GENETICA">SFV OG or Ghost OG</InfoRiga>
      <InfoRiga etichetta="EFFETTO">Effetto indico di carattere fisico predominante, crea molta fame chimica.</InfoRiga>
      <InfoRiga etichetta="GUSTO">Gas, Diesel, miele</InfoRiga>
      <InfoRiga etichetta="TERPENE DOMINANTE">Myrcene</InfoRiga>
      <InfoRiga etichetta="FORMATO">Bolle da 100</InfoRiga>
      <InfoRiga etichetta="STATO">Vetro 100%</InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/Dry work/cj1.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      <div className="flex-1 grid grid-cols-2 gap-3 md:grid-cols-3">
        {[2, 3, 4, 5, 6, 7].map((numero) => (
          <img
            key={numero}
            src={`/products/Dry work/cj${numero}.jpg`}
            alt={`Grove Street OG foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { grammi: "5G", prezzo: 25 },
          { grammi: "10G", prezzo: 40 },
          { grammi: "25G", prezzo: 95 },
          { grammi: "50G", prezzo: 175 },
          { grammi: "100G", prezzo: 320 },
          { grammi: "500G", prezzo: 1450 },
          { grammi: "1K", prezzo: 2700 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `grove-street-og-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? { ...item, quantita: item.quantita + 1 }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `GROVE STREET OG ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-2xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_16px_rgba(250,204,21,0.18)] hover:bg-yellow-400"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>
            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>
            <p className="mt-2 text-xs font-black uppercase text-white">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}

  {/* TABACCHI BIOLOGICI - TOBACCO BIO SHELDIA X JOINT */}
{categoriaAttiva === "Tabacchi biologici" && (
  <div id="tobacco-bio-sheldia" className="mt-8 rounded-3xl border border-yellow-300/80 bg-black/85 p-4 shadow-[0_0_30px_rgba(250,204,21,0.20)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      Tabacchi biologici
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      TOBACCO BIO SHELDIA X JOINT
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="PROVENIENZA">Albania, Regione dello SHELDIA</InfoRiga>
      <InfoRiga etichetta="DESCRIZIONE">
        Tabacco lavorato naturalmente con semi tramandati di mano in mano di generazione in generazione, non contiene nessun tipo di additivo né fertilizzante, lascia un gusto naturale e completamente neutro alla fumata.
      </InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/other/tab1.mp4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      <div className="flex-1 grid grid-cols-2 gap-3 md:grid-cols-3">
        {[2, 3, 4, 5, 6, 7].map((numero) => (
          <img
            key={numero}
            src={`/products/other/tab${numero}.jpg`}
            alt={`Tobacco Bio Sheldia foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>
    </div>

    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-1 gap-3 sm:max-w-sm">
        <button
          type="button"
          onClick={() => {
            const id = "tobacco-bio-sheldia-25-5";

            setCarrello((prev) => {
              const esistente = prev.find(
                (item) => String(item.id) === id
              );

              if (esistente) {
                return prev.map((item) =>
                  String(item.id) === id
                    ? { ...item, quantita: item.quantita + 1 }
                    : item
                );
              }

              return [
                ...prev,
                {
                  id: id as any,
                  nome: "TOBACCO BIO SHELDIA X JOINT 25G + 5G OMAGGIO",
                  prezzo: 5,
                  quantita: 1,
                },
              ];
            });
          }}
          className="rounded-2xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_16px_rgba(250,204,21,0.18)] hover:bg-yellow-400"
        >
          <p className="text-xl font-black text-white">
            25G + 5G IN OMAGGIO
          </p>
          <p className="mt-3 text-2xl font-black lalinea-price-neon">
            5 €
          </p>
          <p className="mt-2 text-xs font-black uppercase text-white">
            Aggiungi al carrello
          </p>
        </button>
      </div>
    </div>
  </div>
)}

{/* WHITE - EGG HUANUCO */}
{categoriaAttiva === "White" && (
  <div className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      White
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      EGG HUANUCO
    </h3>

    {/* BADGE */}
    <div className="mt-3 inline-flex items-center gap-2 rounded-full border border-yellow-300 bg-yellow-400/10 px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-yellow-300 shadow-[0_0_18px_rgba(250,204,21,0.28)]">
      ★ PRODOTTO ESCLUSIVO
    </div>

    {/* MEDIA */}
    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">
      <video
        src="/products/other/HUANUCO1.MP4"
        autoPlay
        muted
        loop
        playsInline
        preload="metadata"
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
      />

      <div className="grid flex-1 grid-cols-2 gap-3">
        {[2, 3, 4, 5].map((numero) => (
          <img
            key={numero}
            src={`/products/other/HUANUCO${numero}.JPG`}
            alt={`Egg Huanuco foto ${numero}`}
            loading="lazy"
            decoding="async"
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>
    </div>

    {/* FORMATI E CARRELLO */}
    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona formato
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { formato: "1g", prezzo: 100 },
          { formato: "2.5g", prezzo: 220 },
          { formato: "5g", prezzo: 350 },
          { formato: "10g", prezzo: 550 },
        ].map((opzione) => (
          <button
            key={opzione.formato}
            type="button"
            onClick={() => {
              const id = `egg-huanuco-${opzione.formato}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? {
                          ...item,
                          quantita: item.quantita + 1,
                        }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `EGG HUANUCO ${opzione.formato}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="group rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)] transition hover:bg-yellow-400"
          >
            <p className="text-xl font-black text-white group-hover:text-black">
              {opzione.formato}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon group-hover:text-black">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase text-yellow-300 group-hover:text-black">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}

  {/* WHITE - LOGO SODA */}
{categoriaAttiva === "White" && (
  <div className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">
    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      White
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      LOGO SODA
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="LAVORAZIONE">Doppio lavaggio, foro di areazione, in guaina originale</InfoRiga>
    </div>

    
  
    {/* QUANTITÀ */}
    <div className="mt-6">
      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        {[
          { grammi: "1G", prezzo: 70 },
          { grammi: "3G", prezzo: 180 },
          { grammi: "5G", prezzo: 260 },
          { grammi: "10G", prezzo: 470 },
          { grammi: "50G", prezzo: 1900 },
          { grammi: "100G", prezzo: 3500 },
        ].map((opzione) => (
          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `logo-soda-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? {
                          ...item,
                          quantita: item.quantita + 1,
                        }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `LOGO SODA ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)] transition hover:bg-yellow-400 hover:text-black"
          >
            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase">
              Aggiungi al carrello
            </p>
          </button>
        ))}
      </div>
    </div>
  </div>
)}

{/* WHITE - DIESEL COLO */} 
{categoriaAttiva === "White" && (
  <div className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">

    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      White
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      DIESEL COLO
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="LAVORAZIONE">Lavaggio Kerosene, Brick da 1kg</InfoRiga>
      <InfoRiga etichetta="DESCRIZIONE">Colombiana classica ad impatto fisico praticamente immediato. No levamisolo, no lido.</InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">

      {/* VIDEO A SINISTRA */}
      <video
        src="/products/other/diesel.MP4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      {/* FOTO A DESTRA */}
      <div className="flex-1 grid grid-cols-2 md:grid-cols-5 gap-3">
        {[2, 3, 4, 5].map((numero) => (
          <img
            key={numero}
            src={`/products/other/diesel${numero}.jpg`}
            alt={`Diesel Colo foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}

       
      </div>

    </div>

    {/* QUANTITA */}
    <div className="mt-6">

      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">

        {[
          { grammi: "1g", prezzo: 70 },
          { grammi: "2g", prezzo: 130 },
          { grammi: "5g", prezzo: 240 },
          { grammi: "10g", prezzo: 400 },
        ].map((opzione) => (

          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {
              const id = `diesel-colo-${opzione.grammi}`;

              setCarrello((prev) => {
                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? {
                          ...item,
                          quantita: item.quantita + 1,
                        }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `DIESEL COLO ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)] hover:bg-yellow-400"
          >

            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase">
              Aggiungi al carrello
            </p>

          </button>

        ))}

      </div>
    </div>

  </div>
)}

{/* WHITE - BOLIVIAN DOLLAR LOGO */}
{categoriaAttiva === "White" && (
  <div className="mt-8 rounded-3xl border border-yellow-300/70 bg-black/85 p-4 shadow-[0_0_28px_rgba(250,204,21,0.16)] sm:p-5">

    <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
      White
    </p>

    <h3 className="mt-2 text-3xl font-black uppercase text-white">
      BOLIVIAN DOLLAR LOGO
    </h3>

    <div className="mt-6 space-y-3">
      <InfoRiga etichetta="PRODUZIONE">Artigianale a doppio lavaggio</InfoRiga>
      <InfoRiga etichetta="LOGISTICA">Ship via aerea, poca disponibilità</InfoRiga>
    </div>

    <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start">

      {/* VIDEO A SINISTRA */}
      <video
        src="/products/other/dollar1.MP4"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-video w-full flex-shrink-0 rounded-2xl border border-yellow-300/50 object-cover shadow-[0_0_18px_rgba(250,204,21,0.16)] sm:aspect-square sm:w-1/4"
       preload="metadata"/>

      {/* FOTO A DESTRA */}
      <div className="flex-1 grid grid-cols-2 md:grid-cols-3 gap-3">
        {[2, 3, 4, 5, 6, 7].map((numero) => (
          <img
            key={numero}
            src={`/products/other/dollar${numero}.jpg`}
            alt={`Bolivian Dollar Logo foto ${numero}`}
            className="aspect-square w-full rounded-xl border border-yellow-300/35 object-cover shadow-[0_0_12px_rgba(250,204,21,0.10)]"
          />
        ))}
      </div>

    </div>

    {/* QUANTITA */}
    <div className="mt-6">

      <p className="mb-3 font-bold uppercase text-white">
        Seleziona quantità
      </p>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">

        {[
          { grammi: "1G", prezzo: 60 },
          { grammi: "3G", prezzo: 150 },
          { grammi: "5G", prezzo: 220 },
          { grammi: "10G", prezzo: 400 },
          { grammi: "OFFERTA LANCIO 2 A 100€", prezzo: 100 },
        ].map((opzione) => (

          <button
            key={opzione.grammi}
            type="button"
            onClick={() => {

              const id = `bolivian-dollar-${opzione.grammi}`;

              setCarrello((prev) => {

                const esistente = prev.find(
                  (item) => String(item.id) === id
                );

                if (esistente) {
                  return prev.map((item) =>
                    String(item.id) === id
                      ? {
                          ...item,
                          quantita: item.quantita + 1,
                        }
                      : item
                  );
                }

                return [
                  ...prev,
                  {
                    id: id as any,
                    nome: `BOLIVIAN DOLLAR LOGO ${opzione.grammi}`,
                    prezzo: opzione.prezzo,
                    quantita: 1,
                  },
                ];
              });
            }}
            className="rounded-xl border border-yellow-300 bg-zinc-950 px-4 py-4 text-center shadow-[0_0_14px_rgba(250,204,21,0.16)] hover:bg-yellow-400/10"
          >

            <p className="text-xl font-black text-white">
              {opzione.grammi}
            </p>

            <p className="mt-3 text-xl font-black lalinea-price-neon">
              {opzione.prezzo} €
            </p>

            <p className="mt-2 text-xs font-black uppercase">
              Aggiungi al carrello
            </p>

          </button>

        ))}

      </div>
    </div>

  </div>
)}
{categoriaAttiva === "Gadget" && (
        <article className="overflow-hidden border border-zinc-800 bg-zinc-950 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
          <div className="grid md:grid-cols-2">
            <div className="p-4">
              <img
                src="/cover1.jpg"
                alt="Cover iPhone LaLinea UltraResistente"
                className="h-[600px] w-full object-contain bg-black"
              />

              <div className="mt-4 grid grid-cols-4 gap-3">
                <img
                  src="/cover1.jpg"
                  alt="Cover LaLinea foto 1"
                  className="h-28 w-full object-cover"
                />

                <img
                  src="/cover2.jpg"
                  alt="Cover LaLinea foto 2"
                  className="h-28 w-full object-cover"
                />

                <img
                  src="/cover3.jpg"
                  alt="Cover LaLinea foto 3"
                  className="h-28 w-full object-cover"
                />

                <img
                  src="/cover4.jpg"
                  alt="Cover LaLinea foto 4"
                  className="h-28 w-full object-cover"
                />
              </div>
            </div>

            <div className="flex flex-col justify-center p-8 md:p-12">
              <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
                LaLinea
              </p>

              <h3 className="mt-4 text-4xl font-black uppercase">
                Cover LaLinea UltraResistente
              </h3>

              <p className="mt-6 text-lg text-zinc-400">
                Cover iPhone LaLinea UltraResistente con adattatore MagSafe.
              </p>

              <p className="mt-2 text-zinc-400">
                Disponibile per iPhone e per tutti i modelli Android.
              </p>

              <div className="mt-8 border-t border-zinc-800 pt-8">
                <p className="text-4xl font-black lalinea-price-neon">
                  10 €
                </p>

                <p className="mt-2 text-xl font-bold text-white">
                  oppure 500 punti LaLinea
                </p>
              </div>

              <button
  type="button"
  onClick={aggiungiAlCarrello}
  className="mt-8 w-full bg-yellow-400 px-6 py-4 font-black uppercase tracking-widest text-black"
>
  Acquista a 10 €
</button>

<button
  type="button"
  onClick={aggiungiCoverConPunti}
  className="mt-3 w-full border border-yellow-400 bg-black px-6 py-4 font-black uppercase text-yellow-400 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
>
  Aggiungi con 500 punti
</button>
            </div>
          </div>
        </article>
)}
{categoriaAttiva === "Gadget" && (
  <article className="mt-12 overflow-hidden border border-zinc-800 bg-zinc-950 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
    <div className="grid md:grid-cols-2">
      <div className="p-4">
        <video
          src="/porta1.mp4"
          poster="/porta1.jpg"
          controls
          muted
          playsInline
          className="h-[600px] w-full bg-black object-contain"
         preload="metadata"/>

        <div className="mt-4 grid grid-cols-3 gap-3">
          <img
            src="/porta1.jpg"
            alt="Portachiavi in resina foto 1"
            className="h-28 w-full object-cover"
          />

          <img
            src="/porta2.jpg"
            alt="Portachiavi in resina foto 2"
            className="h-28 w-full object-cover"
          />

          <img
            src="/porta5.jpg"
            alt="Portachiavi in resina foto 3"
            className="h-28 w-full object-cover"
          />
        </div>
      </div>

      <div className="flex flex-col justify-center p-8 md:p-12">
        <p className="text-sm font-bold uppercase tracking-[0.3em] text-yellow-400">
          LaLinea
        </p>

        <h3 className="mt-4 text-4xl font-black uppercase">
          Portachiavi in resina
        </h3>

        <p className="mt-6 text-lg text-zinc-400">
          In euro: regalo
        </p>

        <div className="mt-8 border-t border-zinc-800 pt-8">
          <p className="text-4xl font-black text-yellow-400">
            200
          </p>

          <p className="mt-2 text-xl font-bold text-white">
            punti LaLinea
          </p>
        </div>

        <button
          type="button"
          onClick={aggiungiPortachiaviConPunti}
          className="mt-8 w-full bg-yellow-400 px-6 py-4 font-black uppercase text-black"
        >
          Aggiungi con 200 punti
        </button>
      </div>
    </div>
  </article>
)}
{/* CALZE LALINEA - OMAGGIO VIP */}
{String(categoriaAttiva).toLowerCase() === "abbigliamento" && (
  <article className="mx-auto my-10 w-[calc(100%-2rem)] max-w-5xl overflow-hidden border-2 border-yellow-400/60 bg-black text-white rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
    <div className="grid grid-cols-3 gap-2 p-3 md:gap-4 md:p-6">
      <img
        src="/products/abbigliamento/calza1.jpg"
        alt="Calze LaLinea foto 1"
        className="aspect-square w-full border border-zinc-800 object-cover rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
       loading="lazy" decoding="async"/>

      <img
        src="/products/abbigliamento/calza2.jpg"
        alt="Calze LaLinea foto 2"
        className="aspect-square w-full border border-zinc-800 object-cover rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
       loading="lazy" decoding="async"/>

      <img
        src="/products/abbigliamento/calza3.jpg"
        alt="Calze LaLinea foto 3"
        className="aspect-square w-full border border-zinc-800 object-cover rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
       loading="lazy" decoding="async"/>
    </div>

    <div className="border-t border-zinc-800 p-5 md:p-7">
      <p className="text-sm font-black uppercase tracking-[0.3em] text-yellow-400">
        OMAGGI VIP
      </p>

      <h3 className="mt-2 text-3xl font-black uppercase">
        CALZE LALINEA
      </h3>

      <div className="mt-4 space-y-1">
        <p className="text-xl font-black text-yellow-400">
          300 PUNTI
        </p>

        <p className="font-bold text-zinc-300">
          In euro: regalo
        </p>
      </div>

      <button
        type="button"
        onClick={aggiungiCalzeConPunti}
        className="mt-6 w-full bg-yellow-400 px-5 py-4 text-lg font-black uppercase text-black transition hover:bg-yellow-300"
      >
        AGGIUNGI AGLI OMAGGI
      </button>
    </div>
  </article>
)}
{/* GIFT CARD */}
      <details
        id="gift-card"
        className="group mt-8 border border-yellow-400/50 bg-black rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
      >
        <summary className="cursor-pointer list-none px-5 py-5">
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="flex items-center gap-3 text-xs font-bold uppercase tracking-[0.3em] text-yellow-400">
  Categoria
  <span className="rounded-full bg-yellow-400 px-3 py-1 font-black tracking-normal text-black">
    Nuova
  </span>
</p>

              <h2 className="mt-1 text-2xl font-black uppercase text-white">
                Gift Card LaLinea
              </h2>
            </div>

            <span className="shrink-0 border border-yellow-400 px-4 py-2 text-sm font-black uppercase text-yellow-400 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
              <span className="group-open:hidden">
                Apri categoria +
              </span>

              <span className="hidden group-open:inline">
                Chiudi −
              </span>
            </span>
          </div>
        </summary>

        <div className="border-t border-yellow-400/30 p-5">
          <p className="text-center font-bold text-zinc-400">
            Acquista con euro oppure riscatta con i punti VIP. Il codice
            verrà inviato dopo la conferma dell’ordine.
          </p>

          <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            {[
              { prezzo: 50, valore: 60, punti: 1000 },
              { prezzo: 100, valore: 120, punti: 2500 },
              { prezzo: 250, valore: 275, punti: 5500 },
              { prezzo: 500, valore: 550, punti: 10000 },
              { prezzo: 1000, valore: 1200, punti: 20000 },
            ].map((giftCard) => (
              <article
                key={giftCard.valore}
                className="flex flex-col border border-zinc-800 bg-zinc-950 p-4 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
              >
                <p className="text-xs font-bold uppercase text-yellow-400">
                  Gift Card
                </p>

                <h3 className="mt-2 text-2xl font-black text-white">
                  Paghi {giftCard.prezzo.toLocaleString("it-IT")} €
                </h3>

                <p className="mt-2 text-lg font-black text-yellow-400">
                  Valore {giftCard.valore.toLocaleString("it-IT")} €
                </p>

                <p className="mt-2 text-sm font-bold text-zinc-400">
                  Oppure {giftCard.punti.toLocaleString("it-IT")} punti
                  LaLinea
                </p>

                <div className="mt-auto grid grid-cols-1 gap-2 pt-5">
                  <button
                    type="button"
                    onClick={() =>
                      aggiungiGiftCardEuro(
                        giftCard.prezzo,
                        giftCard.valore
                      )
                    }
                    className="w-full bg-yellow-400 px-4 py-3 font-black uppercase text-black"
                  >
                    Acquista con €
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      aggiungiGiftCardConPunti(
                        giftCard.valore,
                        giftCard.punti
                      )
                    }
                    className="w-full border border-yellow-400 px-4 py-3 font-black uppercase text-yellow-400 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
                  >
                    Riscatta con punti
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </details>

        {/* CARRELLO */}
        <div id="ll-carrello" className="mt-12 border border-yellow-400 bg-black p-6 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
          <div className="flex items-center justify-between">
            <h3 className="text-3xl font-black uppercase">
              Carrello
            </h3>

            <span className="rounded-full bg-yellow-400 px-4 py-2 font-black text-black">
              {carrello.reduce(
                (totale, item) => totale + item.quantita,
                0
              )}
            </span>
          </div>

          {carrello.length === 0 ? (
            <p className="mt-6 text-zinc-400">
              Il tuo carrello è vuoto.
            </p>
          ) : (
            <>
              <div className="mt-6 space-y-4">
                {carrello.map((item) => (
                  <div
                    key={item.id}
                    className="border border-zinc-800 p-4 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
                  >
                    <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                      <div>
                        <p className="font-black uppercase">
                          {item.nome}
                        </p>

                        <p className="mt-1 text-yellow-400">
                          {item.prezzo} € cad.
                        </p>
                      </div>

                      <div className="flex items-center gap-3">
                        <button
                          onClick={() =>
                            cambiaQuantita(item.id, -1)
                          }
                          className="h-10 w-10 border border-zinc-700 font-black hover:border-yellow-400 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
                        >
                          −
                        </button>

                        <span className="min-w-8 text-center text-xl font-black">
                          {item.quantita}
                        </span>

                        <button
                          onClick={() =>
                            cambiaQuantita(item.id, 1)
                          }
                          className="h-10 w-10 border border-zinc-700 font-black hover:border-yellow-400 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
                        >
                          +
                        </button>

                        <button
                          onClick={() =>
                            eliminaDalCarrello(item.id)
                          }
                          className="ml-3 text-sm font-bold uppercase text-red-400"
                        >
                          Elimina
                        </button>
                      </div>
                    </div>

                    <p className="mt-4 text-right text-xl font-black">
                      {item.prezzo * item.quantita} €
                    </p>
                  </div>
                ))}
              </div>

              <div className="mt-8 border-t border-zinc-800 pt-6">
                <div className="flex items-center justify-between">
                  <span className="text-xl font-bold uppercase">
                    Totale
                  </span>

                  <span className="text-3xl font-black text-yellow-400">
                    {totaleCarrello} €
                  </span>
                </div>

                <div className="mt-6 grid gap-3 md:grid-cols-2">
                  <button
                    onClick={() => setCarrello([])}
                    className="border border-zinc-700 px-5 py-4 font-black uppercase tracking-widest hover:border-yellow-400 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
                  >
                    Svuota carrello
                  </button>

                  <button
  type="button"
  onClick={(e) => {
    e.preventDefault();
    e.stopPropagation();
    setCheckoutAperto(true);
  }}
  className="bg-yellow-400 px-5 py-4 font-black uppercase tracking-widest"
>
                    Checkout
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* CHECKOUT */}
{checkoutAperto && carrello.length > 0 && (
  <div id="ll-checkout" className="mt-8 border border-zinc-700 bg-zinc-950 p-6 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
    <div className="flex items-center justify-between">
      <h3 className="text-3xl font-black uppercase">
        Checkout
      </h3>

      <button
        onClick={() => setCheckoutAperto(false)}
        className="font-black text-zinc-400 hover:text-white"
      >
        ✕
      </button>
    </div>

    <p className="mt-2 text-zinc-400">
      Inserisci i dati per completare l&apos;ordine.
    </p>

    <div className="mt-6 grid gap-4 md:grid-cols-2">
      <input
        type="text"
        placeholder="Nome"
        value={datiCliente.nome}
onChange={(e) => setDatiCliente((prev) => ({ ...prev, nome: e.target.value }))}
        className="border border-zinc-700 bg-black p-4 text-white outline-none focus:border-yellow-400 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
      />

      <input
        type="text"
        placeholder="Cognome"
        value={datiCliente.cognome}
onChange={(e) => setDatiCliente((prev) => ({ ...prev, cognome: e.target.value }))}
        className="border border-zinc-700 bg-black p-4 text-white outline-none focus:border-yellow-400 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
      />

      <input
        type="email"
        placeholder="Email"
        value={datiCliente.email}
onChange={(e) => setDatiCliente((prev) => ({ ...prev, email: e.target.value }))}
        className="border border-zinc-700 bg-black p-4 text-white outline-none focus:border-yellow-400 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
      />
      <div className="mt-4">
  <label className="mb-2 block text-sm font-bold uppercase">
    Codice sconto
  </label>

  <div className="flex gap-2">
    <input
      type="text"
      placeholder="Inserisci codice sconto"
      value={codiceSconto}
onChange={(e) => {
  setCodiceSconto(e.target.value.toUpperCase());
  setCodiceTetrisValidato("");
  setScontoPercentuale(0);
  setMessaggioSconto("");
}}
      className="min-w-0 flex-1 rounded-xl border border-zinc-700 bg-black p-4 text-white outline-none shadow-[0_0_14px_rgba(250,204,21,0.14)]"
    />

    <button
      type="button"
      onClick={applicaCodiceSconto}
      className="rounded-xl bg-yellow-400 px-4 py-3 text-xs font-black uppercase text-black"
    >
      Applica
    </button>
  </div>

  {messaggioSconto && (
    <p className="mt-2 text-sm font-bold text-green-400">
      {messaggioSconto}
    </p>
  )}

  {erroreSconto && (
    <p className="mt-2 text-sm font-bold text-red-400">
      {erroreSconto}
    </p>
  )}
</div>

      <div className="mt-6">
  <label className="block mb-3 text-sm font-bold uppercase">
    Modalità ordine
  </label>

  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
    <button
      type="button"
      onClick={() => setModalitaOrdine("delivery")}
      className={`rounded-2xl border p-4 font-bold uppercase shadow-[0_0_14px_rgba(250,204,21,0.14)] ${
        modalitaOrdine === "delivery"
          ? "bg-yellow-400 text-black border-yellow-400"
          : "bg-black text-white border-zinc-700"
      }`}
    >
      Delivery
    </button>

    <button
      type="button"
      onClick={() => setModalitaOrdine("point")}
      className={`rounded-2xl border p-4 font-bold uppercase shadow-[0_0_14px_rgba(250,204,21,0.14)] ${
        modalitaOrdine === "point"
          ? "bg-yellow-400 text-black border-yellow-400"
          : "bg-black text-white border-zinc-700"
      }`}
    >
      Ritiro al Point
    </button>

    <button
      type="button"
      onClick={() => setModalitaOrdine("spedizione")}
      className={`rounded-2xl border p-4 font-bold uppercase shadow-[0_0_14px_rgba(250,204,21,0.14)] ${
        modalitaOrdine === "spedizione"
          ? "bg-yellow-400 text-black border-yellow-400"
          : "bg-black text-white border-zinc-700"
      }`}
    >
      Spedizione
    </button>
  </div>
</div>

      <input
        type="tel"
        placeholder="Telefono"
        value={datiCliente.telefono}
onChange={(e) => setDatiCliente((prev) => ({ ...prev, telefono: e.target.value }))}
        className="border border-zinc-700 bg-black p-4 text-white outline-none focus:border-yellow-400 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
      />
      <input
  type="text"
  placeholder="Indirizzo di consegna"  
  value={datiCliente.indirizzo}
onChange={(e) => setDatiCliente((prev) => ({ ...prev, indirizzo: e.target.value }))}
  className="border border-zinc-700 bg-black p-4 text-white outline-none focus:border-yellow-400 md:col-span-2 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
/>
{modalitaOrdine === "delivery" && (
  <div className="mt-6 md:col-span-2">
    <label className="mb-2 block text-sm font-bold uppercase">
      Data di consegna
    </label>

    <input
      type="date"
      value={dataConsegna}
      min={oggiItalia()}
      onChange={(event) => {
        setDataConsegna(event.target.value);
        setOrarioConsegna("");
      }}
      required
      className="w-full border border-zinc-700 bg-black px-4 py-3 text-white outline-none focus:border-yellow-400 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
    />

    <label className="mb-2 mt-5 block text-sm font-bold uppercase">
      Orario di consegna
    </label>

    <select
      value={orarioConsegna}
      onChange={(event) => setOrarioConsegna(event.target.value)}
      required
      disabled={caricamentoOrari || !dataConsegna}
      className="w-full border border-zinc-700 bg-black px-4 py-3 text-white outline-none focus:border-yellow-400 disabled:opacity-50 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
    >
      <option value="">
        {caricamentoOrari
          ? "Aggiornamento disponibilità..."
          : "Seleziona un orario"}
      </option>

      <optgroup label="Consegne pranzo">
        {orariConsegnaDisponibili
          .slice(0, 2)
          .filter(orarioPrenotabile)
          .map((orario) => (
            <option key={orario} value={orario}>
              {orario}
            </option>
          ))}
      </optgroup>

      <optgroup label="Consegne sera e notte">
        {orariConsegnaDisponibili
          .slice(2)
          .filter(orarioPrenotabile)
          .map((orario) => (
            <option key={orario} value={orario}>
              {orario}
            </option>
          ))}
      </optgroup>
    </select>

    {erroreSlot && (
      <p className="mt-2 text-sm font-bold text-red-400">
        {erroreSlot}
      </p>
    )}

    {!caricamentoOrari &&
      dataConsegna &&
      orariConsegnaDisponibili.filter(orarioPrenotabile).length === 0 && (
        <p className="mt-2 text-sm font-bold text-yellow-400">
          Nessun orario disponibile per questa data. Seleziona un altro giorno.
        </p>
      )}

    <p className="mt-2 text-sm text-zinc-400">
      Gli orari già prenotati scompaiono automaticamente. Puoi prenotare anche
      i giorni successivi.
    </p>
  </div>
)}
    </div>


    <div className="mt-6 border-t border-zinc-800 pt-6">
      <div className="flex items-center justify-between">
        <span className="font-bold uppercase">
          Totale ordine
        </span>

        <div className="text-right">
  <p className="text-sm text-zinc-400">
    Prodotti: {totaleCarrello} €
  </p>

  <p className="text-sm text-zinc-400">
    Consegna: {costoConsegna} €
  </p>

  <p className="mt-2 text-3xl font-black text-yellow-400">
    Totale: {totaleOrdine} €
  </p>
</div>
      </div>

      <button
  type="button"
onClick={(e) => {
  e.preventDefault();
  e.stopPropagation();
  inviaOrdineTelegram();
}}
  className="mt-6 w-full bg-yellow-400 px-6 py-4 font-black uppercase tracking-widest text-black"
>
  Conferma ordine
</button>
    </div>
  </div>
)}

</section>

{/* BRAND */}
      <section
        id="storia"
        className="border-y border-zinc-800 bg-zinc-950"
      >
        <div className="mx-auto grid max-w-7xl gap-12 px-6 py-24 lg:grid-cols-2">
          <div>
            <p className="font-bold uppercase tracking-[0.3em] text-yellow-400">
              Il progetto
            </p>

            <h2 className="mt-4 text-5xl font-black uppercase">
              Non seguire
              <br />
              la strada.
              <br />
              <span className="text-yellow-400">Crea la tua linea.</span>
            </h2>
          </div>

          <div className="flex items-center">
            <p className="max-w-xl text-lg leading-8 text-zinc-400">
              Il club piu antico sotto la Madonnina. dal 2016 La migliore selezione di prodotti e accessori per la nostra passione da tutto il mondo. Consegne sulla citta dalle 10 alle 2am con possibilita di passare in uno dei nostri point o di ricevere il pacco a casa. Scopri il mondo LaLinea e unisciti alla nostra community
            </p>
          </div>
        </div>
      </section>

{/* DICONO DI NOI */}
<section
  id="dicono-di-noi"
  className="border-y border-zinc-800 bg-zinc-950"
>
  <div className="mx-auto max-w-7xl px-6 py-24">

    <p className="font-bold uppercase tracking-[0.3em] text-yellow-400">
      Recensioni
    </p>

    <h2 className="mt-4 text-5xl font-black uppercase">
      Dicono di noi
    </h2>
    <div className="mt-6 flex flex-wrap items-center gap-3">
      <button
        type="button"
        onClick={() => {
          if (recensioniAperte) {
            setRecensioniAperte(false);
          } else {
            setRecensioniAperte(true);
            setOrdineRecensioni(mescolaNumeri(tutteLeRecensioni));
            setRecensioniVisibili(8);
          }
        }}
        className="border border-yellow-400 bg-black px-6 py-3 font-black uppercase text-white hover:text-yellow-400 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
      >
        {recensioniAperte ? "Chiudi recensioni" : "Esplora i feedback"}
      </button>

      {recensioniAperte && (
        <button
          type="button"
          onClick={() => {
            setOrdineRecensioni(mescolaNumeri(tutteLeRecensioni));
            setRecensioniVisibili(8);
          }}
          className="rounded-2xl border border-green-400/60 bg-green-400/10 px-5 py-3 text-xs font-black uppercase tracking-wider text-green-300"
        >
          ↻ Mescola feedback
        </button>
      )}
    </div>

    {recensioniAperte && (
      <>
        <div className="mt-5 flex items-center justify-between gap-3 text-xs font-bold uppercase tracking-wider text-zinc-400">
          <span>Ordine casuale · nessuna ripetizione</span>
          <span>{Math.min(recensioniVisibili, ordineRecensioni.length)} / {ordineRecensioni.length}</span>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {ordineRecensioni.slice(0, recensioniVisibili).map((numero) => (
            <img
              key={numero}
              src={`/reviews/review${numero}.jpg`}
              alt={`Recensione ${numero}`}
              loading="lazy"
              decoding="async"
              onError={(evento) => {
                evento.currentTarget.style.display = "none";
              }}
              className="w-full rounded-2xl border border-yellow-400/30 bg-black object-cover shadow-[0_0_14px_rgba(250,204,21,0.10)]"
            />
          ))}
        </div>

        {recensioniVisibili < ordineRecensioni.length ? (
          <div className="mt-8 text-center">
            <button
              type="button"
              onClick={() =>
                setRecensioniVisibili((correnti) =>
                  Math.min(correnti + 8, ordineRecensioni.length)
                )
              }
              className="rounded-2xl bg-yellow-400 px-7 py-4 font-black uppercase tracking-wider text-black shadow-[0_0_18px_rgba(250,204,21,0.22)]"
            >
              Mostra altri 8 feedback
            </button>
          </div>
        ) : (
          <p className="mt-8 text-center text-sm font-black uppercase tracking-wider text-green-300">
            Hai visto tutti i {ordineRecensioni.length} feedback disponibili
          </p>
        )}
      </>
    )}
  </div>
</section>
{/* I NOSTRI POINT */}
      <section id="point" className="border-t border-zinc-800 bg-zinc-950">
        <div className="mx-auto max-w-7xl px-6 py-24">
          <p className="font-bold uppercase tracking-[0.3em] text-yellow-400">
            LALINEA MILANO
          </p>

          <h2 className="mt-3 text-5xl font-black uppercase">
            I NOSTRI POINT
          </h2>

          <p className="mt-5 max-w-2xl text-lg leading-8 text-zinc-400">
            Scegli il Point LaLinea più comodo per ritirare i tuoi prodotti a Milano.
          </p>

          <div className="mt-8 border border-yellow-400 bg-yellow-400/10 p-6 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
            <p className="font-black uppercase tracking-wider text-yellow-400">
              IMPORTANTE
            </p>
            <p className="mt-2 text-white">
              È gradita la prenotazione almeno 30 minuti prima.
              Presentarsi singolarmente nei vari Point.
            </p>
          </div>

  
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-stretch">

  {/* POINT 01 */}
  <div className="flex flex-col justify-between border border-zinc-800 bg-black p-4 min-h-[220px] rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
    <div>
      <p className="text-xs font-bold uppercase tracking-[0.25em] text-yellow-400">
        POINT 01
      </p>

      <h3 className="mt-3 text-2xl font-black uppercase">
        Piazzale Loreto
      </h3>

      <p className="mt-3 text-sm text-zinc-400">
        Tutti i giorni
      </p>

      <p className="mt-1 text-lg font-bold">
        19:00 - 02:00
      </p>
    </div>

    <a
      href="https://t.me/LaLineaMiOrdini"
      target="_blank"
      rel="noopener noreferrer"
      className="mt-4 block bg-yellow-400 px-4 py-3 text-center text-sm font-black uppercase tracking-widest text-black"
    >
      PRENOTA IL RITIRO
    </a>
  </div>

  {/* POINT 02 */}
  <div className="flex flex-col justify-between border border-zinc-800 bg-black p-4 min-h-[220px] rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
    <div>
      <p className="text-xs font-bold uppercase tracking-[0.25em] text-yellow-400">
        POINT 02
      </p>

      <h3 className="mt-3 text-2xl font-black uppercase">
        Piazzale Piemonte
      </h3>

      <p className="mt-3 text-sm text-zinc-400">
        Tutti i giorni
      </p>

      <p className="mt-1 text-lg font-bold">
        12:00 - 02:00
      </p>
    </div>

    <a
      href="https://t.me/LaLineaMiOrdini"
      target="_blank"
      rel="noopener noreferrer"
      className="mt-4 block bg-yellow-400 px-4 py-3 text-center text-sm font-black uppercase tracking-widest text-black"
    >
      PRENOTA IL RITIRO
    </a>
  </div>

</div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-stretch">

  {/* POINT 03 */}
  <div className="flex flex-col justify-between border border-zinc-800 bg-black p-4 min-h-[220px] rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
    <div>
      <p className="text-xs font-bold uppercase tracking-[0.25em] text-yellow-400">
        POINT 03
      </p>

      <h3 className="mt-3 text-2xl font-black uppercase">
        Piazza Galeazzi Bruzzano
      </h3>

      <p className="mt-3 text-zinc-400">
        Tutti i giorni
      </p>

      <p className="mt-1 text-xl font-bold">
        10:00 — 20:00
      </p>
    </div>

    <a
      href="https://t.me/LaLineaMiOrdini"
      target="_blank"
      rel="noopener noreferrer"
      className="mt-6 block bg-yellow-400 px-5 py-4 text-center font-black uppercase tracking-widest text-black"
    >
      PRENOTA IL RITIRO
    </a>
  </div>

  {/* POINT 04 */}
  <div className="flex flex-col justify-between border border-zinc-800 bg-black p-4 min-h-[220px] rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
    <div>
      <p className="text-xs font-bold uppercase tracking-[0.25em] text-yellow-400">
        POINT 04
      </p>

      <h3 className="mt-3 text-2xl font-black uppercase">
        Piazza 24 Maggio
      </h3>

      <p className="mt-3 text-zinc-400">
        Tutti i giorni
      </p>

      <p className="mt-1 text-xl font-bold">
        10:00 — 20:00
      </p>
    </div>

    <a
      href="https://t.me/LaLineaMiOrdini"
      target="_blank"
      rel="noopener noreferrer"
      className="mt-6 block bg-yellow-400 px-5 py-4 text-center font-black uppercase tracking-widest text-black"
    >
      PRENOTA IL RITIRO
    </a>
  </div>

</div>
<div className="flex flex-col justify-between border border-zinc-800 bg-black p-6 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
  <div>
    <p className="text-xs font-bold uppercase tracking-[0.25em] text-yellow-400">
      POINT 05
    </p>

    <h3 className="mt-3 text-2xl font-black uppercase">
      Piazza Guardi
    </h3>

    <p className="mt-3 text-zinc-400">
      Tutti i giorni
    </p>

    <p className="mt-1 text-xl font-bold">
      18:00 — 02:00
    </p>
  </div>

  <a
    href="https://t.me/LaLineaMiOrdini"
    target="_blank"
    rel="noopener noreferrer"
    className="mt-6 block bg-yellow-400 px-5 py-4 text-center font-black uppercase tracking-widest text-black"
  >
    PRENOTA IL RITIRO
  </a>
</div>
          </div>
        
      </section>
      {/* CONTATTI */}
      <footer id="contatti" className="border-t border-zinc-800 bg-black">
        <div className="mx-auto max-w-7xl px-6 py-20">

          <p className="font-bold uppercase tracking-[0.3em] text-yellow-400">
            CONTATTI
          </p>

          <h2 className="mt-3 text-4xl font-black uppercase">
            PARLA CON LALINEA.
          </h2>

          <div className="mt-12 grid gap-6 md:grid-cols-2">

            <div className="border border-zinc-800 bg-zinc-950 p-6 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
              <p className="text-xs font-bold uppercase tracking-[0.25em] text-yellow-400">
                INFORMAZIONI PRE E POST VENDITA
              </p>
              <a
                href="https://t.me/LaLineaInfoAssistenza"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 block text-lg font-bold hover:text-yellow-400"
              >
                Telegram — @LaLineaInfoAssistenza
              </a>
            </div>

            <div className="border border-zinc-800 bg-zinc-950 p-6 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
              <p className="text-xs font-bold uppercase tracking-[0.25em] text-yellow-400">
                ORDINI
              </p>
              <a
                href="https://t.me/LaLineaMiOrdini"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 block text-lg font-bold hover:text-yellow-400"
              >
                Telegram — @LaLineaMiOrdini
              </a>

              <a
                href="https://threema.id/H7JMTBM4"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 block text-lg font-bold hover:text-yellow-400"
              >
                Threema — H7JMTBM4
              </a>
            </div>

            <div className="border border-zinc-800 bg-zinc-950 p-6 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
              <p className="text-xs font-bold uppercase tracking-[0.25em] text-yellow-400">
                FORNITORI / RIVENDITORI
              </p>
              <a
                href="https://t.me/LaLineaResellerPlug"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 block text-lg font-bold hover:text-yellow-400"
              >
                Telegram — @LaLineaResellerPlug
              </a>
            </div>

            <div className="border border-zinc-800 bg-zinc-950 p-6 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
              <p className="text-xs font-bold uppercase tracking-[0.25em] text-yellow-400">
                SPEDIZIONI ITALIA / ESTERO
              </p>
              <p className="mt-3 text-lg font-bold">
                Pagamento all'arrivo
              </p>
            </div>

            <div className="border border-yellow-400 p-6 md:col-span-2 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
              <p className="text-xs font-bold uppercase tracking-[0.25em] text-yellow-400">
                VUOI LAVORARE CON NOI?
              </p>
              <a
                href="mailto:igorg69@tutamail.com"
                className="mt-3 block text-xl font-black hover:text-yellow-400"
              >
                igorg69@tutamail.com
              </a>
            </div>

          </div>

          <div className="mt-12 border-t border-zinc-800 pt-6 text-xs text-zinc-500">
            © LaLinea Milano — Since2016 - Il club piu antico sotto la Madonnina. Tutti i diritti riservati.
          </div>

        </div>
      </footer>
      {/* DELIVERY */}
<section
  id="delivery"
  className="border-t border-yellow-400/30 px-6 py-20"
>
  <div className="mx-auto max-w-7xl">
    <p className="font-bold uppercase tracking-[0.3em] text-yellow-400">
      Delivery
    </p>

    <h2 className="mt-3 text-4xl font-black uppercase">
      Zone di consegna
    </h2>

    <p className="mt-4 text-zinc-400">
      Consegna disponibile in tutta Milano. Costo consegna: 10 € in zona bianca 25€ in zona rossa
    </p>
<div className="mt-8 overflow-hidden border border-yellow-400/30 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
  <img
    src="/mappa.jpg"
    alt="Mappa zone di consegna LaLinea"
    className="w-[70%] max-w-3xl mx-auto object-contain"
  />
</div>
{/* DESCRIZIONE ORARI DELIVERY */}
<div className="mt-6 border border-zinc-800 bg-zinc-950 p-5 rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]">
  <p className="text-[1.05rem] font-bold uppercase leading-relaxed text-yellow-400">
    LE CONSEGNE VENGONO EFFETTUATE TUTTI I GIORNI DALLE 13 ALLE 14
    <br />
    E DALLE 19 ALLE 2AM DAL LUNEDÌ AL SABATO. 
    LA DOMENICA DALLE
    18 ALLE DUE.
  </p>

  <p className="text-[1.05rem] font-bold uppercase leading-relaxed text-yellow-400">
    TUTTI GLI ORDINI VANNO EFFETTUATI COL CARRELLO.
    <br />
     IN CASO FOSSIMO
    FULL IL CARRELLO RIFIUTERÀ IN AUTOMATICO L&apos;ORDINE.
  </p>
</div>
    <div className="mt-8">
      <a
        href="https://t.me/+WWNiFZ_7VlZlZWY0"
target="_blank"
rel="noopener noreferrer"
        className="inline-block border border-yellow-400 bg-yellow-400 px-6 py-4 font-black uppercase tracking-widest text-black rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
      >
        Orari e gruppi Telegram
      </a>
    </div>
  </div>
</section>

<div className="ll-gioca py-12 text-center">
  <button
    type="button"
    onClick={() => setTetrisAperto(true)}
    className="border-2 border-yellow-400 bg-black px-8 py-4 font-black uppercase text-yellow-400 hover:bg-yellow-400 hover:text-black rounded-2xl shadow-[0_0_14px_rgba(250,204,21,0.14)]"
  >
    GIOCA A LALINEA GAME · LALINEA EDITION
  </button>
</div>

{/* I PIÙ VENDUTI DELLA SETTIMANA */}
{piuVendutiVisibili && (
<div
  className="ll-best-sellers fixed bottom-3 right-3 z-[9998] w-[calc(54%-12px)] overflow-hidden rounded-xl border border-yellow-400 bg-black/95 shadow-2xl md:bottom-4 md:right-4 md:w-[320px]"
>
  <button
    type="button"
    onClick={() => setPiuVendutiVisibili(false)}
    className="absolute right-2 top-2 z-20 flex h-7 w-7 items-center justify-center rounded-full border-2 border-yellow-400 bg-black text-sm font-black text-yellow-400 shadow-[0_0_14px_rgba(250,204,21,0.14)]"
    aria-label="Chiudi prodotti più venduti"
  >
    ×
  </button>

  <div className="ll-best-sellers-title border-b border-yellow-400 bg-yellow-400 px-4 py-3 text-center text-sm font-black uppercase tracking-widest text-black">
    I PIÙ VENDUTI DELLA SETTIMANA
  </div>

  <div className="ll-best-sellers-grid grid grid-cols-3 gap-1 bg-black p-2">
    {/* 1 - TUNA OG STATIC */}
<button
  type="button"
  onClick={() => apriProdottoCatalogo("Frozen e Static", "tuna-og-static")}
  className="overflow-hidden rounded-xl border border-yellow-400/60 shadow-lg"
  aria-label="Apri TUNA OG STATIC"
>
  <video
    src="/products/frozen-static/tonno1.mp4"
    data-no-preview="true"
    autoPlay
    muted
    loop
    playsInline
    className="aspect-square w-full object-cover"
    preload="metadata"
  />
  <span className="ll-best-seller-label block border-t border-yellow-400/30 bg-black px-1 py-2 text-center font-black text-white">
    1° TUNA OG STATIC
  </span>
</button>

{/* 2 - ZAZAYA x KEY LIME PIE CAKE */}
<button
  type="button"
  onClick={() => apriProdottoCatalogo("Rosin & Pen", "zazaya-key-lime-pie-cake")}
  className="overflow-hidden rounded-xl border border-yellow-400/60 shadow-lg"
  aria-label="Apri ZAZAYA x KEY LIME PIE CAKE"
>
  <video
    src="/products/rosin/key1.mp4"
    data-no-preview="true"
    autoPlay
    muted
    loop
    playsInline
    className="aspect-square w-full object-cover"
    preload="metadata"
  />
  <span className="ll-best-seller-label block border-t border-yellow-400/30 bg-black px-1 py-2 text-center font-black text-white">
    2° ZAZAYA x KEY LIME PIE CAKE
  </span>
</button>

    {/* 3 - GOLD PACK */}
    <button
      type="button"
      onClick={() => apriProdottoCatalogo("", "gold-pack-card", "promo")}
      className="overflow-hidden rounded-xl border border-yellow-400/60 shadow-[0_0_16px_rgba(250,204,21,0.18)]"
      aria-label="Apri Gold Pack"
    >
      <video
        src="/products/promo/gold.mp4"
        data-no-preview="true"
        autoPlay
        muted
        loop
        playsInline
        className="aspect-square w-full object-cover"
       preload="metadata"/>
      <span className="ll-best-seller-label block border-t border-yellow-400/30 bg-black px-1 py-1 text-[9px] font-bold uppercase leading-tight text-yellow-300 md:hidden">
        3° PACK GOLD
      </span>
    </button>
  </div>

  <div className="ll-best-sellers-ticker-wrap overflow-hidden whitespace-nowrap border-t border-yellow-400/30 py-4">
    <div className="best-sellers-ticker inline-flex items-center">
      {[0, 1].map((ripetizione) => (
        <div key={ripetizione} className="inline-flex items-center">
          <button
  type="button"
  onClick={() => apriProdottoCatalogo("Frozen e Static", "tuna-og-static")}
  className="mx-6 font-black text-yellow-400"
>
  🥇 1° TUNA OG STATIC
</button>

<button
  type="button"
  onClick={() => apriProdottoCatalogo("Rosin & Pen", "zazaya-key-lime-pie-cake")}
  className="mx-6 font-black text-white"
>
  🥈 2° ZAZAYA x KEY LIME PIE CAKE
</button>

          <button
            type="button"
            onClick={() => apriProdottoCatalogo("", "gold-pack-card", "promo")}
            className="mx-6 font-black text-yellow-400"
          >
            🥉 3° PACK GOLD
          </button>
        </div>
      ))}
    </div>
  </div>

  <style>{`
    .best-sellers-ticker {
      animation: bestSellersScroll 15s linear infinite;
    }

    .best-sellers-ticker:hover {
      animation-play-state: paused;
    }

    @keyframes bestSellersScroll {
      from {
        transform: translateX(0);
      }

      to {
        transform: translateX(-50%);
      }
    }

    @media (max-width: 640px) {
      .best-sellers-ticker {
        animation-duration: 12s;
      }
    }
  `}</style>
  <style>{`
  @media (max-width: 767px) {
    .ll-best-sellers {
      height: 9.57rem !important;
      max-height: none !important;
      display: flex !important;
      flex-direction: column !important;
    }

    .lalinea-mobile-shell:has(.ll-tetris-mobile[data-feedback="chiuso"]) .ll-best-sellers {
      height: 6rem !important;
    }

    .lalinea-mobile-shell[data-player="chiuso"] .ll-best-sellers {
      height: 8.97rem !important;
    }

    .lalinea-mobile-shell[data-player="chiuso"]:has(.ll-tetris-mobile[data-feedback="chiuso"]) .ll-best-sellers {
      height: 5.4rem !important;
    }

    .ll-best-sellers-title {
      flex: 0 0 auto !important;
    }

    .ll-best-sellers-grid {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      grid-template-rows: minmax(0, 1fr) !important;
    }

    .ll-best-sellers-grid > button {
      display: flex !important;
      flex-direction: column !important;
      min-width: 0 !important;
      min-height: 0 !important;
    }

    .ll-best-sellers-grid video {
      display: block !important;
      flex: 1 1 0% !important;
      width: 100% !important;
      height: 0 !important;
      min-height: 0 !important;
      aspect-ratio: auto !important;
      object-fit: cover !important;
    }

    .ll-best-seller-label {
      flex: 0 0 auto !important;
      min-height: 2rem !important;
    }
  }
`}</style>
</div>
)}
{/* INIZIO TETRIS / FEEDBACK / MUSICA VERTICALI */}
<div
  className="ll-vertical-tools"
  aria-label="LaLinea Game, feedback e musica LaLinea"
  hidden={!tetrisSchedaVisibile && !feedbackPopupVisibile && !playerVisibile}
  onClick={(evento) => evento.stopPropagation()}
>
  {tetrisSchedaVisibile && (
  <section className="ll-tool-card">
    <button
      type="button"
      className="ll-tool-close"
      onClick={() => setTetrisSchedaVisibile(false)}
      aria-label="Chiudi scheda LaLinea Game"
    >
      ×
    </button>
    <h3 className="ll-tool-heading">LALINEA GAME</h3>
    <div className="ll-tool-content">
      <div className="ll-tool-tetris-mark" aria-hidden="true">
        <span /><span /><span /><span />
      </div>
      <p className="ll-tool-name">LALINEA GAME</p>
      <p className="ll-tool-caption ll-tool-yellow">GUADAGNA BUONI GIOCANDO</p>
      <button
        type="button"
        className="ll-tool-action ll-tool-bottom"
        onClick={(evento) => {
          evento.stopPropagation();
          setTetrisAperto(true);
        }}
        aria-label="Apri il gioco completo LaLinea Game"
      >
        GIOCA
      </button>
    </div>
  </section>
  )}

  {feedbackPopupVisibile && (
    <section className="ll-tool-card">
      <button
        type="button"
        className="ll-tool-close"
        onClick={() => setFeedbackPopupVisibile(false)}
        aria-label="Chiudi feedback"
      >
        ×
      </button>
      <h3 className="ll-tool-heading">FEEDBACK</h3>
      <div className="ll-tool-content">
        <button
          type="button"
          className="ll-tool-feedback-photo"
          onClick={(evento) => {
            evento.stopPropagation();
            setTipoAnteprima("img");
            setFotoAnteprima(`/reviews/review${feedbackInEvidenza}.jpg`);
          }}
          aria-label={`Ingrandisci il feedback ${feedbackInEvidenza}`}
        >
          <img
            key={feedbackInEvidenza}
            src={`/reviews/review${feedbackInEvidenza}.jpg`}
            alt={`Feedback ${feedbackInEvidenza}`}
            loading="eager"
            decoding="async"
            onError={(evento) => {
              if (!evento.currentTarget.src.endsWith("/reviews/review33.jpg")) {
                evento.currentTarget.src = "/reviews/review33.jpg";
              }
            }}
          />
        </button>
        <p className="ll-tool-name">#{feedbackInEvidenza}</p>
        <p className="ll-tool-caption ll-tool-green">CAMBIA IN AUTOMATICO</p>
        <button
          type="button"
          className="ll-tool-action"
          onClick={(evento) => {
            evento.stopPropagation();
            apriRecensioniComplete();
          }}
        >
          VEDI TUTTI
        </button>
      </div>
    </section>
  )}

  {playerVisibile && (
    <section className="ll-tool-card">
      <button
        type="button"
        className="ll-tool-close"
        onClick={() => {
          audioRef.current?.pause();
          setMusicaAvviata(false);
          setPlayerVisibile(false);
        }}
        aria-label="Chiudi player musicale"
      >
        ×
      </button>
      <h3 className="ll-tool-heading">MUSICA</h3>
      <div className="ll-tool-content">
        <img
          className="ll-tool-sound-logo"
          src="/lalinea-sound.jpg"
          alt="LaLinea Sound"
          data-no-preview="true"
          width="76"
          height="76"
          decoding="async"
        />
        <div className="ll-tool-song" aria-live="polite">
          <p className="ll-tool-name">{PLAYLIST_MUSICALE[indiceCanzone].titolo}</p>
          <p className="ll-tool-caption ll-tool-yellow">
            {PLAYLIST_MUSICALE[indiceCanzone].artista}
          </p>
        </div>
        <div className="ll-tool-player-controls ll-tool-bottom">
          <button
            type="button"
            className="ll-tool-round ll-tool-play"
            onClick={togglePlayerMusicale}
            aria-label={musicaAvviata ? "Metti in pausa" : "Riproduci"}
            aria-pressed={musicaAvviata}
          >
            {musicaAvviata ? (
              <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <rect x="6" y="5" width="4" height="14" rx="1" />
                <rect x="14" y="5" width="4" height="14" rx="1" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <path d="M8 5.5v13L18.5 12 8 5.5Z" />
              </svg>
            )}
          </button>
          <div className="ll-tool-skip-row">
            <button
              type="button"
              className="ll-tool-round"
              onClick={() => cambiaCanzonePlayer(-1)}
              aria-label="Brano precedente"
            >
              <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M7 5v14M19 6.5 10.5 12 19 17.5V6.5Z" fill="currentColor" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
              </svg>
            </button>
            <button
              type="button"
              className="ll-tool-round"
              onClick={() => cambiaCanzonePlayer(1)}
              aria-label="Brano successivo"
            >
              <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M17 5v14M5 6.5 13.5 12 5 17.5V6.5Z" fill="currentColor" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </section>
  )}
</div>

<style>{`
  .lalinea-mobile-shell:has(.ll-vertical-tools) {
    --ll-tools-height: 16rem;
  }
  .lalinea-mobile-shell:has(.ll-vertical-tools)
  :is(.ll-tetris-mobile, .ll-feedback-card, .ll-music-player) {
    display: none !important;
  }
  .ll-vertical-tools {
    position: fixed;
    z-index: 9998;
    left: 0.5rem;
    bottom: calc(0.5rem + env(safe-area-inset-bottom));
    display: grid;
    grid-auto-flow: column;
    grid-auto-columns: minmax(0, 1fr);
    gap: 4px;
    width: calc(50% - 0.75rem);
    height: var(--ll-tools-height);
    padding: 4px;
    border: 2px solid #ffdb35;
    border-radius: 16px;
    background: #050505;
    color: #fff;
  }
  .ll-vertical-tools[hidden] { display: none !important; }
  .ll-vertical-tools, .ll-vertical-tools * { box-sizing: border-box; }
  .ll-tool-card {
    position: relative;
    display: flex;
    flex-direction: column;
    min-width: 0;
    min-height: 0;
    overflow: hidden;
    border: 1px solid #ffdb3580;
    border-radius: 11px;
    background: #080a09;
  }
  .ll-tool-close {
    position: absolute;
    top: 3px;
    right: 3px;
    z-index: 2;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    padding: 0;
    border: 1px solid #ffdb35;
    border-radius: 50%;
    background: #050505;
    color: #ffdb35;
    font-size: 21px;
    line-height: 1;
    cursor: pointer;
  }
  .ll-tool-heading {
    flex: 0 0 auto;
    margin: 0;
    padding: 8px 34px 8px 4px;
    background: #ffdb35;
    color: #050505;
    font-size: 13px;
    font-weight: 900;
    line-height: 1.2;
    text-align: center;
  }
  .ll-tool-content {
    display: flex;
    flex: 1 1 0;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    min-width: 0;
    min-height: 0;
    padding: 6px 3px;
  }
  .ll-tool-name, .ll-tool-caption {
    width: 100%;
    margin: 0;
    font-weight: 900;
    line-height: 1.15;
    text-align: center;
    text-transform: uppercase;
    overflow-wrap: anywhere;
  }
  .ll-tool-name { font-size: 13px; }
  .ll-tool-caption { font-size: 10px; }
  .ll-tool-yellow { color: #ffdb35; }
  .ll-tool-green { color: #43df80; }
  .ll-tool-bottom { margin-top: auto; }
  .ll-tool-action {
    display: flex;
    flex: 0 0 auto;
    align-items: center;
    justify-content: center;
    width: 100%;
    min-height: 34px;
    padding: 4px 1px;
    border: 1px solid #43df80;
    border-radius: 999px;
    background: #07140c;
    color: #43df80;
    font-size: 11px;
    font-weight: 900;
    line-height: 1.15;
    cursor: pointer;
  }
  .ll-tool-tetris-mark {
    display: grid;
    flex: 0 0 auto;
    grid-template-columns: repeat(3, 1fr);
    gap: 3px;
    width: min(100%, 48px);
    margin: 7px 0;
  }
  .ll-tool-tetris-mark span { aspect-ratio: 1; border-radius: 3px; background: #ffdb35; }
  .ll-tool-tetris-mark span:last-child { grid-column: 2; background: #43df80; }
  .ll-tool-feedback-photo {
    display: block;
    flex: 1 1 0;
    width: 100%;
    min-height: 0;
    padding: 0;
    overflow: hidden;
    border: 1px solid #ffdb3580;
    border-radius: 8px;
    background: #121413;
    cursor: pointer;
  }
  .ll-tool-feedback-photo img { display: block; width: 100%; height: 100%; object-fit: contain; }
  .ll-tool-sound-logo {
    display: block;
    flex: 0 0 auto;
    width: min(100%, 60px);
    height: auto;
    aspect-ratio: 1;
    border-radius: 50%;
    object-fit: contain;
  }
  .ll-tool-song { display: grid; gap: 3px; width: 100%; }
  .ll-tool-song .ll-tool-name,
  .ll-tool-song .ll-tool-caption {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
  }
  .ll-tool-player-controls { display: flex; flex: 0 0 auto; flex-direction: column; align-items: center; gap: 3px; width: 100%; }
  .ll-tool-skip-row { display: flex; justify-content: center; gap: 3px; width: 100%; }
  .ll-tool-round {
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 0 1 28px;
    width: 28px;
    height: 28px;
    min-width: 0;
    padding: 0;
    border: 1px solid #43df8080;
    border-radius: 50%;
    background: #07140c;
    color: #43df80;
    cursor: pointer;
  }
  .ll-tool-round svg { width: 18px; height: 18px; }
  .ll-tool-play { flex: 0 0 auto; width: 36px; height: 36px; border: 2px solid #ffdb35; background: #35d66d; color: #052312; }
  .ll-vertical-tools button:focus-visible { outline: 2px solid #fff; outline-offset: -3px; }

  .lalinea-mobile-shell:has(.ll-vertical-tools):has(.ll-tetris-mobile[data-feedback]) .ll-best-sellers {
    left: auto !important;
    right: 0.5rem !important;
    bottom: calc(0.5rem + env(safe-area-inset-bottom)) !important;
    width: calc(50% - 0.75rem) !important;
    height: var(--ll-tools-height) !important;
    max-height: none !important;
    display: flex !important;
    flex-direction: column !important;
  }
  .ll-best-sellers-title { flex: 0 0 auto !important; }
  .ll-best-sellers-grid { flex: 1 1 0% !important; min-height: 0 !important; grid-template-rows: minmax(0, 1fr) !important; }
  .ll-best-sellers-grid > button { display: flex !important; flex-direction: column !important; min-height: 0 !important; min-width: 0 !important; }
  .ll-best-sellers-grid video { display: block !important; flex: 1 1 0% !important; width: 100% !important; height: 0 !important; min-height: 0 !important; aspect-ratio: auto !important; object-fit: cover !important; }
  .ll-best-seller-label { flex: 0 0 auto !important; min-height: 2rem !important; }

  @media (max-width: 767px) {
    .lalinea-mobile-shell:has(.ll-vertical-tools) { --ll-tools-height: 13.75rem; }
    .ll-tool-heading { padding: 25px 1px 4px; font-size: 9px; }
    .ll-tool-close { width: 23px; height: 23px; font-size: 18px; }
    .ll-tool-content { gap: 3px; padding: 4px 2px; }
    .ll-tool-name { font-size: 10px; }
    .ll-tool-caption { font-size: 8px; }
    .ll-tool-action { min-height: 28px; font-size: 9px; }
    .ll-tool-tetris-mark { width: min(100%, 36px); margin: 4px 0; }
    .ll-tool-sound-logo { width: min(100%, 40px); }
    .ll-tool-round { flex-basis: 24px; width: 24px; height: 24px; }
    .ll-tool-round svg { width: 15px; height: 15px; }
    .ll-tool-play { flex-basis: auto; width: 32px; height: 32px; }
    .ll-best-sellers-title { padding: 7px 25px 7px 4px !important; font-size: 9px !important; line-height: 1.15 !important; }
    .lalinea-mobile-shell[data-vista-mobile] > :is(#shop, #promo, #tracking, #dicono-di-noi, #point, #delivery, #contatti),
    .lalinea-mobile-shell[data-vista-mobile="home"] > .ll-mobile-home {
      padding-bottom: calc(14.75rem + env(safe-area-inset-bottom)) !important;
    }
  }
`}</style>
{/* FINE TETRIS / FEEDBACK / MUSICA VERTICALI */}
{/* LALINEA_GAME_INSTALLED */}


{/* LALINEA_GAME_REPLACES_TETRIS_INLINE */}
{tetrisAperto && typeof document !== "undefined" && laLineaGamePortal(
  <div role="dialog" aria-modal="true" aria-label="LaLinea Game"
    onClick={(event) => event.stopPropagation()}
    style={{ position: "fixed", inset: 0, zIndex: 10002, display: "flex", flexDirection: "column", background: "#050505" }}>
    <button id="lalinea-game-close" type="button" onClick={() => setTetrisAperto(false)}
      style={{ flexShrink: 0, minHeight: 44, padding: "max(10px, env(safe-area-inset-top)) 12px 10px", textAlign: "left", background: "#050505", color: "#ffdb35", border: 0, borderBottom: "1px solid #ffdb3540", font: "700 13px system-ui, sans-serif", cursor: "pointer" }}>
      ← CHIUDI E TORNA AL SITO LALINEA
    </button>
    <iframe src="/lalinea-game/index.html" title="LaLinea Game" allow="autoplay; fullscreen" allowFullScreen
      style={{ flex: 1, minHeight: 0, width: "100%", border: 0, background: "#050505" }} />
  </div>, document.body
)} 


</main>
);
}